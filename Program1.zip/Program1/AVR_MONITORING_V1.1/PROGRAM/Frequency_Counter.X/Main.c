/*************************************************************************************************
*  PURPOSE      : AVR Monitoring System                                                          *
*  DEVELOPED BY : Prabhu R                                                                       *
*  STARTED ON   : 15-05-2017                                                                     *
*  VERSION      : V1.1                                                                           *
*  Language     : C Programming                                                                  *
*  Controller   : PIC12F683(8 Bit)                                                               *
*                                                                                                *                  
**************************************************************************************************

********************************************************************************
* HARDWARE *         * PORT ALLOCATION  *                                      *
********************************************************************************
------------------------------------|
PIN |GPIO  	 |Port Allocate         |
----|--------|----------------------|
1	|-		 | VDD (+5V)            |
2	|5		 | Voltage Trip Relay   |
3	|4		 | ADC Input            |
4	|3		 | MCLR                 |
5	|2   	 | Frequency Count      |
6	|1   	 | Frequency trip Relay |
7	|0		 | Status LED           |
8	|-		 | VSS                  |
------------------------------------|
 */

/*******************************************************************************/
/*                                                                             */ 
/*                              Include Files                                  */
/*                                                                             */
/*******************************************************************************/

#include <xc.h>
#include <stdint.h>

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.

/*******************************************************************************/
/*                                                                             */ 
/*                              Configuration                                  */
/*                                                                             */
/*******************************************************************************/

#pragma config FOSC = INTOSCIO  // Oscillator Selection bits (INTOSCIO oscillator: I/O function on RA4/OSC2/CLKOUT pin, I/O function on RA5/OSC1/CLKIN)
#pragma config WDTE = OFF        // Watchdog Timer Enable bit (WDT enabled)
#pragma config PWRTE = OFF       // Power-up Timer Enable bit (PWRT enabled)
#pragma config MCLRE = ON       // MCLR Pin Function Select bit (MCLR pin function is MCLR)
#pragma config CP = OFF         // Code Protection bit (Program memory code protection is disabled)
#pragma config CPD = OFF        // Data Code Protection bit (Data memory code protection is disabled)
#pragma config BOREN = ON       // Brown Out Detect (BOR enabled)
#pragma config IESO = OFF       // Internal External Switchover bit (Internal External Switchover mode is disabled)
#pragma config FCMEN = OFF      // Fail-Safe Clock Monitor Enabled bit (Fail-Safe Clock Monitor is disabled)

/*******************************************************************************/
/*                                                                             */ 
/*                              Crystal Oscillator                             */
/*                                                                             */
/*******************************************************************************/

#define _XTAL_FREQ 4000000

/*******************************************************************************/
/*                                                                             */ 
/*                              Limit Values Definition                        */
/*                                                                             */
/*******************************************************************************/
#define UnderFreqLimit                  369     // Over Frequency Limit
#define UnderFreqResetLimit             380     // Over Frequency Reset Limit
#define OverVoltageTimeDelay            300     // Over Voltage Trip Delay i.e XXX*10 ms 300x10 ms  = 3 seconds  
#define UnderFreqTimeDelay              300     // Under Frequency Trip Delay i.e XXX*10 ms 300x10 ms  = 3 seconds 
#define UnderFreqResetTimeDelay         200     // Under Frequency Reset Delay i.e XXX*10 ms 200x10 ms  = 2 seconds 
#define LEDBlinkDefaultTimeDelay        100     // No Fault is 1 Second
#define LEDBlinkNoInput                 200     // No input LED blink Delay i.e xxx*10ms = 2 Seconds
#define LEDBlinkVoltageTimeDelay        50     // Over Voltage LED blink Delay i.e xxx*10ms = 0.5 Seconds
#define LEDBlinkFreqTimeDelay           20     // Under Frequency LED blink Delay i.e xxx*10ms = 0.2 Seconds
#define FreqCaptureFailureTimeDelay     20      // Frequency Capture interrupt time Delay i.e xxx*10ms = 0.2 Seconds
#define FreqSampleCount                 5      // No. of Samples frequency
#define MaximumFrequency                400     // Maxium input Frequency 400Hz

#define VoltageTripRelay          GPIObits.GP5    //  GPIO Pin GP4 is defined as Voltage Trip Relay Output
#define FreqTripRelay             GPIObits.GP1    //  GPIO Pin GP5 is defined as Frequency Trip Relay output
#define LED                       GPIObits.GP0    //  GPIO Pin GP5 is defined as Status LED output



/*******************************************************************************/
/*                                                                             */ 
/*                              Function Declaration                           */
/*                                                                             */
/*******************************************************************************/
void System_Init(void);                 //  System Init function declaration
void Collect_ADC_Inputs(void);          //  ADC Signal samplinig function declaration
void Collect_Freq_Samples(void);        //  Collect 20 samples of frequency
void Check_Voltage(void);               //  Voltage checking function declaration ( OV & UV Check )
void Check_Frequency(void);               //  Frequency checking function declaration (Lower Freq)
void Process_Control_Output(void);      //  Output processing function ( Relay & LED output )
void LED_Blink(void);                   // LED blink status


/*******************************************************************************/
/*                                                                             */ 
/*                              Global Variables Definition                    */
/*                                                                             */
/*******************************************************************************/

unsigned int AvgVoltage,Capture1=0,Capture2=0,i=0,Freq=0,j=0,k=0,a=0,b=0,TempFreq1=0,TempFreq2=0;
float Period=0;
unsigned int OverVoltageTick=0;
unsigned int UnderFreqTick=0;
unsigned int UnderFreqResetTick=0;
unsigned int LEDBlinkTick=0;
unsigned int FreqCaptureFailureTick=0;
bit OverVoltageFlag;
bit UnderFreqFlag;
bit UnderFreqResetFlag;
bit VoltageTripRelayFlag;
bit FreqTripRelayFlag;
bit InputFailureFlag;
bit ADCFailureFlag;
bit FreqFailureFlag;

/*******************************************************************************/
/*                                                                             */ 
/*                              Main Function Start                            */
/*                                                                             */
/*******************************************************************************/
void main(void) 
{
    System_Init();   
    for( ; ; )
    {                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             
        Collect_ADC_Inputs();
        Collect_Freq_Samples();
        Check_Voltage();
        Check_Frequency();
        Process_Control_Output();
        LED_Blink();
        CLRWDT();                   // Reset the Watchdog timer
    }
}
/****************************** Main Function END   ********************************/


/*******************************************************************************/
/*                              System Initialization                          */
/*******************************************************************************/

void System_Init(void)
{
/******************* Internal Oscillator Setting *******************************/  
    
    OSCCONbits.IRCF0 = 0;           //  
    OSCCONbits.IRCF1 = 1;           //  Internal Oscillator configured to 4 MHz
    OSCCONbits.IRCF2 = 1;           //
    OSCCONbits.SCS   = 1;           //  
    //OSCTUNE = 0x00;
    
/*********************** GPIO Port Setting *************************************/
    
    TRISIObits.TRISIO0 = 0;         //  GPIO0 is set as Output (LED))
    TRISIObits.TRISIO1 = 0;         //  GPIO1 is set as Output (Frequency Trip Relay)
    TRISIObits.TRISIO2 = 1;         //  GPIO2 is set as Input (Frequency Read)
    TRISIObits.TRISIO4 = 1;         //  GPIO4 is set as Input (Voltage_ADC)
    TRISIObits.TRISIO5 = 0;         //  GPIO5 is set as Output (Trip relay for Voltage)
    
    ANSELbits.ANS0 = 0;             //  ADC Channel-0 is disabled
    ANSELbits.ANS1 = 0;             //  ADC Channel-1 is disabled
    ANSELbits.ANS2 = 0;             //  ADC Channel-2 is disabled
    ANSELbits.ANS3 = 1;             //  ADC Channel-3 is enabled

/*********************** Unused Peripheral Masking *****************************/
    
    WPU = 0x00;                     //  Internal Pull-ups disabled
    IOC = 0x00;                     //  Interrupt ON Change disabled
    CMCON0 = 0x07;                  //  Comparator disabled    
    CCP1CON = 0x05;                 //  Capture module is enabled for every Rising edge
    PCONbits.ULPWUE = 0;            //  Ultra low power wakeup disabled

/*********************** Timer-0 Assigned as WDT   *****************************/   
    
    OPTION_REG = 0x8F;              //  Timer-0 assigned to WDT 
    CLRWDT();                   // Reset the Watchdog timer
    
/*********************** Timer-1 Configuration for Capture ********************/    
    
    T1CONbits.TMR1CS = 0;           //  Timer-1 Clock source selection (FOSC)
    T1CONbits.nT1SYNC = 1;          //  Timer-1 Sync disabled
    T1CONbits.T1OSCEN = 0;          //  LP osc. Disabled
    T1CONbits.T1CKPS0 = 0;          //  1:4 Prescalar 
    T1CONbits.T1CKPS1 = 1;          //  
    T1CONbits.TMR1GE = 0;           //
    T1CONbits.TMR1ON = 1;           //  Timer-1 ON
    TMR1H = 0;                      // Clear the Timer register
    TMR1L = 0;
/*********************** Timer-2 Configuration for 10ms Tick ********************/  
    
    //Timer2 Registers Prescaler= 16 - TMR2 PostScaler = 8 - PR2 = 79 - Freq = 98.89 Hz - Period = 0.010112 seconds
    T2CON |= 56;                     // bits 6-3 Post scaler 1:1 thru 1:16
    T2CONbits.TMR2ON = 1;            // bit 2 turn timer2 on;
    T2CONbits.T2CKPS1 = 1;          // bits 1-0  Prescaler Rate Select bits
    T2CONbits.T2CKPS0 = 0;
    PR2 = 76;                       // PR2 (Timer2 Match value)
/*********************** Interrupt Configuration   *****************************/    
    
    INTCONbits.GIE = 1;             //  Global Interrupts enabled
    INTCONbits.PEIE = 1;            //  Peripheral interrupts enabled
    INTCONbits.T0IE = 0;            //  Timer-0 interrupt disabled
    INTCONbits.INTE = 0;            //  External Interrupt disabled
    INTCONbits.GPIE = 0;            //  GPIO Change Interrupt disabled
    PIE1bits.TMR2IE = 1;           // enable Timer2 interrupts
    PIE1bits.CCP1IE = 1;            //  Capture mode interrupt enabled
    CCP1IF = 0;
    
/*********************** ADC Configuration   *****************************/    
    
    ADCON0 = 0x8D;                  //  ADC Register configuration
    ADCON0bits.VCFG = 0;            //  ADC Reference is connected to VCC
    ANSELbits.ADCS0 = 1;            //  16bit Resolution
    ANSELbits.ADCS1 = 0;
    ANSELbits.ADCS2 = 1;
    
/*********************  OUTPUT and Flags ************************************/    
    VoltageTripRelay = 0;
    FreqTripRelay = 0;
    LED = 0;
    VoltageTripRelayFlag = 0;
    InputFailureFlag = 0;   
}
/*******************************************************************************/
/*                                                                             */ 
/*                              Interrupt Function                             */
/*                                                                             */
/*******************************************************************************/
void interrupt isr(void)
{
    if(CCP1IF)
    {
        CCP1IF = 0;
        FreqCaptureFailureTick=0;
        if(i==1)
        {
            Capture1 = ((256 * CCPR1H) + CCPR1L );
            i++;
        }
        else if(i==2)
        {
            Capture2 = ((256 * CCPR1H) + CCPR1L );
            Period = Capture2 - Capture1;
            i=1;
            TMR1H = TMR1L = 0;
        }
        else { i++; }
        
    }
    if(TMR2IF)
    {
        TMR2IF = 0;
        LEDBlinkTick++;
        FreqCaptureFailureTick++;
        if(OverVoltageFlag) { OverVoltageTick++; }
        if(UnderFreqFlag) { UnderFreqTick++; }
        if(UnderFreqResetFlag) { UnderFreqResetTick++; }
    }
    

}
/*******************************************************************************/
/*                                                                             */ 
/*                       FREQUENCY Sampling                                   */
/*                                                                             */
/*******************************************************************************/
void Collect_Freq_Samples()
{
    Period = ((4000000)/(4*4*Period));
    TempFreq1   = (unsigned int) (Period);
    TempFreq2 += TempFreq1;
    a++;
    if(a == FreqSampleCount)
    {
        Freq = TempFreq2/FreqSampleCount;
        TempFreq2 = 0;
        a=0;
    }
}
/*******************************************************************************/
/*                                                                             */ 
/*                       ADC Signal Sampling                                   */
/*                                                                             */
/*******************************************************************************/

void Collect_ADC_Inputs(void)
{
    long int TempVoltage = 0;
    unsigned char t;
    
    for(t = 0; t < 100; t++)
    {
        ADCON0 = 0x8D;                          //  ADC Channel-3 Selection Voltage Input
        __delay_us(10);
        ADCON0bits.GO_DONE = 1;                 //  ADC Conversion ON set
        while(ADCON0bits.GO_DONE);              //  Waiting for ADC Conversion to complete
        TempVoltage += ADRESH*256+ADRESL;       //  Collecting the ADC values ( 0-1024)
    }
    AvgVoltage = TempVoltage/100;               //  Average Voltage calculation
}

/*******************************************************************************/
/*                                                                             */ 
/*                         Voltage Protection Function                         */
/*                                                                             */
/*******************************************************************************/

void Check_Voltage(void)
{
    if(AvgVoltage >= 532)           // 1023/5=204.6== 204.6*2.6= 531.92==532
    {
        OverVoltageFlag = 1;   
    }
    else
    {
        OverVoltageFlag = 0;
        OverVoltageTick = 0;
    }
    if(AvgVoltage <=0)
    {
        ADCFailureFlag = 1;
    }
    else
    {           
        ADCFailureFlag = 0;
    }
}



/*******************************************************************************/
/*                           Frequency Calculation and checking                */
/*******************************************************************************/
void Check_Frequency(void)
{
    
    if(Freq <= UnderFreqLimit)
    {
        UnderFreqFlag = 1;
        UnderFreqResetFlag = 0;
        UnderFreqResetTick = 0;
    }
    if(Freq >= UnderFreqResetLimit)
    {
        UnderFreqResetFlag = 1;
        UnderFreqFlag = 0;
        UnderFreqTick = 0;
    }
    if(FreqCaptureFailureTick >= FreqCaptureFailureTimeDelay)
    {
        FreqFailureFlag = 1;
    }
    else 
    {
        FreqFailureFlag = 0;
    }  
}

/*******************************************************************************/
/*                                                                             */ 
/*                         Control Output Processing                           */
/*                                                                             */
/*******************************************************************************/

void Process_Control_Output(void)
{
    if(OverVoltageFlag && (OverVoltageTick >= OverVoltageTimeDelay))
    {
        VoltageTripRelay = 1;
        VoltageTripRelayFlag = 1;
    }
    else
    {
        VoltageTripRelay = 0;
        VoltageTripRelayFlag = 0;
        
    }
    
    if(UnderFreqFlag && (UnderFreqTick >= UnderFreqTimeDelay))
    {
        FreqTripRelay = 1;
        FreqTripRelayFlag = 1;
    }
    if(UnderFreqResetFlag && (UnderFreqResetTick >= UnderFreqResetTimeDelay))
    {
        FreqTripRelay = 0;
        FreqTripRelayFlag = 0;
    }
    if(ADCFailureFlag || FreqFailureFlag)           // input Failure 
    {
        InputFailureFlag = 1;
    }
    else 
    {
        InputFailureFlag = 0;
    }
}
/*******************************************************************************/
/*                                                                             */ 
/*                         STATUS LED PROCESSING                               */
/*                                                                             */
/*******************************************************************************/
void LED_Blink(void)
{
    if(VoltageTripRelayFlag && (LEDBlinkTick >= LEDBlinkVoltageTimeDelay) && !InputFailureFlag)          // Voltage Relay after Tick
    {
        LED = ~LED;
        LEDBlinkTick = 0;
    }
    if(FreqTripRelayFlag && (LEDBlinkTick >= LEDBlinkFreqTimeDelay) && !InputFailureFlag)                // Frequency Relay after Tick
    {
        LED = ~LED;
        LEDBlinkTick = 0;
    }
    if(!FreqTripRelayFlag && !VoltageTripRelayFlag && (LEDBlinkTick >= LEDBlinkDefaultTimeDelay) && !InputFailureFlag)   // Default time tick
    {
        LED = ~LED;
        LEDBlinkTick = 0;
    }
    if(InputFailureFlag && (LEDBlinkTick >= LEDBlinkNoInput))            // Input failure delay
    {
        LED = ~LED;
        LEDBlinkTick = 0;
    }
}


///*************************************************************************************************
//*  PURPOSE      : AVR Monitoring System                                                          *
//*  DEVELOPED BY : Prabhu R                                                                       *
//*  STARTED ON   : 15-05-2017                                                                     *
//*  VERSION      : V1.1                                                                           *
//*  Language     : C Programming                                                                  *
//*  Controller   : PIC12F683(8 Bit)                                                               *
//*                                                                                                *                  
//**************************************************************************************************
//
//********************************************************************************
//* HARDWARE *         * PORT ALLOCATION  *                                      *
//********************************************************************************
//------------------------------------|
//PIN |GPIO  	 |Port Allocate         |
//----|--------|----------------------|
//1	|-		 | VDD (+5V)            |
//2	|5		 | Voltage Trip Relay   |
//3	|4		 | ADC Input            |
//4	|3		 | MCLR                 |
//5	|2   	 | Frequency Count      |
//6	|1   	 | Frequency trip Relay |
//7	|0		 | Status LED           |
//8	|-		 | VSS                  |
//------------------------------------|
// */
//
///*******************************************************************************/
///*                                                                             */ 
///*                              Include Files                                  */
///*                                                                             */
///*******************************************************************************/
//
//#include <xc.h>
//#include <stdint.h>
//
//// #pragma config statements should precede project file includes.
//// Use project enums instead of #define for ON and OFF.
//
///*******************************************************************************/
///*                                                                             */ 
///*                              Configuration                                  */
///*                                                                             */
///*******************************************************************************/
//
//#pragma config FOSC = INTOSCIO  // Oscillator Selection bits (INTOSCIO oscillator: I/O function on RA4/OSC2/CLKOUT pin, I/O function on RA5/OSC1/CLKIN)
//#pragma config WDTE = ON        // Watchdog Timer Enable bit (WDT enabled)
//#pragma config PWRTE = ON       // Power-up Timer Enable bit (PWRT enabled)
//#pragma config MCLRE = ON       // MCLR Pin Function Select bit (MCLR pin function is MCLR)
//#pragma config CP = OFF         // Code Protection bit (Program memory code protection is disabled)
//#pragma config CPD = OFF        // Data Code Protection bit (Data memory code protection is disabled)
//#pragma config BOREN = ON       // Brown Out Detect (BOR enabled)
//#pragma config IESO = OFF       // Internal External Switchover bit (Internal External Switchover mode is disabled)
//#pragma config FCMEN = OFF      // Fail-Safe Clock Monitor Enabled bit (Fail-Safe Clock Monitor is disabled)
//
///*******************************************************************************/
///*                                                                             */ 
///*                              Crystal Oscillator                             */
///*                                                                             */
///*******************************************************************************/
//
//#define _XTAL_FREQ 4000000
//
///*******************************************************************************/
///*                                                                             */ 
///*                              Limit Values Definition                        */
///*                                                                             */
///*******************************************************************************/
//#define UnderFreqLimit                  370     // Over Frequency Limit
//#define UnderFreqResetLimit             380     // Over Frequency Reset Limit
//#define OverVoltageTimeDelay            300     // Over Voltage Trip Delay i.e XXX*10 ms 300x10 ms  = 3 seconds  
//#define UnderFreqTimeDelay              300     // Under Frequency Trip Delay i.e XXX*10 ms 300x10 ms  = 3 seconds 
//#define UnderFreqResetTimeDelay         300     // Under Frequency Reset Delay i.e XXX*10 ms 200x10 ms  = 2 seconds 
//#define LEDBlinkDefaultTimeDelay        100     // No Fault is 1 Second
//#define LEDBlinkNoInput                 200     // No input LED blink Delay i.e xxx*10ms = 2 Seconds
//#define LEDBlinkVoltageTimeDelay        50     // Over Voltage LED blink Delay i.e xxx*10ms = 0.5 Seconds
//#define LEDBlinkFreqTimeDelay           20     // Under Frequency LED blink Delay i.e xxx*10ms = 0.2 Seconds
//#define FreqCaptureFailureTimeDelay     20      // Frequency Capture interrupt time Delay i.e xxx*10ms = 0.2 Seconds
//#define FreqSampleCount                 20      // No. of Samples frequency
//#define MaximumFrequency                400     // Maxium input Frequency 400Hz
//
//#define VoltageTripRelay          GPIObits.GP5    //  GPIO Pin GP4 is defined as Voltage Trip Relay Output
//#define FreqTripRelay             GPIObits.GP1    //  GPIO Pin GP5 is defined as Frequency Trip Relay output
//#define LED                       GPIObits.GP0    //  GPIO Pin GP5 is defined as Status LED output
//
//
//
///*******************************************************************************/
///*                                                                             */ 
///*                              Function Declaration                           */
///*                                                                             */
///*******************************************************************************/
//void System_Init(void);                 //  System Init function declaration
//void Collect_ADC_Inputs(void);          //  ADC Signal samplinig function declaration
//void Collect_Freq_Samples(void);        //  Collect 20 samples of frequency
//void Check_Voltage(void);               //  Voltage checking function declaration ( OV & UV Check )
//void Check_Frequency(void);               //  Frequency checking function declaration (Lower Freq)
//void Process_Control_Output(void);      //  Output processing function ( Relay & LED output )
//void LED_Blink(void);                   // LED blink status
//
//
///*******************************************************************************/
///*                                                                             */ 
///*                              Global Variables Definition                    */
///*                                                                             */
///*******************************************************************************/
//
//unsigned int AvgVoltage,Capture1=0,Capture2=0,i=0,Freq=0,j=0,k=0,a=0,b=0,TempFreq1=0,TempFreq2=0,Period_int=0;
//float Period=0;
//unsigned int OverVoltageTick=0;
//unsigned int UnderFreqTick=0;
//unsigned int UnderFreqResetTick=0;
//unsigned int LEDBlinkTick=0;
//unsigned int FreqCaptureFailureTick=0;
//bit OverVoltageFlag;
//bit UnderFreqFlag;
//bit UnderFreqResetFlag;
//bit VoltageTripRelayFlag;
//bit FreqTripRelayFlag;
//bit InputFailureFlag;
//bit ADCFailureFlag;
//bit FreqFailureFlag;
//
///*******************************************************************************/
///*                                                                             */ 
///*                              Main Function Start                            */
///*                                                                             */
///*******************************************************************************/
//void main(void) 
//{
//    System_Init();   
//    for( ; ; )
//    {                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             
//        Collect_ADC_Inputs();
//        Collect_Freq_Samples();
//        Check_Voltage();
//        Check_Frequency();
//        Process_Control_Output();
//        LED_Blink();
//        CLRWDT();                   // Reset the Watchdog timer
//    }
//}
///****************************** Main Function END   ********************************/
//
//
///*******************************************************************************/
///*                              System Initialization                          */
///*******************************************************************************/
//
//void System_Init(void)
//{
///******************* Internal Oscillator Setting *******************************/  
//    
//    OSCCONbits.IRCF0 = 0;           //  
//    OSCCONbits.IRCF1 = 1;           //  Internal Oscillator configured to 4 MHz
//    OSCCONbits.IRCF2 = 1;           //
//    OSCCONbits.SCS   = 1;           //  
//    //OSCTUNE = 0x00;
//    
///*********************** GPIO Port Setting *************************************/
//    
//    TRISIObits.TRISIO0 = 0;         //  GPIO0 is set as Output (LED))
//    TRISIObits.TRISIO1 = 0;         //  GPIO1 is set as Output (Frequency Trip Relay)
//    TRISIObits.TRISIO2 = 1;         //  GPIO2 is set as Input (Frequency Read)
//    TRISIObits.TRISIO4 = 1;         //  GPIO4 is set as Input (Voltage_ADC)
//    TRISIObits.TRISIO5 = 0;         //  GPIO5 is set as Output (Trip relay for Voltage)
//    
//    ANSELbits.ANS0 = 0;             //  ADC Channel-0 is disabled
//    ANSELbits.ANS1 = 0;             //  ADC Channel-1 is disabled
//    ANSELbits.ANS2 = 0;             //  ADC Channel-2 is disabled
//    ANSELbits.ANS3 = 1;             //  ADC Channel-3 is enabled
//
///*********************** Unused Peripheral Masking *****************************/
//    
//    WPU = 0x00;                     //  Internal Pull-ups disabled
//    IOC = 0x00;                     //  Interrupt ON Change disabled
//    CMCON0 = 0x07;                  //  Comparator disabled    
//    CCP1CON = 0x05;                 //  Capture module is enabled for every Rising edge
//    PCONbits.ULPWUE = 0;            //  Ultra low power wakeup disabled
//
///*********************** Timer-0 Assigned as WDT   *****************************/   
//    
//    OPTION_REG = 0x8F;              //  Timer-0 assigned to WDT 
//    CLRWDT();                   // Reset the Watchdog timer
//    
///*********************** Timer-1 Configuration for Capture ********************/    
//    
//    T1CONbits.TMR1CS = 0;           //  Timer-1 Clock source selection (FOSC)
//    T1CONbits.nT1SYNC = 1;          //  Timer-1 Sync disabled
//    T1CONbits.T1OSCEN = 0;          //  LP osc. Disabled
//    T1CONbits.T1CKPS0 = 0;          //  1:4 Prescalar 
//    T1CONbits.T1CKPS1 = 1;          //  
//    T1CONbits.TMR1GE = 0;           //
//    T1CONbits.TMR1ON = 1;           //  Timer-1 ON
//    TMR1H = 0;                      // Clear the Timer register
//    TMR1L = 0;
///*********************** Timer-2 Configuration for 10ms Tick ********************/  
//    
//    //Timer2 Registers Prescaler= 16 - TMR2 PostScaler = 8 - PR2 = 79 - Freq = 98.89 Hz - Period = 0.010112 seconds
//    T2CON |= 56;                     // bits 6-3 Post scaler 1:1 thru 1:16
//    T2CONbits.TMR2ON = 1;            // bit 2 turn timer2 on;
//    T2CONbits.T2CKPS1 = 1;          // bits 1-0  Prescaler Rate Select bits
//    T2CONbits.T2CKPS0 = 0;
//    PR2 = 76;                       // PR2 (Timer2 Match value)
///*********************** Interrupt Configuration   *****************************/    
//    
//    INTCONbits.GIE = 1;             //  Global Interrupts enabled
//    INTCONbits.PEIE = 1;            //  Peripheral interrupts enabled
//    INTCONbits.T0IE = 0;            //  Timer-0 interrupt disabled
//    INTCONbits.INTE = 0;            //  External Interrupt disabled
//    INTCONbits.GPIE = 0;            //  GPIO Change Interrupt disabled
//    PIE1bits.TMR2IE = 1;           // enable Timer2 interrupts
//    PIE1bits.CCP1IE = 1;            //  Capture mode interrupt enabled
//    CCP1IF = 0;
//    
///*********************** ADC Configuration   *****************************/    
//    
//    ADCON0 = 0x8D;                  //  ADC Register configuration
//    ADCON0bits.VCFG = 0;            //  ADC Reference is connected to VCC
//    ANSELbits.ADCS0 = 1;            //  16bit Resolution
//    ANSELbits.ADCS1 = 0;
//    ANSELbits.ADCS2 = 1;
//    
///*********************  OUTPUT and Flags ************************************/    
//    VoltageTripRelay = 0;
//    FreqTripRelay = 0;
//    LED = 0;
//    VoltageTripRelayFlag = 0;
//    InputFailureFlag = 0;   
//}
///*******************************************************************************/
///*                                                                             */ 
///*                              Interrupt Function                             */
///*                                                                             */
///*******************************************************************************/
//void interrupt isr(void)
//{
//    if(CCP1IF)
//    {
//        CCP1IF = 0;
//        FreqCaptureFailureTick=0;
//        if(i==1)
//        {
//            Capture1 = ((256 * CCPR1H) + CCPR1L );
//            i++;
//        }
//        else if(i==2)
//        {
//            Capture2 = ((256 * CCPR1H) + CCPR1L );
//            Period_int = Capture2 - Capture1;
//            i=1;
//            TMR1H = TMR1L = 0;
//        }
//        else { i++; }
//        
//    }
//    if(TMR2IF)
//    {
//        TMR2IF = 0;
//        LEDBlinkTick++;
//        FreqCaptureFailureTick++;
//        if(OverVoltageFlag) { OverVoltageTick++; }
//        if(UnderFreqFlag) { UnderFreqTick++; }
//        if(UnderFreqResetFlag) { UnderFreqResetTick++; }
//    }
//    
//
//}
///*******************************************************************************/
///*                                                                             */ 
///*                       FREQUENCY Sampling                                   */
///*                                                                             */
///*******************************************************************************/
//void Collect_Freq_Samples()
//{
//    Period = ((4000000)/(4*4*Period_int));
//    Freq   = (unsigned int) (Period);
//   // TempFreq1   = (unsigned int) (Period);
//    //TempFreq2 += TempFreq1;
//    
////    a++;
////    if(a == FreqSampleCount)
////    {
////        Freq = TempFreq2/FreqSampleCount;
////        TempFreq2 = 0;
////        a=0;
////    }
//    
////    for(j=1; j<=FreqSampleCount; j++)
////    {
////        Period = ((4000000)/(4*4*Period_int));
////        TempFreq1   = (unsigned int) (Period);
////        TempFreq2 += TempFreq1;
////        __delay_ms(1);
////    }
////    Freq = TempFreq2/FreqSampleCount;
////    TempFreq2 = 0;
//}
///*******************************************************************************/
///*                                                                             */ 
///*                       ADC Signal Sampling                                   */
///*                                                                             */
///*******************************************************************************/
//
//void Collect_ADC_Inputs(void)
//{
//    long int TempVoltage = 0;
//    unsigned char t;
//    
//    for(t = 0; t < 100; t++)
//    {
//        ADCON0 = 0x8D;                          //  ADC Channel-3 Selection Voltage Input
//        __delay_us(10);
//        ADCON0bits.GO_DONE = 1;                 //  ADC Conversion ON set
//        while(ADCON0bits.GO_DONE);              //  Waiting for ADC Conversion to complete
//        TempVoltage += ADRESH*256+ADRESL;       //  Collecting the ADC values ( 0-1024)
//    }
//    AvgVoltage = TempVoltage/100;               //  Average Voltage calculation
//}
//
///*******************************************************************************/
///*                                                                             */ 
///*                         Voltage Protection Function                         */
///*                                                                             */
///*******************************************************************************/
//
//void Check_Voltage(void)
//{
//    if(AvgVoltage >= 532)           // 1023/5=204.6== 204.6*2.6= 531.92==532
//    {
//        OverVoltageFlag = 1;   
//    }
//    else
//    {
//        OverVoltageFlag = 0;
//        OverVoltageTick = 0;
//    }
//    if(AvgVoltage <=0)
//    {
//        ADCFailureFlag = 1;
//    }
//    else
//    {           
//        ADCFailureFlag = 0;
//    }
//}
//
//
//
///*******************************************************************************/
///*                           Frequency Calculation and checking                */
///*******************************************************************************/
//void Check_Frequency(void)
//{
//    
//    if(Freq <= UnderFreqLimit)
//    {
//        UnderFreqFlag = 1;
//        UnderFreqResetFlag = 0;
//        UnderFreqResetTick = 0;
//    }
//    if(Freq >= UnderFreqResetLimit)
//    {
//        UnderFreqResetFlag = 1;
//        UnderFreqFlag = 0;
//        UnderFreqTick = 0;
//    }
//    if(FreqCaptureFailureTick >= FreqCaptureFailureTimeDelay)
//    {
//        FreqFailureFlag = 1;
//    }
//    else 
//    {
//        FreqFailureFlag = 0;
//    }  
//}
//
///*******************************************************************************/
///*                                                                             */ 
///*                         Control Output Processing                           */
///*                                                                             */
///*******************************************************************************/
//
//void Process_Control_Output(void)
//{
//    if(OverVoltageFlag && (OverVoltageTick >= OverVoltageTimeDelay))
//    {
//        VoltageTripRelay = 1;
//        VoltageTripRelayFlag = 1;
//    }
//    else
//    {
//        VoltageTripRelay = 0;
//        VoltageTripRelayFlag = 0;
//        
//    }
//    
//    if(UnderFreqFlag && (UnderFreqTick >= UnderFreqTimeDelay))
//    {
//        FreqTripRelay = 1;
//        FreqTripRelayFlag = 1;
//    }
//    if(UnderFreqResetFlag && (UnderFreqResetTick >= UnderFreqResetTimeDelay))
//    {
//        FreqTripRelay = 0;
//        FreqTripRelayFlag = 0;
//    }
//    if(ADCFailureFlag || FreqFailureFlag)           // input Failure 
//    {
//        InputFailureFlag = 1;
//    }
//    else 
//    {
//        InputFailureFlag = 0;
//    }
//}
///*******************************************************************************/
///*                                                                             */ 
///*                         STATUS LED PROCESSING                               */
///*                                                                             */
///*******************************************************************************/
//void LED_Blink(void)
//{
//    if(VoltageTripRelayFlag && (LEDBlinkTick >= LEDBlinkVoltageTimeDelay) && !InputFailureFlag)          // Voltage Relay after Tick
//    {
//        LED = ~LED;
//        LEDBlinkTick = 0;
//    }
//    if(FreqTripRelayFlag && (LEDBlinkTick >= LEDBlinkFreqTimeDelay) && !InputFailureFlag)                // Frequency Relay after Tick
//    {
//        LED = ~LED;
//        LEDBlinkTick = 0;
//    }
//    if(!FreqTripRelayFlag && !VoltageTripRelayFlag && (LEDBlinkTick >= LEDBlinkDefaultTimeDelay) && !InputFailureFlag)   // Default time tick
//    {
//        LED = ~LED;
//        LEDBlinkTick = 0;
//    }
//    if(InputFailureFlag && (LEDBlinkTick >= LEDBlinkNoInput))            // Input failure delay
//    {
//        LED = ~LED;
//        LEDBlinkTick = 0;
//    }
//}
