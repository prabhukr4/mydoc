#include <avr/io.h>
#include<util/delay.h>
#define FCPU 4e6

#define DIN1	(PORTA_IN & 0x10)?1:0
#define DIN2	(PORTA_IN & 0x08)?1:0
#define DIN3	(PORTA_IN & 0x04)?1:0
#define DIN4	(PORTA_IN & 0x02)?1:0

void System_init(void);
int main(void)
{
	System_init();	
    while(1)
    {
		if(!DIN4)
		{
			PORTE_OUTCLR = 0x02; or PORTE_OUT &= ~(0x02);
		}
		else
		{
			PORTE_OUTSET = 0x02; or PORTE_OUT |= (0x02);
		}
		
    }
}

void System_init(void)
{
	PORTE_DIR = 0xFF;
	PORTA_DIR = 0x00;
	PORTE_OUT = 0x02;
}