#include <avr/io.h>
#include<util/delay.h>
#define FCPU 4e6
void System_init(void);
int main(void)
{
	System_init();	
    while(1)
    {
	PORTE_OUTTGL = 0x01;	// if need 1st oly toggle.
        _delay_ms(500);

		
    }
}

void System_init(void)
{
	PORTE_DIR = 0xFF;
	PORTE_OUT = 0x02;
}