#include <avr/io.h>
#include<util/delay.h>
#include "uart.h"
#define FCPU 4e6

#define StatusLED_ON	(PORTE_OUTCLR = 0x02)
#define StatusLED_OFF	(PORTE_OUTSET = 0x02)
#define StatusLED_TOGL	(PORTE_OUTTGL = 0x02)
#define RS485_Enable	(PORTE_OUTCLR = 0x04)		// Need to Clear the pin when before RS485 (check the Ciruit)
#define RS485_Disable	(PORTE_OUTSET = 0x04)		// Set after Communication done.
#define DAC1_REF_VCC	(PORTB_OUTSET = 0x04)		// Here instead of DAC im using VCC as reference of ADC

void System_init(void);
unsigned int i=0;
unsigned long int AvgVoltage=0;
int main()
{
	uart_init();
	System_init();
	RS485_Enable;
	DAC1_REF_VCC;
	while(1)
	{
		StatusLED_TOGL;
		for(i=0; i<500; i++)
		{
			ADCA_CTRLA		|=	0x08;			// Channel start the single conversion, after it will automatically reset
			ADCA_CH0_CTRL	 =	0x81;			// Start conversion and Single ended input
			while(!(ADCA_INTFLAGS & 0x01));		// Wait until conversion is complete
			AvgVoltage += ADCA_CH0_RES;			// Load the 12 bit value
		}
		_delay_ms(500);
		uart1_con_out("ADC COUNT ");
		AvgVoltage = AvgVoltage/500;			// get Average of 500 Samples
		htd4(AvgVoltage);
		uart1_out(0x0a);
		uart1_out(0x0d);
	}
	
}
void System_init(void)
{
/*-----------------------------------------------------------------------------------
								PORT DIRECTIONS				
-----------------------------------------------------------------------------------*/
	PORTA_DIR = 0x00;			// PORTA act as input
	PORTE_DIR = 0b00000110;		// PE1 is Status LED and PE2 is RS485 Enable both act as output
	PORTB_DIR = 0b00000100;		// PB2 as output, for ADC reference

/*-----------------------------------------------------------------------------------
								ADC Initialization				
-----------------------------------------------------------------------------------*/
	ADCA_CTRLA		= 0x01;		//DMA off,Conversion disable, Flush off
	ADCA_CTRLB		= 0x00;		//High impedance, Current NO limit, 12Bit
	ADCA_REFCTRL	= 0x20;		//PortA AREFA, No band gap, No temp. measurement
	ADCA_PRESCALER	= 0x03;		// Prescalar is DIV32
	
	ADCA_CH0_CTRL	= 0x00;		//Do not adc conversion, gain as 1
	ADCA_CH0_MUXCTRL= 0x28;		//Mux configured to Channel ADC5 (i.e.) PA5
	ADCA_CH0_INTCTRL= 0x00;		//interrupt When conversion is complete
	
}
