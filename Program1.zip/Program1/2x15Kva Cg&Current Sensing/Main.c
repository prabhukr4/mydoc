/*************************************************************************************************
*  PURPOSE      : TO DEVELOP A CONTROL SYSTEM FOR 2x15KVA DC Voltage and Current Sensing		 *
*  DEVELOPED BY : AnandKumar D                                                                   *
*  STARTED ON   : 27-01-2017                                                                     *
*  VERSION      : V1.0                                                                           *
*  Language     : C Programming                                                                  *
*  Controller   : PIC12F683(8 Bit)                                                               *
*                                                                                                *                  
**************************************************************************************************

********************************************************************************
* HARDWARE *         * PORT ALLOCATION  *                                      *
********************************************************************************
-----------------------------|
PIN |GPIO  	 |Port Allocate  |
----|--------|---------------|
1	|-		 | VDD (+5V)     |
2	|5		 | Status LED    |
3	|4		 | Trip Relay	 |
4	|3		 | MCLR          |
5	|2   	 | Reset Input   |
6	|1   	 | ADC 1(Current)|
7	|0		 | ADC 0(Voltage)|
8	|-		 | VSS           |
-----------------------------|
 */

/*******************************************************************************/
/*                                                                             */ 
/*                              Include Files                                  */
/*                                                                             */
/*******************************************************************************/

#include <xc.h>
#include <stdint.h>

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.

/*******************************************************************************/
/*                                                                             */ 
/*                              Configuration                                  */
/*                                                                             */
/*******************************************************************************/

#pragma config FOSC = INTOSCIO  // Oscillator Selection bits (INTOSCIO oscillator: I/O function on RA4/OSC2/CLKOUT pin, I/O function on RA5/OSC1/CLKIN)
#pragma config WDTE = ON        // Watchdog Timer Enable bit (WDT enabled)
#pragma config PWRTE = ON       // Power-up Timer Enable bit (PWRT enabled)
#pragma config MCLRE = ON       // MCLR Pin Function Select bit (MCLR pin function is MCLR)
#pragma config CP = OFF         // Code Protection bit (Program memory code protection is disabled)
#pragma config CPD = OFF        // Data Code Protection bit (Data memory code protection is disabled)
#pragma config BOREN = ON       // Brown Out Detect (BOR enabled)
#pragma config IESO = OFF       // Internal External Switchover bit (Internal External Switchover mode is disabled)
#pragma config FCMEN = OFF      // Fail-Safe Clock Monitor Enabled bit (Fail-Safe Clock Monitor is disabled)

/*******************************************************************************/
/*                                                                             */ 
/*                              Crystal Oscillator                             */
/*                                                                             */
/*******************************************************************************/

#define _XTAL_FREQ 4000000

/*******************************************************************************/
/*                                                                             */ 
/*                              Limit Values Definition                        */
/*                                                                             */
/*******************************************************************************/
/*
#define OverVolatgeLimit        440     //  Over Voltage Trip Limit 
#define OverVoltageResetLimit   400     //  Over Voltage Reset Limit
#define UnderVoltageLimit       360     //  Under Voltage Trip Limit
#define UnderVoltageResetLimit  380     //  Under Voltage Reset Limit
#define OverCurentLimit         50      //  Over Current Trip Limit
#define UnderCurrentLimit       5       //  Under Curent Trip Limit
*/

#define OverVolatgeLimit        390     //  Over Voltage Trip Limit 
#define OverVoltageResetLimit   380     //  Over Voltage Reset Limit
#define UnderVoltageLimit       330     //  Under Voltage Trip Limit
#define UnderVoltageResetLimit  340     //  Under Voltage Reset Limit
#define OverCurentLimit         50      //  Over Current Trip Limit
#define UnderCurrentLimit       5       //  Under Curent Trip Limit

#define OverVoltageTripDelay    300     //  Over Voltage Trip Delay i.e XXX*10 ms 300x10 ms  = 3 seconds
#define UnderVolatgeTripDelay   300     //  Under Voltage Trip Delay i.e XXX*10 ms 300x10 ms  = 3 seconds 
#define OverCurrentTripDelay    300     //  Over Current Trip Delay i.e XXX*10 ms 300x10 ms  = 3 seconds 
#define UnderCurrentTripDelay   300     //  Under Current Trip Delay i.e XXX*10 ms 300x10 ms  = 3 seconds 

#define AutoResetTimeDelay      300     //  Fault Reset Delay (Only in Auto reset mode) i.e XXX*10 ms 300x10 ms  = 3 seconds
#define PowerONDelay            100     //  Power ON Start delay i.e XXX*10 ms 100x10 ms  = 1 second
#define ModeSelsectionDelay     300     //  Mode Selection delay i.e XXX*10 ms 300x10 ms  = 3 seconds
#define InputDebounceDelay      10      //  Indpu Signal debounce delay i.e XXX*10 ms 10x10 ms  = 100ms

#define MaxDisplayVolatge       500     //  Maximum Voltage value for display and internal actual voltage calculation
#define MaxDisplayCurrent       100     //  Maximum Current value for display and internal actual voltage calculation

#define ResetInput              GPIObits.GP2    //  GPIO Pin GP2 is defined as Reset input
#define TripRelay               GPIObits.GP4    //  GPIO Pin GP4 is defined as Trip Relay Output
#define StatusLED               GPIObits.GP5    //  GPIO Pin GP5 is defined as Status LED output



/*******************************************************************************/
/*                                                                             */ 
/*                              Function Declaration                           */
/*                                                                             */
/*******************************************************************************/

void interrupt isr(void);               //  Interrup function declaration
void System_Init(void);                 //  System Init function declaration
void Collect_ADC_Inputs(void);          //  ADC Signal samplinig function declaration
void Check_Voltage(void);               //  Voltage checking function declaration ( OV & UV Check )
void Check_Current(void);               //  Current checking function declarartin ( OC & UC check )
void Process_Control_Output(void);      //  Output processing function ( Relay & LED output )
void Collect_Digital_Inputs(void);      //  Check the Key inouts ( here Reset input)
void BlinkLED(void);                    //  Status LED blinking under various conditions


/*******************************************************************************/
/*                                                                             */ 
/*                              Global Variables Definition                    */
/*                                                                             */
/*******************************************************************************/

unsigned int AvgVoltage;
unsigned int AvgCurrent;
unsigned int OverVoltageTick;
unsigned int UnderVoltageTick;
unsigned int OverCurrentTick;
//unsigned int UnderCurrentTick;
unsigned int AutoResetTick;
unsigned int ModeSelectionTick;
unsigned char DebounceDelayTick;
unsigned char LEDBlinkTick;


bit OverVoltageFlag;
bit UnderVoltageFlag;
bit OverCurrentFlag;
//bit UnderCurrentFlag;
bit TripRelayFlag;
bit AutoResetFlag;
bit PowerONFlag;
bit AutoModeFlag;
bit ManualResetFlag;
bit ManualResetInput;


/*******************************************************************************/
/*                                                                             */ 
/*                              Main Function Start                            */
/*                                                                             */
/*******************************************************************************/

void main(void) 
{
    System_Init();
    
    TripRelay = 0;
    StatusLED = 1;
    
    TripRelayFlag = 1;
    PowerONFlag   = 1;
    AutoResetFlag = 0;
    ManualResetFlag = 0;
    
    for( ; ; )
    {
        Collect_Digital_Inputs();                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  
        Collect_ADC_Inputs();
        Check_Voltage();
        Check_Current();
        Process_Control_Output();
        BlinkLED();
    
        CLRWDT();
    }
}
/****************************** Main Function END   ********************************/


/*******************************************************************************/
/*                                                                             */ 
/*                              Interrupt Function                             */
/*                                                                             */
/*******************************************************************************/

void interrupt isr(void)
{
    static uint8_t i;

	if(TMR1IF)
	{
		TMR1IF = 0;						// interrupt for every 10msec
        TMR1H = 216;
        TMR1L = 242;
        
		i++;
        LEDBlinkTick++;
        
		if( i >= 100)
		{
            i = 0;
        }
        
        if(OverVoltageFlag)
            OverVoltageTick++;
        else OverVoltageTick = 0;
        
        if(UnderVoltageFlag)
            UnderVoltageTick++;
        else UnderVoltageTick = 0;
        
        if(OverCurrentFlag)
            OverCurrentTick++;
        else OverCurrentTick = 0;
        
//        if(UnderCurrentFlag)
//            UnderCurrentTick++;
//        else UnderCurrentTick = 0;
        
        if(AutoResetFlag)
            AutoResetTick++;
        else AutoResetTick = 0;
        
        if(!ResetInput && !AutoModeFlag)
        {
            ModeSelectionTick++;
            DebounceDelayTick++;
            if(DebounceDelayTick > 200)
                DebounceDelayTick = 0;
        }
        else
        {
            ModeSelectionTick = 0;
            DebounceDelayTick = 0;
        }
    }
}


/*******************************************************************************/
/*                                                                             */ 
/*                              System Initialization                          */
/*                                                                             */
/*******************************************************************************/

void System_Init(void)
{
/******************* Internal Oscillator Setting *******************************/  
    
    OSCCONbits.IRCF0 = 0;           //  
    OSCCONbits.IRCF1 = 1;           //  Internal Oscillator configured to 4 MHz
    OSCCONbits.IRCF2 = 1;           //
    OSCCONbits.SCS   = 1;
    //OSCTUNE = 0x00;
    
/*********************** GPIO Port Setting *************************************/
    
    TRISIObits.TRISIO0 = 1;         //  GPIO0 is set as Input
    TRISIObits.TRISIO1 = 1;         //  GPIO1 is set as Input  
    TRISIObits.TRISIO2 = 1;         //  GPIO2 is set as Input
    TRISIObits.TRISIO4 = 0;         //  GPIO4 is set as Output
    TRISIObits.TRISIO5 = 0;         //  GPIO5 is set as Output
    
    ANSELbits.ANS0 = 1;             //  ADC Channel-1 is enabled
    ANSELbits.ANS1 = 1;             //  ADC Channel-2 is enabled
    ANSELbits.ANS2 = 0;             //  ADC Channel-3 is disabled
    ANSELbits.ANS3 = 0;             //  ADC Channel-4 is disabled

/*********************** Unused Peripheral Masking *****************************/
    
    WPU = 0x00;                     //  Internal Pull-ups disabled
    IOC = 0x00;                     //  Interrupt ON Change disabled
    CMCON0 = 0x07;                  //  Comparator disabled    
    CCP1CON = 0x00;                 //  CCP Module disabled
    PCONbits.ULPWUE = 0;            //  Ultra low power wakeup disabled

/*********************** Timer-0 Assigned as WDT   *****************************/   
    
    OPTION_REG = 0x8F;              //  Timer-0 assigned to WDT 
    
/*********************** Timer-1 Configuration for 10ms Tick ********************/    
    
    T1CONbits.TMR1CS = 0;           //  Timer-1 Clock source selection (FOSC)
    T1CONbits.nT1SYNC = 1;          //  Timer-1 Sync disabled
    T1CONbits.T1OSCEN = 0;          //  
    T1CONbits.T1CKPS0 = 0;          //
    T1CONbits.T1CKPS1 = 0;          //
    T1CONbits.TMR1GE = 0;           //
    T1CONbits.TMR1ON = 1;           //  Timer-1 ON
    TMR1H = 216;                    
    TMR1L = 242;
    
/*********************** Interrupt Configuration   *****************************/    
    
    INTCONbits.GIE = 1;             //  Global Interrupts enabled
    INTCONbits.PEIE = 1;            //  Peripheral interrupts enabled
    INTCONbits.T0IE = 0;            //  Timer-0 interrupt disabled
    INTCONbits.INTE = 0;            //  External Interrupt disabled
    INTCONbits.GPIE = 0;            //  GPIO Change Interrupt disabled
    PIE1bits.T1IE = 1;              //  Timer-1 Interrupt enabled
    
/*********************** ADC Configuration   *****************************/    
    
    ADCON0 = 0x81;                  //  ADC Register configuration
    ADCON0bits.VCFG = 0;            //  ADC Reference is connected to VCC
    ANSELbits.ADCS0 = 1;
    ANSELbits.ADCS1 = 0;
    ANSELbits.ADCS2 = 1;
}

/*******************************************************************************/
/*                                                                             */ 
/*                              Digital Inputs Scanning                        */
/*                                                                             */
/*******************************************************************************/

void Collect_Digital_Inputs(void)
{
    if(!ResetInput && (ModeSelectionTick > ModeSelsectionDelay) && !AutoModeFlag)    //  Auto Reset Mode set
    {
        AutoModeFlag = 1;
        ModeSelectionTick = 0;
    }
    else if(ResetInput)                                                            //  Manual Reset Mode set
        AutoModeFlag = 0;
    else
        NOP();
    
    if(!PowerONFlag && !AutoModeFlag && !ResetInput && ManualResetFlag && (DebounceDelayTick > InputDebounceDelay))  //  Manual reset input variable set
    {
        ManualResetInput = 1;
    }
    else 
        NOP();
}




/*******************************************************************************/
/*                                                                             */ 
/*                       ADC Signal Sampling                                   */
/*                                                                             */
/*******************************************************************************/

void Collect_ADC_Inputs(void)
{
    long int TempVoltage = 0,TempCurrent = 0;
    unsigned char i;
    
    for(i = 0; i < 100; i++)
    {
        ADCON0 = 0x81;                          //  ADC Channel-0 Selection     Voltage Input
        __delay_us(100);
        ADCON0bits.GO_DONE = 1;                 //  ADC Conversion ON set
        while(ADCON0bits.GO_DONE);              //  Waiting for ADC Conversion to complete
        TempVoltage += ADRESH*256+ADRESL;       //  Collecting the ADC values ( 0-1024)

        ADCON0 = 0x85;                          //  ADC Channel-1 Selection     Current Input
        __delay_us(100);
        ADCON0bits.GO_DONE = 1;                 //  ADC Conversion ON set 
        while(ADCON0bits.GO_DONE);              //  Waiting for ADC Conversion to complete
        TempCurrent += ADRESH*256+ADRESL;       //  Collecting the ADC values ( 0-1024)
    }
    AvgVoltage = TempVoltage/100;               //  Average Voltage calculation
    AvgCurrent = TempCurrent/100;               //  Average Current calculation
}



/*******************************************************************************/
/*                                                                             */ 
/*                         Voltage Protection Function                         */
/*                                                                             */
/*******************************************************************************/

void Check_Voltage(void)
{
    float TempVoltage = (AvgVoltage * 1.0) / 1024.0;
    AvgVoltage        = (unsigned int) (TempVoltage*MaxDisplayVolatge);
    
    if(AvgVoltage > OverVolatgeLimit)
        OverVoltageFlag = 1;
    else if(AvgVoltage < UnderVoltageLimit && !PowerONFlag)
        UnderVoltageFlag = 1;
    else
    {
        OverVoltageFlag = 0;
        UnderVoltageFlag = 0;
    }
    
    if((AvgVoltage > UnderVoltageResetLimit) && (AvgVoltage < OverVoltageResetLimit) && TripRelayFlag)
    {
        if(AutoModeFlag || PowerONFlag)
            AutoResetFlag =1;
        else
            ManualResetFlag = 1;
    }
    else
    {
        AutoResetFlag = 0;
        ManualResetFlag = 0;
    }
    
 /*   float TempVoltage = (AvgCurrent * 1.0) / 1024.0;
    AvgCurrent        = (unsigned int) (TempVoltage*MaxDisplayVolatge);
    
    if(AvgCurrent > OverVolatgeLimit)
        OverVoltageFlag = 1;
    else if(AvgCurrent < UnderVoltageLimit && !PowerONFlag)
        UnderVoltageFlag = 1;
    else
    {
        OverVoltageFlag = 0;
        UnderVoltageFlag = 0;
    }
    
    if((AvgCurrent > UnderVoltageResetLimit) && (AvgCurrent < OverVoltageResetLimit) && TripRelayFlag)
    {
        if(AutoModeFlag || PowerONFlag)
            AutoResetFlag =1;
        else
            ManualResetFlag = 1;
    }
    else
    {
        AutoResetFlag = 0;
        ManualResetFlag = 0;
    }*/

    
}


/*******************************************************************************/
/*                                                                             */ 
/*                         Current Protection Function                         */
/*                                                                             */
/*******************************************************************************/

void Check_Current(void)
{
    float TempCurrent = (AvgCurrent * 1.0) / 1024.0;
    AvgCurrent        = (unsigned int) (TempCurrent*MaxDisplayCurrent);
    
    if(AvgCurrent > OverCurentLimit)
        OverCurrentFlag = 1;
    //else if(AvgCurrent < UnderCurrentLimit)
    //    UnderCurrentFlag = 1;
    else
    {
        OverCurrentFlag = 0;
//        UnderCurrentFlag = 0;
//        if(TripRelayFlag)
//            AutoResetFlag = 1;
    }
    
    if(TripRelayFlag && AutoModeFlag)
        AutoResetFlag = 1;
    else
        NOP();
}



/*******************************************************************************/
/*                                                                             */ 
/*                         Control Output Processing                           */
/*                                                                             */
/*******************************************************************************/

void Process_Control_Output(void)
{
    if(OverVoltageFlag && (OverVoltageTick > OverVoltageTripDelay)&& !TripRelayFlag) //  && !TripRelayFlag
    {
        TripRelayFlag = 1;
        TripRelay     = 0;
    }
    else if(UnderVoltageFlag && !TripRelayFlag && (UnderVoltageTick > UnderVolatgeTripDelay))
    {
        TripRelayFlag = 1;
        TripRelay     = 0;
    }
    else
    {
        NOP();
    }
    
    if(OverCurrentFlag  && (OverCurrentTick > OverCurrentTripDelay)&& !TripRelayFlag) //&& !TripRelayFlag
    {
        TripRelayFlag = 1;
        TripRelay     = 0;        
    }
   /* else if (UnderCurrentFlag && !TripRelayFlag && (UnderCurrentTick > UnderCurrentTripDelay))
    {
        TripRelayFlag = 1;
        TripRelay     = 0;        
    }*/
    else
    {
        NOP();
    }
    
    if(PowerONFlag && TripRelayFlag && (AutoResetTick > PowerONDelay))         //  Power ON Reset Condition
    {
        TripRelayFlag = 0;
        AutoResetFlag = 0;
        PowerONFlag    = 0;
        
        TripRelay = 1;
    }
    else if(!PowerONFlag && TripRelayFlag && AutoResetFlag && (AutoResetTick > AutoResetTimeDelay) && AutoModeFlag)         //  Auto Mode Reset Condition
    {
        TripRelayFlag = 0;
        AutoResetFlag = 0;
        PowerONFlag    = 0;
        
        TripRelay = 1;
    }
    else if(!PowerONFlag && TripRelayFlag && ManualResetInput && !AutoModeFlag)      //  Manual Mode Reset Condition
    {
        TripRelayFlag = 0;
        ManualResetInput = 0;
        AutoResetFlag = 0;
        
        OverVoltageFlag = 0;
        UnderVoltageFlag = 0;
        
        TripRelay     = 1;
    }
    else
        NOP();
}

/*******************************************************************************/
/*                                                                             */ 
/*                          Status LED Blinking                                */
/*                                                                             */
/*******************************************************************************/

void BlinkLED(void)
{
    if(!TripRelayFlag && LEDBlinkTick > 100)         //  Under normal condition blink every 500ms
    {
        StatusLED = ~StatusLED;
        LEDBlinkTick = 0;
    }
    else if(TripRelayFlag && LEDBlinkTick >25)      //  Under fault condition blink every 250ms
    {
        StatusLED = ~StatusLED;
        LEDBlinkTick = 0;
    }
    else
        NOP();
}