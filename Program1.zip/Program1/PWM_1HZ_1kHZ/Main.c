
#include <xc.h>
#include <stdint.h>

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.

/*******************************************************************************/
/*                                                                             */ 
/*                              Configuration                                  */
/*                                                                             */
/*******************************************************************************/

#pragma config FOSC = INTOSCIO  // Oscillator Selection bits (INTOSCIO oscillator: I/O function on RA4/OSC2/CLKOUT pin, I/O function on RA5/OSC1/CLKIN)
#pragma config WDTE = OFF        // Watchdog Timer Enable bit (WDT enabled)
#pragma config PWRTE = ON       // Power-up Timer Enable bit (PWRT enabled)
#pragma config MCLRE = ON       // MCLR Pin Function Select bit (MCLR pin function is MCLR)
#pragma config CP = OFF         // Code Protection bit (Program memory code protection is disabled)
#pragma config CPD = OFF        // Data Code Protection bit (Data memory code protection is disabled)
#pragma config BOREN = ON       // Brown Out Detect (BOR enabled)
#pragma config IESO = OFF       // Internal External Switchover bit (Internal External Switchover mode is disabled)
#pragma config FCMEN = OFF      // Fail-Safe Clock Monitor Enabled bit (Fail-Safe Clock Monitor is disabled)

/*******************************************************************************/
/*                                                                             */ 
/*                              Crystal Oscillator                             */
/*                                                                             */
/*******************************************************************************/

#define _XTAL_FREQ 4000000
void System_Init(void);                 //  System Init function declaration
void main()
{
     System_Init();
     while(1)
     {
         
     }
}

void System_Init(void)
{
    /******************* Internal Oscillator Setting *******************************/  
    
    OSCCONbits.IRCF0 = 0;           //  
    OSCCONbits.IRCF1 = 1;           //  Internal Oscillator configured to 4 MHz
    OSCCONbits.IRCF2 = 1;           //
    OSCCONbits.SCS   = 1;
    //OSCTUNE = 0x00;
    
/*********************** GPIO Port Setting *************************************/
    
    TRISIObits.TRISIO0 = 1;         //  GPIO0 is set as Input
    TRISIObits.TRISIO1 = 1;         //  GPIO1 is set as Input  
    TRISIObits.TRISIO2 = 1;         //  GPIO2 is set as Input
    TRISIObits.TRISIO4 = 0;         //  GPIO4 is set as Output
    TRISIObits.TRISIO5 = 0;         //  GPIO5 is set as Output
    
    ANSELbits.ANS0 = 1;             //  ADC Channel-1 is enabled
    ANSELbits.ANS1 = 1;             //  ADC Channel-2 is enabled
    ANSELbits.ANS2 = 0;             //  ADC Channel-3 is disabled
    ANSELbits.ANS3 = 0;             //  ADC Channel-4 is disabled

/*********************** Unused Peripheral Masking *****************************/
    
    WPU = 0x00;                     //  Internal Pull-ups disabled
    IOC = 0x00;                     //  Interrupt ON Change disabled
    CMCON0 = 0x07;                  //  Comparator disabled    
    CCP1CON = 0x00;                 //  CCP Module disabled
    PCONbits.ULPWUE = 0;            //  Ultra low power wakeup disabled

/*********************** Timer-0 Assigned as WDT   *****************************/   
    
    
    //Timer0 Registers Prescaler= 2 - TMR0 Preset = 6 - Freq = 2000.00 Hz - Period = 0.000500 seconds
    OPTION_REGbits.T0CS = 0;  // bit 5  TMR0 Clock Source Select bit...0 = Internal Clock (CLKO) 1 = Transition on T0CKI pin
    OPTION_REGbits.T0SE = 0;  // bit 4 TMR0 Source Edge Select bit 0 = low/high 1 = high/low
    OPTION_REGbits.PSA = 0;   // bit 3  Prescaler Assignment bit...0 = Prescaler is assigned to the Timer0
    OPTION_REGbits.PS2 = 1;   // bits 2-0  PS2:PS0: Prescaler Rate Select bits
    OPTION_REGbits.PS1 = 1;
    OPTION_REGbits.PS0 = 0;
    TMR0 = 250;             // preset for timer register


    // Interrupt Registers
      INTCON = 0;           // clear the interrpt control register
      INTCONbits.TMR0IE = 1;        // bit5 TMR0 Overflow Interrupt Enable bit...1 = Enables the TMR0 interrupt
      INTCONbits.TMR0IF = 0;        // bit2 clear timer 0 interrupt flag
      INTCONbits.GIE = 1;           // bit7 global interrupt enable
      INTCONbits.PEIE = 1;            //  Peripheral interrupts enabled
/*********************** ADC Configuration   *****************************/    
    
    ADCON0 = 0x81;                  //  ADC Register configuration
    ADCON0bits.VCFG = 0;            //  ADC Reference is connected to VCC
    ANSELbits.ADCS0 = 1;
    ANSELbits.ADCS1 = 0;
    ANSELbits.ADCS2 = 1;
}