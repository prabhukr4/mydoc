/*
 * SMS.h
 *
 * Created: 11/4/2014 8:53:10 AM
 *  Author: rnd-u7
 */ 


#ifndef SMS_H_
#define SMS_H_
extern void gsm_ok_response_check(unsigned char next_status,unsigned char previous_status,unsigned char next_shift_status);
extern void sms_init(void);
extern void send_gsm_msg_read_command(void);
extern void change_gsm_to_text_mode(void);
extern void set_new_msg_indication(void);
extern void save_msg_settings(void);
extern void send_gsm_sms_delete_command(void);
extern void apn_settings_function(void);
extern void GSM_GPRS_CONTEXT_Cmd(void);
extern void store_num_to_sim_mem(unsigned char *mob_no);
extern void Collect_Info_Data(void);
extern void Collect_Parameter_Data(void);
extern void Collect_Summary_Data(void);
extern void Send_Parameter_Function(unsigned char *mob_no);
extern void Send_Info_Function(unsigned char *mob_no);
extern void Collect_Info_Data(void);
extern void Send_Summary_Function(unsigned char *mob_no);

/****************************************************************************************************************************************************
SMS is one of the advanced feature which is used to tell the status execution of MWM and used to configure the APN settings for MWM
*****************************************************************************************************************************************************/
void gsm_ok_response_check(unsigned char next_status,unsigned char previous_status,unsigned char next_shift_status)
{
	if(bGSMRxdFlag==1)
	{
		bGSMRxdFlag = 0;
		while(ucGSMtempBuff[testcount] != 'O' && ucGSMtempBuff[testcount] != 'E')
		{
			testcount++;
			
		}
		
		if((ucGSMtempBuff[testcount] == 'O') && (ucGSMtempBuff[testcount+1] == 'K'))
		{
			GSM_COMMAND_STATUS       = next_shift_status;
			testcount                = 0;
			GSM_Temp_Count           = 0;
			Qout_GSM                 = 0;
			gsm_retry_count          = 0;
			bGSMRxdFlag              = 0;
			
		}
		else
		{
			gsm_retry(next_status,previous_status);				
		}
	}
	
	else
	{
		gsm_retry(next_status,previous_status);
	}
	
}

/*****************************************************************************************
READ COMMAND FOR MESSAGE
AT+CMGR = Memory Location
Note ------>>>>>> All the Below commands are transmitted via transmission Interrupt
******************************************************************************************/
void send_gsm_msg_read_command(void)/*modified in sms.h file whose value already corrected but for testing 100315*/
{
	//GSM_Send_UART_String_1(GSM_CMGR,'=',sms.msg_loc,' ',' ',' ',0x0D,0x0A);
	GSM_Send_UART_String_1(GSM_CMGR,0,0,0,0,0,0x0D,0x0A);
	//GSM_Send_UART_String_1(GSM_CMGR,'=','0','0','0',sms.msg_loc,0x0D,0x0A);
	//GSM_Send_UART_String_1(GSM_CMGR,'=',sms.msg_loc,0,0,0,0x0D,0x0A);
	GSM_Struct.Start_Transmission_command = 1;
	USARTD0_DATA                          = GSM_Struct.Queue_GSM_Command_Buff[Qout_GSM];
	sms.msg_status                        = CHECK_READ_SMS;
}

/*****************************************************************************************
READ COMMAND FOR MESSAGE
AT+CMGR = Memory Location
******************************************************************************************/
void change_gsm_to_text_mode(void)
{
	GSM_Send_UART_String_1(GSM_CMGF,0,0,0,0,0,0x0D,0x0A);
	GSM_Struct.Start_Transmission_command = 1;
	USARTD0_DATA                          = GSM_Struct.Queue_GSM_Command_Buff[Qout_GSM];
	_delay_ms(20);	
}

/*****************************************************************************************
Setting the Message indication 
this command is used to set the GSM module to notify the New incoming message
At+CNMI = 1,1,0,0,0
******************************************************************************************/
void set_new_msg_indication(void)
{
	GSM_Send_UART_String_1(GSM_CNMI,0,0,0,0,0,0x0D,0x0A);
	GSM_Struct.Start_Transmission_command = 1;
	USARTD0_DATA = GSM_Struct.Queue_GSM_Command_Buff[Qout_GSM];
	_delay_ms(20);
}

/*****************************************************************************************
Save the above message settings to GSM
this command will save the settings to the GSM Module
At+CSAS
******************************************************************************************/
void save_msg_settings(void)
{
	GSM_Send_UART_String_1(GSM_CSAS,0,0,0,0,0,0x0D,0x0A);
	GSM_Struct.Start_Transmission_command = 1;
	USARTD0_DATA = GSM_Struct.Queue_GSM_Command_Buff[Qout_GSM];
	_delay_ms(20);
	//GSM_COMMAND_STATUS = GSM_GPRS_DEACTIVATE_CMD;
	GSM_COMMAND_STATUS = APN_SETTINGS;
}

/*****************************************************************************************
Sending the SMS to the given Mobile number and the body of the Text message
Example to send a message to a Number
AT+CMGS = 0123456789 (enter) HI (ctrl+z)
*****************************************************************************************/
void sms_send_function(unsigned char *mob_no,const char *mob_txt)//This function will send the SMS to the Given mobile number 
{
	GSM_UART_Send_String("AT+CMGS=");//AT command for Sending the MSG
	while(*mob_no != '"')//Sending the Mobile number to GSM Module upto the " character in the Buffer
	{
		GSM_UART_Send_Byte(*mob_no++);
	}
	GSM_UART_Send_Byte(0x0D);// Sending the Enter character
	_delay_ms(500);//Giving delay
	while(*mob_txt != '\0')//After that transmitting the Mobile Text message to the GSM Module
	{
		GSM_UART_Send_Byte(*mob_txt++);
	}
	GSM_UART_Send_Byte(0x1A);//Character for Control + Z
	sms.finished_bit = FALSE;//Setting this bit will control the Status LED
}

/*******************************************************************************************************************************************
// Function which will store the mobile number of its own in to SIM memory in the name of "My Number"
//Output of the function will be the given mobile number will be stored in the first location of Sim card in the Name of "My Number"
*********************************************************************************************************************************************/
void store_num_to_sim_mem(unsigned char *mob_no)
{
	GSM_UART_Send_String("AT+CPBS=\"SM\"");//Sending the storage location as SIM card
	GSM_UART_Send_Byte(0x0D);GSM_UART_Send_Byte(0x0A);//Sending Enter and Line feed character
	GSM_UART_Send_String("AT+CPBW=1,\"");//Sending phone book writing command and storing the number in the first location of the SIM card
	while(*mob_no != '"')
	{
		GSM_UART_Send_Byte(*mob_no++);//Sending the number to GSM 
	}
	GSM_UART_Send_String("\",129,\"%My_Number\"");//Sending the numbering scheme(National or international) and Text My number to GSM
	GSM_UART_Send_Byte(0x0D);GSM_UART_Send_Byte(0x0A);//Sending Enter and Line feed character
}

/*****************************************************************************************
Sending this command will delete all the messages that is stored in the SIM card
*****************************************************************************************/
void send_gsm_sms_delete_command(void)/*modified in sms.h file whose value already corrected but for testing 100315*/
{
	GSM_Send_UART_String_1(GSM_CMGD,0,0,0,0,0,0x0D,0x0A);
	//GSM_Send_UART_String_1(GSM_CMGD,'=','0','0','0',"1,4",0x0D,0x0A);
	//GSM_Send_UART_String_1(GSM_CMGD,'=',"1,4",0,0,0,0x0D,0x0A);
	GSM_Struct.Start_Transmission_command = 1;
	USARTD0_DATA                          = GSM_Struct.Queue_GSM_Command_Buff[Qout_GSM];
	_delay_ms(20);
}

/**********************************************************************************************
This function will check if the received string from the GSM is CMGR character continuously
in the buffer

Model String that is received from the GSM module
-----------------------------------------------------------------------------------------------
+CMGR: "REC UNREAD","+917502537770","","14/11/04,09:46:04+22"
<>"airtelgprs.com"#1234567890*

OK
-----------------------------------------------------------------------------------------------
Note ---> All defined buffer position is mapped in a seperate Excel file please refer that
************************************************************************************************/
void check_read_sms(void)
{	
	sms.Read_Cmd_Bit = FALSE;
	if(ucGSMtempBuff[test_count_1+1] == 'C' && ucGSMtempBuff[test_count_1+2] == 'M' && ucGSMtempBuff[test_count_1+3] == 'G' && ucGSMtempBuff[test_count_1+4] == 'R')//Checking if the buffer has CMGR characters
	{
		/*			MCU_UART_Send_String("NUMBER : ");*/
		/*+CMGR: "REC UNREAD","+919790336510","","15/03/04,15:52:21+22"
		<>"airtelgprs.com"#8220777849@HHHH:MM*
		*/
		int8_t i = test_count_1+5;
		for(;i<45;i++)//This for Loop will used to segregate the mobile number from the GSM module
		{
			if(ucGSMtempBuff[i] == '"')//If the GSM temp buffer has " character
			{
				sms.qoutes_counter++;//incrementing the quotes counter
			}
			if(sms.qoutes_counter == 3 && sms.qoutes_counter != 4)
			{
				sms.number[sms.number_count] = ucGSMtempBuff[i+1];//Store the number that is lies between the 
				sms.number_count++;
			}
		}
		sms.Read_bit = 1;
		sms.incoming_bit = 0;
		sms.msg_status     = DELETE_MSG_IN_SIM_CARD;
		sms.count          = 0;
		sms.qoutes_counter = 0;
		sms.number_count   = 0;
		test_count_1 = 0;		
	}
	else
	{
		sms.msg_status = CHECK_READ_SMS;//if not the CMGR received then go back to checking process
	}
}

//Checking OK response that is received for the Delete message
void check_deleted_msg(void)
{
	if(bGSMRxdFlag==1)
	{
		bGSMRxdFlag = 0;
		while(ucGSMtempBuff[testcount] != 'O' && ucGSMtempBuff[testcount] != 'E')
		{
			testcount++;
		}
			
		if((ucGSMtempBuff[testcount] == 'O') && (ucGSMtempBuff[testcount+1] == 'K'))
		{
			sms.msg_status          = CODE_APN_TO_GSM;
			testcount                = 0;
			GSM_Temp_Count           = 0;
			Qout_GSM                 = 0;
			gsm_retry_count          = 0;
			bGSMRxdFlag              = 0;
			//sms.set_apn_bit			 = 1;
			sms.Del_Bit = 1;
		}
		else
		{
			sms.msg_status = CHECK_MSG_DELETED;
			//sms.set_apn_bit			 = 1;// For testing 090315
			sms.Del_Bit = 1;//For Testing 090315
		}
	}
}

/**************************************************************************************
If any Incoming message that is triggered then the following string will be notified 

+CMTI: "SM",7
7 -----> is the Position that the Message is stored
SM---->  means the SIM memory location
***************************************************************************************/
void sms_read_function(void)
{
	sms.rxd_sms_bit = FALSE;
		
	GSM_Temp_Count  = 0;////resetting the pointer back to zero
	if(ucGSMtempBuff[test_count + 1] == 'C' && ucGSMtempBuff[test_count + 2] == 'M' && ucGSMtempBuff[test_count + 3] == 'T' && ucGSMtempBuff[test_count + 4] == 'I')//When new sms received then the received string is "CMTI"	
	{
		sms.msg_loc[0] = ucGSMtempBuff[test_count + 12];
		sms.new_Rxd_Bit = 1;
		sms.Read_Cmd_Flag = 1;
		sms.msg_status     = SEND_SMS_READ_COMMAND;
		MWM_COMMAND_STATUS = SEND_GSM_SMS_MODE;
		GSM_COMMAND_STATUS = IDEAL_STATUS;
		sms.incoming_bit = 1;
		sms.finished_bit = 0;
		test_count = 0;
	}
	else
	{
		GSM_Temp_Count = 0;
		test_count = 0;
		sms.msg_status = DETECT_RX_SMS;
	}
}

/**************************************************************************************
This SMS function is the Main functions that is the collection of all the sub functions 

1. Always in checking mode if any SMS incoming 
2.Send msg read command to GSM if any message is getting In to GSM
3.Check the read SMS from the Memory location
4.Delete the Messages available in the SIM card once the SMS get read
5.Code the APN setting received from MSG to GSM
6.Store the number  from the sms to Sim card
***************************************************************************************/
void sms_function(void)
{
	if(sms.rxd_sms_bit == TRUE)			//Read the sms from the GSM
	{
		sms_read_function();			//Check if any new sms received
	}
	if(sms.new_Rxd_Bit == TRUE)
	{
		sms.new_Rxd_Bit = FALSE;
		send_gsm_msg_read_command();	// Send the read command 
	}
	if(sms.Read_Cmd_Bit== TRUE)
	{
		check_read_sms();				//check the received sms
	}
	if(sms.Read_bit == TRUE)
	{
		sms.Read_bit = FALSE;
		send_gsm_sms_delete_command();	// delete the sms after the msg read from the GSM.
		_delay_ms(1000);
		check_deleted_msg();			// checking the deleted sms
	}
	
	if(sms.Del_Bit == TRUE)
	{
		sms.Del_Bit = FALSE;
		apn_settings_function();		// separating the APN and HMR input from the SMS
		_delay_ms(2000);			//	Timing Problem for sms send and receive fn 17/04/2015
	}
	
	if(sms.apn_finshd_bit == 1)
	{
		sms.apn_finshd_bit = 0;			//Store the mobile number 
		store_num_to_sim_mem(GSM_Struct.mob_num);	
		sms.send_sms_bit = TRUE;
	}
	
	if(sms.req_msg == 1)
	{
		if(sms.req_settings[0] == 'G' && sms.req_settings[1] == 'e' && sms.req_settings[2] == 't' && sms.req_settings[3] == ' ' && sms.req_settings[4] == 'I' && sms.req_settings[5] == 'n' && sms.req_settings[6] == 'f' && sms.req_settings[7] == 'o')
		{	//Checking received SMS and comparing received string and provided string
			if (sms.tick_cnt >= 50)
			{	//Count reaches 500mSec interval
				sms.req_msg		= 0;			//Clear new message received
				sms.tick_cnt    = 0;			//Clear tick count
				Send_Info_Function(sms.number);	//Send info message function
				sms.incoming_bit    = 0;		//Clear new message received flag once reply send to user
				sms.finished_bit = FALSE;		//Setting this bit will control the Status LED
				_delay_ms(5000);
				GSM_COMMAND_STATUS = SEND_GSM_INIT_AT;	//Reinitialize GSM Module once again
			}
		}
		if(sms.req_settings[0] == 'G' && sms.req_settings[1] == 'e' && sms.req_settings[2] == 't' && sms.req_settings[3] == ' ' && sms.req_settings[4] == 'D' && sms.req_settings[5] == 'a' && sms.req_settings[6] == 't' && sms.req_settings[7] == 'a')
		{
			if (sms.tick_cnt >= 50)
			{
				sms.req_msg		= 0;			//Clear new message received
				sms.tick_cnt    = 0;			//Clear tick count
				Send_Parameter_Function(sms.number);
				sms.incoming_bit    = 0;		//Clear new message received flag once reply send to user
				sms.finished_bit = FALSE;		//Setting this bit will control the Status LED
				_delay_ms(5000);
				GSM_COMMAND_STATUS = SEND_GSM_INIT_AT;	//Reinitialize GSM Module once again
			}
		}
		if(sms.req_settings[0] == 'G' && sms.req_settings[1] == 'e' && sms.req_settings[2] == 't' && sms.req_settings[3] == ' ' && sms.req_settings[4] == 'S' && sms.req_settings[5] == 'u' && sms.req_settings[6] == 'm' && sms.req_settings[7] == 'm')
		{
			if (sms.tick_cnt >= 50)
			{
				sms.req_msg		= 0;			//Clear new message received
				sms.tick_cnt    = 0;			//Clear tick count
				Send_Summary_Function(sms.number);
				sms.incoming_bit    = 0;		//Clear new message received flag once reply send to user
				sms.finished_bit = FALSE;		//Setting this bit will control the Status LED
				_delay_ms(5000);
				GSM_COMMAND_STATUS = SEND_GSM_INIT_AT;	//Reinitialize GSM Module once again
			}
		}
	}
	
	if(sms.send_sms_bit == TRUE)
	{
		if (sms.tick_cnt >= 50)
		{
			sms.send_sms_bit = FALSE;		//Send SMS after receiving  and precessed 
			sms.tick_cnt    = 0;			//Clear tick count
			sms_send_function(sms.number,SMS_NOTIFICATION_FOR_APN);
			sms.finished_flag = 1;			//Enabling sms finished flag to 1 for executing hour meter reset function reply
			sms.incoming_bit    = 0;		//Clear new message received flag once reply send to user
			sms.finished_bit = FALSE;		//Setting this bit will control the Status LED
			_delay_ms(5000);
			GSM_COMMAND_STATUS = SEND_GSM_INIT_AT;	//Reinitialize GSM Module once again
		}
	}
		
	if(sms.HMR_Reset_Flag == TRUE && sms.finished_flag == TRUE)
	{
		if (sms.tick_cnt_1 >= 300)
		{
			sms.HMR_Reset_Flag	= FALSE;	//Clear HMR Reset flag
			sms.finished_flag	= FALSE;	//Clear SMS received flag
			sms.tick_cnt_1		= 0;		//Clear Clock tick count
			sms_send_function(sms.number,SMS_NOTIFICATION_FOR_APN_2);
			sms.HMR_Finished_Flag = 1;		//Set HMR Reset completed flag
		}
	}
}

/**********************************************************************************************************************
Send sms function will execute once the APN successfully coded and the received SMS process has been completed
**********************************************************************************************************************/
void send_sms(void)
{
	if(sms.send_sms_bit == TRUE)
	{
		if (sms.tick_cnt >= 50)
		{
			sms.send_sms_bit = FALSE;
			sms.tick_cnt     = 0;
			sms_send_function(sms.number,SMS_NOTIFICATION_FOR_APN_2);
		}
	}
}

/***********************************************************
All sms related initialization will happen in this function
************************************************************/
void sms_init(void)
{
	change_gsm_to_text_mode();
	set_new_msg_indication();
	send_gsm_sms_delete_command();
	save_msg_settings();
}

/***********************************************************
Sending the APN settings command to the GSM
Example to code APN for Air tel Network:

AT+CGDCONT = 1,"IP","airtelgprs.com","0.0.0.0",0,0 (Enter)
************************************************************/
void GSM_GPRS_CONTEXT_Cmd(void)
{
	GSM_Send_UART_String_1(GSM_CGDCONT,'=',' ' ,' ' ,' ',sms.temp_buff,0x0D,0x0A);
	GSM_Struct.Start_Transmission_command = 1;
	USARTD0_DATA = GSM_Struct.Queue_GSM_Command_Buff[Qout_GSM];
	sms.processing_bit = 0;
	sms.finished_bit = 1;
}

void GPRS_ACTIVATION_APN_Cmd(void)
{
	if(APN_Settings_Change_Cnt == 0)
	{
		GSM_Send_UART_String_1(GSM_CGDCONT1,0,0,0,0,0,0x0D,0x0A);
	}
	else if(APN_Settings_Change_Cnt == 1)
	{
		GSM_Send_UART_String_1(GSM_CGDCONT2,0,0,0,0,0,0x0D,0x0A);
	}
	else if(APN_Settings_Change_Cnt == 2)
	{
		GSM_Send_UART_String_1(GSM_CGDCONT3,0,0,0,0,0,0x0D,0x0A);
	}
	else if(APN_Settings_Change_Cnt == 3)
	{
		GSM_Send_UART_String_1(GSM_CGDCONT4,0,0,0,0,0,0x0D,0x0A);
	}
	else if(APN_Settings_Change_Cnt == 4)
	{
		GSM_Send_UART_String_1(GSM_CGDCONT5,0,0,0,0,0,0x0D,0x0A);
	}
	else if(APN_Settings_Change_Cnt == 5)
	{
		GSM_Send_UART_String_1(GSM_CGDCONT6,0,0,0,0,0,0x0D,0x0A);
	}
	GSM_Struct.Start_Transmission_command = 1;
	USARTD0_DATA = GSM_Struct.Queue_GSM_Command_Buff[Qout_GSM];
	GSM_COMMAND_STATUS = GSM_GPRS_DEACTIVATE_CMD;
}

/***********************************************************
Load the APN settings in a a buffer and will code to GSM
************************************************************/
void load_apn_in_one_buffer(void)
{
	unsigned char i,j,k,m,n;
	
	for(uint8_t i=0;i<150;i++)
	{
		sms.temp_buff[i] = 0;
	}
	for(uint8_t i=0;i<=5;i++)
	{
		sms.HMR_HOUR_Settings[i] = 0;
	}
	for(uint8_t i=0;i<=2;i++)
	{
		sms.HMR_MIN_Settings[i] = 0;
	}
	sms.temp_buff[0] = '1';
	sms.temp_buff[1] = ',';
	sms.temp_buff[2] = '"';
	sms.temp_buff[3] = 'I';
	sms.temp_buff[4] = 'P';
	sms.temp_buff[5] = '"';
	sms.temp_buff[6] = ',';
	j=7;i=1;
	while(sms.apn_settings[i] != '#')//Segregating the APN settings
	{
		sms.temp_buff[j] = sms.apn_settings[i];
		j++;i++;
	}
	
	sms.temp_buff[j] = ',';
	sms.temp_buff[j+1] = '"';
	sms.temp_buff[j+2] = '0';
	sms.temp_buff[j+3] = '.';
	sms.temp_buff[j+4] = '0';
	sms.temp_buff[j+5] = '.';
	sms.temp_buff[j+6] = '0';
	sms.temp_buff[j+7] = '.';
	sms.temp_buff[j+8] = '0';
	sms.temp_buff[j+9] = '"';
	sms.temp_buff[j+10] = ',';
	sms.temp_buff[j+11] = '0';
	sms.temp_buff[j+12] = ',';
	sms.temp_buff[j+13] = '0';
	sms.incoming_bit    = 0;
	sms.processing_bit  = 1;
	
	k=0;i++;
	while(sms.apn_settings[i] != '@')//Segregating the Mobile number 
	{
		GSM_Struct.mob_num[k] = sms.apn_settings[i];
		k++;i++;
	}
	GSM_Struct.mob_num[k++] = '"';
	GSM_Struct.mob_num_cnt = k;
	
	m=0;i++;
	while(sms.apn_settings[i] != ':')//Segregating Engine Hours 
	{
		sms.HMR_HOUR_Settings[m] = sms.apn_settings[i];
		m++;i++;
	}
	n=0;i++;
	while(sms.apn_settings[i] != '*')//Segregating Engine Minutes
	{
		sms.HMR_MIN_Settings[n] = sms.apn_settings[i];
		n++;i++;
	}
	
	engine_hrs = int4hex(sms.HMR_HOUR_Settings);
	engine_min = chr2hex(sms.HMR_MIN_Settings);
	
	if(sms.HMR_HOUR_Settings[0] == 'H')
	{
		ucGSMRxdStatus = CHK_START_OF_PACKET;
	}
	else
	{
		sms.Engine_HMR_Proc_Flag = 1;
		Configuration_from_UDP_write_to_EEPROM();
		ucModCommandStatus    = SEND_CONFIG_INFO_TO_EQUIPMENT;
	}
}

void apn_settings_function(void)
{
	if(sms.set_apn_bit == 1)
	{
		sms.set_apn_bit = 0;
		load_apn_in_one_buffer();
		GSM_GPRS_CONTEXT_Cmd();
		sms.apn_finshd_bit = 1;
	}
}


unsigned char number_to_string(unsigned long *number)
{
	unsigned char i=0;
	do
	{
		data_buff[i++]=*number%10+'0';
		*number=*number/10;
	}
	while(*number>0);
	return(i);
}

void LSBuf(const unsigned char *str_buff,unsigned char *msg_buff,unsigned long *val)
{
	unsigned char digits=0;
	
	while(*str_buff!='`')
	{
		*msg_buff=*str_buff;
		str_buff++;msg_buff++;
		if(*str_buff=='0')
		{
			digits=number_to_string(val);
			do
			{
				*msg_buff=data_buff[--digits];
				str_buff++;msg_buff++;
			}
			while(digits > 0);
			val++;
		}
	}
	
	*msg_buff='`';
}

void SMSBuf(unsigned char *msg_array)
{
	while(*msg_array != '`')
	{
		GSM_UART_Send_Byte(*msg_array);
		msg_array++;
	}
	GSM_UART_Send_Byte(13);
}

void Send_Parameter_Function(unsigned char *mob_no)
{
	GSM_UART_Send_String("AT+CMGS=");//AT command for Sending the MSG
	while(*mob_no != '"')//Sending the Mobile number to GSM Module upto the " character in the Buffer
	{
		GSM_UART_Send_Byte(*mob_no++);
	}
	GSM_UART_Send_Byte(0x0D);// Sending the Enter character
	_delay_ms(500);//Giving delay

	Collect_Parameter_Data();
	GSM_UART_Send_Byte(0x1A);//Character for Control + Z
}

void Collect_Parameter_Data(void)
{
	unsigned int temp_z,temp_y,ui_temp;

	/*	00 24		Oil Pressure
		00 46		Coolant temperature
		00 00		Dummy
		00 32		Fuel level
		07 D0	RPM
		00 32		Run Hrs
		00 0A	Run Min
	 00 00  00 00	Dummy
		00 00		Freq
	 00 00 04 7E	L1N
	 00 00 04 88	L2N
	 00 00 04 7E	L3N
	 00 00 01 F4	L1A
	 00 00 01 F4	L2A
	 00 00 01 F4	L3A
	 00 00 00 0A	EA
	 00 00 02 58	L1A 
	 00 00 02 8A	L2A
	 00 00 02 BC	L3A
		01 1D	DCV1
		01 2C	DCC1
		00 00		DCV2
		00 00		DCA2
		00 00		CM
		00 00		OM
		00 01		SS
02 00 00  |  00 00 00 00 00 AB C9 FF*/
	
	value_sms[0] = 0;		
	value_sms[1] = 0;
	value_sms[2] = 0;
	LSBuf(Send_Data,sms_buff,value_sms);
	SMSBuf(sms_buff);
	
	//Serial Number
	ui_temp = (PROD_ID_NO_3);
	ui_temp = ((ui_temp << 8) | PROD_ID_NO_4);
	temp_z = (ui_temp);
	value_sms[0] = temp_z;
	value_sms[1] = 0;
	value_sms[2] = 0;
	LSBuf(Send_Info_Serial,sms_buff,value_sms);
	SMSBuf(sms_buff);
	
	//Oil Pressure
	ui_temp = (Modbus_Struct.Parameters_buff[0]);
	ui_temp = ((ui_temp << 8) | (Modbus_Struct.Parameters_buff[1]));
	temp_z = (ui_temp / 10);
	value_sms[0] = temp_z;
	temp_y = (ui_temp % 10);
	value_sms[1] = temp_y;
	LSBuf(Send_Data_OP,sms_buff,value_sms);
	SMSBuf(sms_buff);

	//Coolant Temperature
	ui_temp = (Modbus_Struct.Parameters_buff[2]);
	ui_temp = ((ui_temp << 8) | (Modbus_Struct.Parameters_buff[3]));
	temp_z = (ui_temp);
	value_sms[0] = temp_z;
	value_sms[1] = 0;
	value_sms[2] = 0;
	LSBuf(Send_Data_CT,sms_buff,value_sms);
	SMSBuf(sms_buff);

	//Fuel Level
	ui_temp = (Modbus_Struct.Parameters_buff[6]);
	ui_temp = ((ui_temp << 8) | (Modbus_Struct.Parameters_buff[7]));
	temp_z = (ui_temp);
	value_sms[0] = temp_z;
	value_sms[1] = 0;
	value_sms[2] = 0;
	LSBuf(Send_Data_FL,sms_buff,value_sms);
	SMSBuf(sms_buff);

	////Engine Speed
	ui_temp = (Modbus_Struct.Parameters_buff[8]);
	ui_temp = ((ui_temp << 8) | (Modbus_Struct.Parameters_buff[9]));
	temp_z = (ui_temp);
	value_sms[0] = temp_z;
	value_sms[1] = 0;
	value_sms[2] = 0;
	LSBuf(Send_Data_ES,sms_buff,value_sms);
	SMSBuf(sms_buff);
	
	//Engine Run Hours
	ui_temp = (Modbus_Struct.Parameters_buff[10]);
	ui_temp = ((ui_temp << 8) | (Modbus_Struct.Parameters_buff[11]));
	temp_z = (ui_temp);
	value_sms[0] = temp_z;
	temp_y = (Modbus_Struct.Parameters_buff[13]);
	value_sms[1] = temp_y;
	LSBuf(Send_Data_EH,sms_buff,value_sms);
	SMSBuf(sms_buff);
	
	//Frequency
	ui_temp = (Modbus_Struct.Parameters_buff[18]);
	ui_temp = ((ui_temp << 8) | (Modbus_Struct.Parameters_buff[19]));
	temp_z = (ui_temp / 10);
	value_sms[0] = temp_z;
	temp_y = (ui_temp % 10);
	value_sms[1] = temp_y;
	LSBuf(Send_Data_AF,sms_buff,value_sms);
	SMSBuf(sms_buff);
	
	//L1N
	ui_temp = (Modbus_Struct.Parameters_buff[22]);
	ui_temp = ((ui_temp << 8) | (Modbus_Struct.Parameters_buff[23]));
	temp_z = (ui_temp / 10);
	value_sms[0] = temp_z;
	temp_y = (ui_temp % 10);
	value_sms[1] = temp_y;
	LSBuf(Send_Data_L1N,sms_buff,value_sms);
	SMSBuf(sms_buff);
	
	//L2N
	ui_temp = (Modbus_Struct.Parameters_buff[26]);
	ui_temp = ((ui_temp << 8) | (Modbus_Struct.Parameters_buff[27]));
	temp_z = (ui_temp / 10);
	value_sms[0] = temp_z;
	temp_y = (ui_temp % 10);
	value_sms[1] = temp_y;
	LSBuf(Send_Data_L2N,sms_buff,value_sms);
	SMSBuf(sms_buff);
	
	//L3N
	ui_temp = (Modbus_Struct.Parameters_buff[30]);
	ui_temp = ((ui_temp << 8) | (Modbus_Struct.Parameters_buff[31]));
	temp_z = (ui_temp / 10);
	value_sms[0] = temp_z;
	temp_y = (ui_temp % 10);
	value_sms[1] = temp_y;
	LSBuf(Send_Data_L3N,sms_buff,value_sms);
	SMSBuf(sms_buff);
	
	//L1C
	ui_temp = (Modbus_Struct.Parameters_buff[34]);
	ui_temp = ((ui_temp << 8) | (Modbus_Struct.Parameters_buff[35]));
	temp_z = (ui_temp / 10);
	value_sms[0] = temp_z;
	temp_y = (ui_temp % 10);
	value_sms[1] = temp_y;
	LSBuf(Send_Data_L1S1,sms_buff,value_sms);
	SMSBuf(sms_buff);
	
	ui_temp = (Modbus_Struct.Parameters_buff[38]);
	ui_temp = ((ui_temp << 8) | (Modbus_Struct.Parameters_buff[39]));
	temp_z = (ui_temp / 10);
	value_sms[0] = temp_z;
	temp_y = (ui_temp % 10);
	value_sms[1] = temp_y;
	LSBuf(Send_Data_L2S1,sms_buff,value_sms);
	SMSBuf(sms_buff);
	
	ui_temp = (Modbus_Struct.Parameters_buff[42]);
	ui_temp = ((ui_temp << 8) | (Modbus_Struct.Parameters_buff[43]));
	temp_z = (ui_temp / 10);
	value_sms[0] = temp_z;
	temp_y = (ui_temp % 10);
	value_sms[1] = temp_y;
	LSBuf(Send_Data_L3S1,sms_buff,value_sms);
	SMSBuf(sms_buff);
	
	ui_temp = (Modbus_Struct.Parameters_buff[46]);
	ui_temp = ((ui_temp << 8) | (Modbus_Struct.Parameters_buff[47]));
	temp_z = (ui_temp / 10);
	value_sms[0] = temp_z;
	temp_y = (ui_temp % 10);
	value_sms[1] = temp_y;
	LSBuf(Send_Data_NCS1,sms_buff,value_sms);
	SMSBuf(sms_buff);
	
	ui_temp = (Modbus_Struct.Parameters_buff[50]);
	ui_temp = ((ui_temp << 8) | (Modbus_Struct.Parameters_buff[51]));
	temp_z = (ui_temp / 10);
	value_sms[0] = temp_z;
	temp_y = (ui_temp % 10);
	value_sms[1] = temp_y;
	LSBuf(Send_Data_L1S2,sms_buff,value_sms);
	SMSBuf(sms_buff);
	
	ui_temp = (Modbus_Struct.Parameters_buff[54]);
	ui_temp = ((ui_temp << 8) | (Modbus_Struct.Parameters_buff[55]));
	temp_z = (ui_temp / 10);
	value_sms[0] = temp_z;
	temp_y = (ui_temp % 10);
	value_sms[1] = temp_y;
	LSBuf(Send_Data_L2S2,sms_buff,value_sms);
	SMSBuf(sms_buff);
	
	ui_temp = (Modbus_Struct.Parameters_buff[58]);
	ui_temp = ((ui_temp << 8) | (Modbus_Struct.Parameters_buff[59]));
	temp_z = (ui_temp / 10);
	value_sms[0] = temp_z;
	temp_y = (ui_temp % 10);
	value_sms[1] = temp_y;
	LSBuf(Send_Data_L3S2,sms_buff,value_sms);
	SMSBuf(sms_buff);
	
	ui_temp = (Modbus_Struct.Parameters_buff[60]);
	ui_temp = ((ui_temp << 8) | (Modbus_Struct.Parameters_buff[61]));
	temp_z = (ui_temp / 10);
	value_sms[0] = temp_z;
	temp_y = (ui_temp % 10);
	value_sms[1] = temp_y;
	LSBuf(Send_Data_DCVS1,sms_buff,value_sms);
	SMSBuf(sms_buff);
	
	ui_temp = (Modbus_Struct.Parameters_buff[62]);
	ui_temp = ((ui_temp << 8) | (Modbus_Struct.Parameters_buff[63]));
	temp_z = (ui_temp);
	value_sms[0] = temp_z;
	value_sms[1] = 0;
	value_sms[2] = 0;
	LSBuf(Send_Data_DCCS1,sms_buff,value_sms);
	SMSBuf(sms_buff);
		
	ui_temp = (Modbus_Struct.Parameters_buff[64]);
	ui_temp = ((ui_temp << 8) | (Modbus_Struct.Parameters_buff[65]));
	temp_z = (ui_temp / 10);
	value_sms[0] = temp_z;
	temp_y = (ui_temp % 10);
	value_sms[1] = temp_y;
	LSBuf(Send_Data_DCVS2,sms_buff,value_sms);
	SMSBuf(sms_buff);
	
	ui_temp = (Modbus_Struct.Parameters_buff[66]);
	ui_temp = ((ui_temp << 8) | (Modbus_Struct.Parameters_buff[67]));
	temp_z = (ui_temp);
	value_sms[0] = temp_z;
	value_sms[1] = 0;
	value_sms[2] = 0;
	LSBuf(Send_Data_DCCS2,sms_buff,value_sms);
	SMSBuf(sms_buff);
	
	ui_temp = (Modbus_Struct.Parameters_buff[68]);
	ui_temp = ((ui_temp << 8) | (Modbus_Struct.Parameters_buff[69]));
	if(ui_temp == 0)
	{
		LSBuf(Send_Data_CM1,sms_buff,value_sms);
		SMSBuf(sms_buff);
	}
	else
	{
		LSBuf(Send_Data_CM0,sms_buff,value_sms);
		SMSBuf(sms_buff);
	}
	
	ui_temp = (Modbus_Struct.Parameters_buff[70]);
	ui_temp = ((ui_temp << 8) | (Modbus_Struct.Parameters_buff[71]));
	if(ui_temp == 1)
	{
		LSBuf(Send_Data_OM1,sms_buff,value_sms);
		SMSBuf(sms_buff);
	}
	else if(ui_temp == 2)
	{
		LSBuf(Send_Data_OM2,sms_buff,value_sms);
		SMSBuf(sms_buff);
	}
	else
	{
		LSBuf(Send_Data_OM0,sms_buff,value_sms);
		SMSBuf(sms_buff);
	}

	ui_temp = (Modbus_Struct.Parameters_buff[72]);
	ui_temp = ((ui_temp << 8) | (Modbus_Struct.Parameters_buff[73]));
	if(ui_temp == 1)
	{
		LSBuf(Send_Data_SS1,sms_buff,value_sms);
		SMSBuf(sms_buff);
	}
	else
	{
		LSBuf(Send_Data_SS0,sms_buff,value_sms);
		SMSBuf(sms_buff);
	}
	GSM_UART_Send_Byte(0x0D);// Sending the Enter character	
}

void Send_Info_Function(unsigned char *mob_no)
{
	GSM_UART_Send_String("AT+CMGS=");//AT command for Sending the MSG
	while(*mob_no != '"')//Sending the Mobile number to GSM Module upto the " character in the Buffer
	{
		GSM_UART_Send_Byte(*mob_no++);
	}
	GSM_UART_Send_Byte(0x0D);// Sending the Enter character
	_delay_ms(500);//Giving delay

	Collect_Info_Data();
	GSM_UART_Send_Byte(0x1A);//Character for Control + Z
}

void Collect_Info_Data(void)
{
	unsigned int temp_z,temp_y,ui_temp;
	
	/*PROD_ID_NO_3 = 0x04;
	PROD_ID_NO_4 = 0x57;
	Software_version_byte3 = 0x00;
	Software_version_byte4 = 0xB2;
	Hardware_version_byte3 = 0x00;
	Hardware_version_byte4 = 0x51;
	Engine_Hours_byte1	 = 0x04;
	Engine_Hours_byte2	 = 0xD2;
	Engine_Hours_byte4	 = 0x05;*/
	
	value_sms[0] = 0;
	value_sms[1] = 0;
	value_sms[2] = 0;
	LSBuf(Send_Info,sms_buff,value_sms);
	SMSBuf(sms_buff);
	//GSM_UART_Send_Byte(0x0D);// Sending the Enter character
	
	ui_temp = (PROD_ID_NO_3);
	ui_temp = ((ui_temp << 8) | PROD_ID_NO_4);
	temp_z = (ui_temp);
	value_sms[0] = temp_z;
	value_sms[1] = 0;
	value_sms[2] = 0;
	LSBuf(Send_Info_Serial,sms_buff,value_sms);
	SMSBuf(sms_buff);
	//GSM_UART_Send_Byte(0x0D);// Sending the Enter character
	
	ui_temp = 15;
	temp_z = (ui_temp / 10);
	value_sms[0] = temp_z;
	temp_y = (ui_temp % 10);
	value_sms[1] = temp_y;
	LSBuf(Send_Info_MWMVer,sms_buff,value_sms);
	SMSBuf(sms_buff);
	//GSM_UART_Send_Byte(0x0D);// Sending the Enter character
			
	ui_temp = Software_version_byte3;
	ui_temp = ((ui_temp << 8) | Software_version_byte4);
	temp_z = (ui_temp / 100);
	value_sms[0] = temp_z;
	temp_y = (ui_temp % 100);
	value_sms[1] = temp_y;
	LSBuf(Send_Info_GPUSVer,sms_buff,value_sms);
	SMSBuf(sms_buff);
	//GSM_UART_Send_Byte(0x0D);// Sending the Enter character
		
	ui_temp = Hardware_version_byte3;
	ui_temp = ((ui_temp << 8) | Hardware_version_byte4);
	temp_z = (ui_temp / 10);
	value_sms[0] = temp_z;
	temp_y = (ui_temp % 10);
	value_sms[1] = temp_y;
	LSBuf(Send_Info_GPUHVer,sms_buff,value_sms);
	SMSBuf(sms_buff);
	//GSM_UART_Send_Byte(0x0D);// Sending the Enter character
		
	ui_temp = (Engine_Hours_byte1);
	ui_temp = ((ui_temp << 8) | Engine_Hours_byte2);
	temp_z = (ui_temp);
	value_sms[0] = temp_z;
	ui_temp = (Engine_Hours_byte4);
	temp_y = (ui_temp);
	value_sms[1] = temp_y;
	LSBuf(Send_Info_EngineRH,sms_buff,value_sms);
	SMSBuf(sms_buff);	
	GSM_UART_Send_Byte(0x0D);// Sending the Enter character
}

void Send_Summary_Function(unsigned char *mob_no)
{
	GSM_UART_Send_String("AT+CMGS=");//AT command for Sending the MSG
	while(*mob_no != '"')//Sending the Mobile number to GSM Module upto the " character in the Buffer
	{
		GSM_UART_Send_Byte(*mob_no++);
	}
	GSM_UART_Send_Byte(0x0D);// Sending the Enter character
	_delay_ms(500);//Giving delay

	Collect_Summary_Data();
	GSM_UART_Send_Byte(0x1A);//Character for Control + Z
}

void Collect_Summary_Data(void)
{
	
}

#endif /* SMS_H_ */