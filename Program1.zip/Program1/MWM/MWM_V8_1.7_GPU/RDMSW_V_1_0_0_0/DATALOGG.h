/*
 * DATALOGG.h
 *
 * Created: 8/23/2014 10:06:00 AM
 *  Author: rnd-u7
 */ 


#ifndef DATALOGG_H_
#define DATALOGG_H_

extern void Store_Parameters_to_Flash_memory	(void);
void Store_Cycle_Summary_to_Flash_memory(uint16_t cycle_summary_data_length,uint16_t total_number_of_cycle_summary);
extern void Store_Day_Summary_to_Flash_memory	(void);
extern void Store_Fault_Warning_to_Flash_memory	(void);
extern void read_cycle_sumry_para_actual_addr_of_eeprom(void);
extern void read_cycle_sumry_para_shadow_addr_of_eeprom(void);
extern void Read_from_flash(void);
extern void For_SnapShot_Read_Previous_Records_From_Flash(void);
extern void Store_page_address_queue_position_to_EEPROM(uint16_t current_page_address,uint16_t current_queue_position,uint64_t No_of_Records,uint16_t actual_Register_addr, uint16_t shadow_register_addr);
extern void store_snapshot_for_query(unsigned int total_parameter_length,bool previous_present_status);
extern void cycle_summary_parameters_eeprom_storage();

void Store_Parameters_to_Flash_memory(void)
{
	unsigned int uICRC,i;
	unsigned char uICRCH,uICRCL;
	unsigned char y,j;
	uint16_t k;
	uint16_t udp_data_length;
	
	udp_data_length = (chk_udp_data_length+5);
		
	unsigned char tempFlashDataFrame[300] = {PROD_ID_NO_1,PROD_ID_NO_2,PROD_ID_NO_3,PROD_ID_NO_4,CMD,CMD_ID};
	tempFlashDataFrame[6]  = LAT_GPS_BYTE0;
	tempFlashDataFrame[7]  = LAT_GPS_BYTE1;
	tempFlashDataFrame[8]  = LAT_GPS_BYTE2;
	tempFlashDataFrame[9]  = LAT_GPS_BYTE3;
	tempFlashDataFrame[10] = LON_GPS_BYTE0;
	tempFlashDataFrame[11] = LON_GPS_BYTE1;
	tempFlashDataFrame[12] = LON_GPS_BYTE2;
	tempFlashDataFrame[13] = LON_GPS_BYTE3;
	tempFlashDataFrame[14] = Speed;
	tempFlashDataFrame[15] = info_code;
	tempFlashDataFrame[16] = FC_MODE_A_PARAMETERS_BROADCAST_H;
	tempFlashDataFrame[17] = FC_MODE_A_PARAMETERS_BROADCAST_L;
	tempFlashDataFrame[18] = udp_data_length>>8;
	tempFlashDataFrame[19] = udp_data_length;
	
	k=20;
	for(j=0;j<chk_udp_data_length;j++)
	{
		tempFlashDataFrame[k] = Modbus_Struct.Parameters_buff[j];
		k++;
	}

	tempFlashDataFrame[k]   = Time_Hr;
	tempFlashDataFrame[k+1] = Time_Min;
	tempFlashDataFrame[k+2] = Time_Sec;
	tempFlashDataFrame[k+3] = Date_Byte1;
	tempFlashDataFrame[k+4] = Date_Byte2;
	
	uICRC                   = crc(tempFlashDataFrame,(k+5));
	uICRCH                  = (uICRC>>8);
	uICRCL                  = (uICRC);
	tempFlashDataFrame[k+5] = uICRCH;
	tempFlashDataFrame[k+6] = uICRCL;
	tempFlashDataFrame[k+7] = END;
	
	Flash_DataBuff[0] = START;
	
	y=1;
	for(i=0;i<(k+8);i++)
	{
		Flash_DataBuff[y] = tempFlashDataFrame[i];
		y++;
	}
	Flash_Struct.Flash_data_length = y;
	Update_Flash_to_the_Requested_page(Flash_Struct.ui32Current_Page_address,Flash_Struct.Flash_data_length);
}

//Storing the snaphot informations in the Flash memory
void store_snapshot_for_query(unsigned int total_parameter_length,bool previous_present_status)
{
	uint32_t current_page_address;
	uint16_t j = 0;
	
	if(previous_present_status == TRUE)
	{
		current_page_address = START_PAGE_ADDRESS_FOR_SNAPSHOT;
		
		for(unsigned int i=0;i<(total_parameter_length*5);i++)
		{
			Flash_Struct.record_buffer[i] = Modbus_Struct.snapshot_buffer[i];
		}
		at45dbx_wait_ready();
		flash_buffer1_write();
		at45dbx_wait_ready();
		flash_buffer1_to_main_memory_page_program_with_built_in_erase(current_page_address);
		at45dbx_wait_ready();
		
		current_page_address = (START_PAGE_ADDRESS_FOR_SNAPSHOT+1);
		
		j=(total_parameter_length*5);
		for(unsigned int i=0;i<(Modbus_Struct.Snapshot_total_buffer_size - (total_parameter_length*5));i++)
		{
			Flash_Struct.record_buffer[i] = Modbus_Struct.snapshot_buffer[j];
			j++;
		}
		at45dbx_wait_ready();
		flash_buffer1_write();
		at45dbx_wait_ready();
		flash_buffer1_to_main_memory_page_program_with_built_in_erase(current_page_address);
		at45dbx_wait_ready();
	}
	else
	{
		if(snapshot_struct.record_buffer_pos < (total_parameter_length*5))
		{
			current_page_address = (START_PAGE_ADDRESS_FOR_SNAPSHOT+2);
				
			for(unsigned int i=0;i<(total_parameter_length);i++)
			{
				Flash_Struct.record_buffer[snapshot_struct.record_buffer_pos] = Modbus_Struct.Parameters_buff[i];
				snapshot_struct.record_buffer_pos++;
			}
			at45dbx_wait_ready();
			flash_buffer1_write();
			at45dbx_wait_ready();
			flash_buffer1_to_main_memory_page_program_with_built_in_erase(current_page_address);
			at45dbx_wait_ready();
			
		}
		else
		{
			current_page_address = (START_PAGE_ADDRESS_FOR_SNAPSHOT+3);
									
			for(unsigned int i=0;i<(total_parameter_length);i++)
			{
				Flash_Struct.record_buffer[snapshot_struct.record_buffer_pos_1] = Modbus_Struct.Parameters_buff[i];
				snapshot_struct.record_buffer_pos_1++;
			}
			at45dbx_wait_ready();
			flash_buffer1_write();
			at45dbx_wait_ready();
			flash_buffer1_to_main_memory_page_program_with_built_in_erase(current_page_address);
			at45dbx_wait_ready();
		}
		
	}
	
}

//Reading the snapshot informations from flash
void read_snapshot_from_flash(unsigned char Current_page_number)
{
	uint16_t i;
	if(Current_page_number < 5)//Made by Padmanathan 16/03/2015
	{
		flash_main_memory_page_read(START_PAGE_ADDRESS_FOR_SNAPSHOT,0);
		for(i=0;i<Total_Parameter_data_length;i++)
		{
			snapshot_struct.temp_buff[i] = Flash_Struct.download_buffer[snapshot_struct.query_readng_pos];
			snapshot_struct.query_readng_pos++;
		}
		if(snapshot_struct.query_readng_pos>=(Total_Parameter_data_length*5))snapshot_struct.query_readng_pos=0;
		
	}
	
	if(Current_page_number < 10 && Current_page_number >= 5)//Made by Padmanathan 16/03/2015
	{
		flash_main_memory_page_read((START_PAGE_ADDRESS_FOR_SNAPSHOT+1),0);
		for(i=0;i<Total_Parameter_data_length;i++)
		{
			snapshot_struct.temp_buff[i] = Flash_Struct.download_buffer[snapshot_struct.query_readng_pos];
			snapshot_struct.query_readng_pos++;
		}
		if(snapshot_struct.query_readng_pos>=(Total_Parameter_data_length*5))snapshot_struct.query_readng_pos=0;
	}
	
	if(Current_page_number < 15 && Current_page_number >= 10)//Made by Padmanathan 16/03/2015
	{
		flash_main_memory_page_read((START_PAGE_ADDRESS_FOR_SNAPSHOT+2),0);
		for(i=0;i<Total_Parameter_data_length;i++)
		{
			snapshot_struct.temp_buff[i] = Flash_Struct.download_buffer[snapshot_struct.query_readng_pos];
			snapshot_struct.query_readng_pos++;
		}
		if(snapshot_struct.query_readng_pos>=(Total_Parameter_data_length*5))snapshot_struct.query_readng_pos=0;
	}
	
	if(Current_page_number < 20 && Current_page_number >= 15)//Made by Padmanathan 16/03/2015
	{
		flash_main_memory_page_read((START_PAGE_ADDRESS_FOR_SNAPSHOT+3),0);
		for(i=0;i<Total_Parameter_data_length;i++)
		{
			snapshot_struct.temp_buff[i] = Flash_Struct.download_buffer[snapshot_struct.query_readng_pos];
			snapshot_struct.query_readng_pos++;
		}
		if(snapshot_struct.query_readng_pos>=(Total_Parameter_data_length*5))snapshot_struct.query_readng_pos=0;
	}	
}

void cycle_summary_parameters_eeprom_storage(void)
{			 	
	uint16_t Calc_CRC16;
	uint8_t Calc_CRCH,Calc_CRCL;	
	ucEEPROM_Array[0] = ((DataLogg_Struct.No_of_Records_Cycle_Summary>>8)&0xFF);
	ucEEPROM_Array[1] = ((DataLogg_Struct.No_of_Records_Cycle_Summary)&0xFF);
	ucEEPROM_Array[2] = ((DataLogg_Struct.cycle_summary_pos>>8)&0xFF);
	ucEEPROM_Array[3] = ((DataLogg_Struct.cycle_summary_pos)&0xFF);
	ucEEPROM_Array[4] = ((DataLogg_Struct.cycle_summary_total_data_length>>8)&0xFF);
	ucEEPROM_Array[5] = ((DataLogg_Struct.cycle_summary_total_data_length)&0xFF);
	ucEEPROM_Array[6] = ((EEprom_Date>>8)&0xFF);
	ucEEPROM_Array[7] = ((EEprom_Date)&0xFF);
	//ucEEPROM_Array[6] = ((Day_Summary_Tick_Count>>24)&0xFF);
	//ucEEPROM_Array[7] = ((Day_Summary_Tick_Count>>16)&0xFF);
	//ucEEPROM_Array[8] = ((Day_Summary_Tick_Count>>8)&0xFF);
	//ucEEPROM_Array[9] = ((Day_Summary_Tick_Count)&0xFF);
	//Calc_CRC16 = crc(ucEEPROM_Array,10);
	Calc_CRC16 = crc(ucEEPROM_Array,8);
	Calc_CRCH = Calc_CRC16>>8;
	Calc_CRCL = Calc_CRC16;
	ucEEPROM_Array[8]	= Calc_CRCH;
	ucEEPROM_Array[9]	= Calc_CRCL;
	//ucEEPROM_Array[10]	= Calc_CRCH;
	//ucEEPROM_Array[11]	= Calc_CRCL;
	RDMSW_Config_Write_To_EEPROM(ACTUAL_EEPROM_ADDR_PAGE_ADDRESS_HI,10);
	RDMSW_Config_Write_To_EEPROM(SHADOW_EEPROM_ADDR_PAGE_ADDRESS_HI,10);
	//RDMSW_Config_Write_To_EEPROM(ACTUAL_EEPROM_ADDR_PAGE_ADDRESS_HI,12);
	//RDMSW_Config_Write_To_EEPROM(SHADOW_EEPROM_ADDR_PAGE_ADDRESS_HI,12);
}

void read_cycle_sumry_para_shadow_addr_of_eeprom(void)
{
	uint16_t crc_int;
	uint8_t *Data;
	uint8_t crc_h,crc_l;
	uint8_t temp_array[13];
	
	//Data = RDMSW_Config_Read_Frm_EEPROM(SHADOW_EEPROM_ADDR_PAGE_ADDRESS_HI,12);
	Data = RDMSW_Config_Read_Frm_EEPROM(SHADOW_EEPROM_ADDR_PAGE_ADDRESS_HI,10);
	//for(uint8_t i=0;i<12;i++)
	for(uint8_t i=0;i<10;i++)
	{
		temp_array[i] = (*(Data+i));
	}
	
	//crc_int   = crc(temp_array,10);
	crc_int   = crc(temp_array,8);
	crc_h     = (crc_int>>8);
	crc_l     = crc_int;
	
	//if((crc_h == temp_array[10]) && (crc_l == temp_array[11]))
	if((crc_h == temp_array[8]) && (crc_l == temp_array[9]))
	{
		DataLogg_Struct.No_of_Records_Cycle_Summary     = Char_To_Integer(temp_array[0],temp_array[1]);
		DataLogg_Struct.cycle_summary_pos			    = Char_To_Integer(temp_array[2],temp_array[3]);
		DataLogg_Struct.cycle_summary_total_data_length = Char_To_Integer(temp_array[4],temp_array[5]);
		EEprom_Read_Date								= Char_To_Integer(temp_array[6],temp_array[7]);
		//Day_Summary_Tick_Count							= char_To_Long_Integer(temp_array[6],temp_array[7],temp_array[8],temp_array[9]);
		if(EEprom_Read_Date != EEprom_Date)
		{
			Day_Summary_Interval_flag    = 1;
			Modbus_Struct.cloud_txd_bit	 = 1;
			MWM_COMMAND_STATUS           = PUT_RDMS_DAY_SUMMARY_BROADCAST;//changing the MWM status to put the Day summary broadcast to the server
			GPS_Location_Status          = AQUIRE_GPS_DATA;
			day_summary_calculation(DataLogg_Struct.cycle_summary_total_data_length,DataLogg_Struct.No_of_Records_Cycle_Summary);//After performing the day summary calculation
			cycle_summary_parameters_eeprom_storage();
		}
	}
	else
	{
		DataLogg_Struct.No_of_Records_Cycle_Summary     = 0;
		DataLogg_Struct.cycle_summary_pos			    = 0;
		DataLogg_Struct.cycle_summary_total_data_length = 0;
		Day_Summary_Tick_Count							= 0;
		cycle_summary_parameters_eeprom_storage();
	}
}

///////////////////////////////Reading the cycle summary parameters from EEPROM
void read_cycle_sumry_para_actual_addr_of_eeprom(void)
{
	uint16_t crc_int;
	uint8_t *Data;
	uint8_t crc_h,crc_l;
	uint8_t temp_array[13];
		
	//Data = RDMSW_Config_Read_Frm_EEPROM(ACTUAL_EEPROM_ADDR_PAGE_ADDRESS_HI,12);
	Data = RDMSW_Config_Read_Frm_EEPROM(ACTUAL_EEPROM_ADDR_PAGE_ADDRESS_HI,10);
	//for(uint8_t i=0;i<12;i++)
	for(uint8_t i=0;i<10;i++)
	{
		temp_array[i] = (*(Data+i));
	}

	//Calculating the CRC
	//crc_int   = crc(temp_array,10);
	crc_int   = crc(temp_array,8);
	crc_h     = (crc_int>>8);
	crc_l     = crc_int;
	
	//If Calculated CRC and the CRC from the EEPROM is equal then collect and store to the corresponding variable
	//if((crc_h == temp_array[10]) && (crc_l == temp_array[11]))
	if((crc_h == temp_array[8]) && (crc_l == temp_array[9]))
	{
		DataLogg_Struct.No_of_Records_Cycle_Summary     = Char_To_Integer(temp_array[0],temp_array[1]);
		DataLogg_Struct.cycle_summary_pos			    = Char_To_Integer(temp_array[2],temp_array[3]);
		DataLogg_Struct.cycle_summary_total_data_length = Char_To_Integer(temp_array[4],temp_array[5]);
		EEprom_Read_Date								= Char_To_Integer(temp_array[6],temp_array[7]);
		//Day_Summary_Tick_Count							= char_To_Long_Integer(temp_array[6],temp_array[7],temp_array[8],temp_array[9]);
		if(EEprom_Read_Date != EEprom_Date)
		{
			Day_Summary_Interval_flag    = 1;
			Modbus_Struct.cloud_txd_bit	 = 1;
			MWM_COMMAND_STATUS           = PUT_RDMS_DAY_SUMMARY_BROADCAST;//changing the MWM status to put the Day summary broadcast to the server
			GPS_Location_Status          = AQUIRE_GPS_DATA;
			day_summary_calculation(DataLogg_Struct.cycle_summary_total_data_length,DataLogg_Struct.No_of_Records_Cycle_Summary);//After performing the day summary calculation
			cycle_summary_parameters_eeprom_storage();
		}
	}
	else//else read from the shadow register f EEPROM
	{
		read_cycle_sumry_para_shadow_addr_of_eeprom();
	}
}

void Store_Cycle_Summary_to_Flash_memory(uint16_t cycle_summary_data_length,uint16_t total_number_of_cycle_summary)
{
	uint32_t current_page_address;
	if(total_number_of_cycle_summary<=3)// If number of cycle summary is less than 3 records
	{
		current_page_address = START_PAGE_ADDRESS_FOR_CYCLE_SUMMARY;
		for(uint16_t i=0;i<cycle_summary_data_length;i++)
		{
			Flash_Struct.record_buffer[DataLogg_Struct.cycle_summary_pos] = Modbus_Struct.Day_Summary_buff[i];
			DataLogg_Struct.cycle_summary_pos++;
			if(DataLogg_Struct.cycle_summary_pos>=(cycle_summary_data_length*3))DataLogg_Struct.cycle_summary_pos=0;
		}
		at45dbx_wait_ready();
		flash_buffer1_write();
		at45dbx_wait_ready();
		flash_buffer1_to_main_memory_page_program_with_built_in_erase(current_page_address);
		at45dbx_wait_ready();
	}
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	if(total_number_of_cycle_summary<=6 && total_number_of_cycle_summary>3)//if number of cycle summary is less than 6 and greater than 3 records
	{
		current_page_address = (START_PAGE_ADDRESS_FOR_CYCLE_SUMMARY+1);
		for(uint16_t i=0;i<cycle_summary_data_length;i++)
		{
			Flash_Struct.record_buffer[DataLogg_Struct.cycle_summary_pos] = Modbus_Struct.Day_Summary_buff[i];
			DataLogg_Struct.cycle_summary_pos++;
			if(DataLogg_Struct.cycle_summary_pos>=(cycle_summary_data_length*3))DataLogg_Struct.cycle_summary_pos=0;
		}
		at45dbx_wait_ready();
		flash_buffer1_write();
		at45dbx_wait_ready();
		flash_buffer1_to_main_memory_page_program_with_built_in_erase(current_page_address);
		at45dbx_wait_ready();
	}
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	if(total_number_of_cycle_summary<=9 && total_number_of_cycle_summary>6)//if number of cycle summary is less than 9 records and greater than 6 records
	{
		current_page_address = (START_PAGE_ADDRESS_FOR_CYCLE_SUMMARY+2);
		for(uint16_t i=0;i<cycle_summary_data_length;i++)
		{
			Flash_Struct.record_buffer[DataLogg_Struct.cycle_summary_pos] = Modbus_Struct.Day_Summary_buff[i];
			DataLogg_Struct.cycle_summary_pos++;
			if(DataLogg_Struct.cycle_summary_pos>=(cycle_summary_data_length*3))DataLogg_Struct.cycle_summary_pos=0;
		}
		at45dbx_wait_ready();
		flash_buffer1_write();
		at45dbx_wait_ready();
		flash_buffer1_to_main_memory_page_program_with_built_in_erase(current_page_address);
		at45dbx_wait_ready();
	}
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	if(total_number_of_cycle_summary<=12 && total_number_of_cycle_summary>9)// if number of cycle summary is less than  12 records and greater than 9 records
	{
		current_page_address = (START_PAGE_ADDRESS_FOR_CYCLE_SUMMARY+3);
		for(uint16_t i=0;i<cycle_summary_data_length;i++)
		{
			Flash_Struct.record_buffer[DataLogg_Struct.cycle_summary_pos] = Modbus_Struct.Day_Summary_buff[i];
			DataLogg_Struct.cycle_summary_pos++;
			if(DataLogg_Struct.cycle_summary_pos>=(cycle_summary_data_length*3))DataLogg_Struct.cycle_summary_pos=0;
		}
		at45dbx_wait_ready();
		flash_buffer1_write();
		at45dbx_wait_ready();
		flash_buffer1_to_main_memory_page_program_with_built_in_erase(current_page_address);
		at45dbx_wait_ready();
	}
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	if(total_number_of_cycle_summary<=15 && total_number_of_cycle_summary>12)//if number of cycle summary is less than 15 and greater than 12
	{
		current_page_address = (START_PAGE_ADDRESS_FOR_CYCLE_SUMMARY+4);
		for(uint16_t i=0;i<cycle_summary_data_length;i++)
		{
			Flash_Struct.record_buffer[DataLogg_Struct.cycle_summary_pos] = Modbus_Struct.Day_Summary_buff[i];
			DataLogg_Struct.cycle_summary_pos++;
			if(DataLogg_Struct.cycle_summary_pos>=(cycle_summary_data_length*3))DataLogg_Struct.cycle_summary_pos=0;
		}
		at45dbx_wait_ready();
		flash_buffer1_write();
		at45dbx_wait_ready();
		flash_buffer1_to_main_memory_page_program_with_built_in_erase(current_page_address);
		at45dbx_wait_ready();
		
	}
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	if(total_number_of_cycle_summary<=18 && total_number_of_cycle_summary>15)//if number of cycle summary is less than 18 and greater than 15
	{
		current_page_address = (START_PAGE_ADDRESS_FOR_CYCLE_SUMMARY+5);
		for(uint16_t i=0;i<cycle_summary_data_length;i++)
		{
			Flash_Struct.record_buffer[DataLogg_Struct.cycle_summary_pos] = Modbus_Struct.Day_Summary_buff[i];
			DataLogg_Struct.cycle_summary_pos++;
			if(DataLogg_Struct.cycle_summary_pos>=(cycle_summary_data_length*3))DataLogg_Struct.cycle_summary_pos=0;
		}
		at45dbx_wait_ready();
		flash_buffer1_write();
		at45dbx_wait_ready();
		flash_buffer1_to_main_memory_page_program_with_built_in_erase(current_page_address);
		at45dbx_wait_ready();
	}
	

}

void day_summary_calculation(uint16_t cycle_summary_data_length,uint16_t total_number_of_cycle_summary)
{
	/////////Local variables declaration
	uint16_t temp;uint8_t temp_buff_day_summary[150];uint8_t loop_exec_reg_1=0;/*uint16_t j=0;*/
	uint8_t loop_exec_reg=0;
	
	///////Checking for the loop count to match
	if(total_number_of_cycle_summary<=3)
	{
		temp = (total_number_of_cycle_summary-1);
	}
	else
	{
		temp = (total_number_of_cycle_summary-2);
	}
	if(total_number_of_cycle_summary == 1 || total_number_of_cycle_summary == 0)
	{
		for(uint8_t i=0;i<cycle_summary_data_length;i++)
		{
			temp_buff_day_summary[i] = Modbus_Struct.Day_Summary_buff[i];
		}
	}
	else
	{
		///////Logic to calculate day summary
		for(uint8_t i=0;i<temp;i++)
		{
			///////////////////////////////////////////////////////////////////////// FIRST CONDITION ////////////////////////////////////////////////////////////////////////////
			flash_main_memory_page_read(START_PAGE_ADDRESS_FOR_CYCLE_SUMMARY,0);
			if(loop_exec_reg_1 == 0)
			{
				loop_exec_reg_1 = 1;
				
				for(uint16_t i=0,j=0;i<cycle_summary_data_length;i++,j++)
				{
					temp_buff_day_summary[j] = MAX(Flash_Struct.download_buffer[j],Flash_Struct.download_buffer[j+cycle_summary_data_length]);
				}
			}
			else
			{
				if(loop_exec_reg_1 == 1)
				{
					loop_exec_reg_1 = 2;
					
					for(uint16_t i=0,j=0;i<cycle_summary_data_length;i++,j++)
					{
						temp_buff_day_summary[j] = MAX(temp_buff_day_summary[j],Flash_Struct.download_buffer[j+(cycle_summary_data_length*2)]);
					}
				}
						////////////////////////////////////////////////////////////////////////////// SECOND CONDITION ////////////////////////////////////////////////////////////////////////////
				if(total_number_of_cycle_summary>3)
				{
					flash_main_memory_page_read((START_PAGE_ADDRESS_FOR_CYCLE_SUMMARY+1),0);
					if(loop_exec_reg == 0)
					{
						loop_exec_reg = 1;
						
						for(uint16_t i=0,j=0;i<cycle_summary_data_length;i++,j++)
						{
							temp_buff_day_summary[j] = MAX(temp_buff_day_summary[j],Flash_Struct.download_buffer[j]);
						}
					}
					else if(loop_exec_reg == 1)
					{
						loop_exec_reg = 2;
						
						for(uint16_t i=0,j=0;i<cycle_summary_data_length;i++,j++)
						{
							temp_buff_day_summary[j] = MAX(temp_buff_day_summary[j],Flash_Struct.download_buffer[j+(cycle_summary_data_length)]);
						}
					}
					else if(loop_exec_reg == 2)
					{
						loop_exec_reg = 3;
						
						for(uint16_t i=0,j=0;i<cycle_summary_data_length;i++,j++)
						{
							temp_buff_day_summary[j] = MAX(temp_buff_day_summary[j],Flash_Struct.download_buffer[j+(cycle_summary_data_length*2)]);
						}
					}
					////////////////////////////////////////////////////////////////////////////// THIRD CONDITION ////////////////////////////////////////////////////////////////////////////
					if(total_number_of_cycle_summary>6)
					{
						flash_main_memory_page_read((START_PAGE_ADDRESS_FOR_CYCLE_SUMMARY+2),0);
						if(loop_exec_reg == 3)
						{
							loop_exec_reg = 4;
							for(uint16_t i=0,j=0;i<cycle_summary_data_length;i++,j++)
							{
								temp_buff_day_summary[j] = MAX(temp_buff_day_summary[j],Flash_Struct.download_buffer[j]);
							}
						}
						else if(loop_exec_reg == 4)
						{
							loop_exec_reg = 5;
							for(uint16_t i=0,j=0;i<cycle_summary_data_length;i++,j++)
							{
								temp_buff_day_summary[j] = MAX(temp_buff_day_summary[j],Flash_Struct.download_buffer[j+(cycle_summary_data_length)]);
							}
						}
						else if(loop_exec_reg == 5)
						{
							loop_exec_reg = 6;
							for(uint16_t i=0,j=0;i<cycle_summary_data_length;i++,j++)
							{
								temp_buff_day_summary[j] = MAX(temp_buff_day_summary[j],Flash_Struct.download_buffer[j+(cycle_summary_data_length*2)]);
							}
						}
						////////////////////////////////////////////////////////////////////////////// FOURTH CONDITION ////////////////////////////////////////////////////////////////////////////
						if(total_number_of_cycle_summary>9)
						{
							flash_main_memory_page_read((START_PAGE_ADDRESS_FOR_CYCLE_SUMMARY+3),0);
							if(loop_exec_reg == 6)
							{
								loop_exec_reg = 7;
								for(uint16_t i=0,j=0;i<cycle_summary_data_length;i++,j++)
								{
									temp_buff_day_summary[j] = MAX(temp_buff_day_summary[j],Flash_Struct.download_buffer[j]);
								}
							}
							else if(loop_exec_reg == 7)
							{
								loop_exec_reg = 8;
								for(uint16_t i=0,j=0;i<cycle_summary_data_length;i++,j++)
								{
									temp_buff_day_summary[j] = MAX(temp_buff_day_summary[j],Flash_Struct.download_buffer[j+(cycle_summary_data_length)]);
								}
							}
							else if(loop_exec_reg == 8)
							{
								loop_exec_reg = 9;
								for(uint16_t i=0,j=0;i<cycle_summary_data_length;i++,j++)
								{
									temp_buff_day_summary[j] = MAX(temp_buff_day_summary[j],Flash_Struct.download_buffer[j+(cycle_summary_data_length*2)]);
								}
							}
							////////////////////////////////////////////////////////////////////////////// FIFTH CONDITION ////////////////////////////////////////////////////////////////////////////
							if(total_number_of_cycle_summary>12)
							{
								flash_main_memory_page_read((START_PAGE_ADDRESS_FOR_CYCLE_SUMMARY+4),0);
								if(loop_exec_reg == 9)
								{
									loop_exec_reg = 10;
									for(uint16_t i=0,j=0;i<cycle_summary_data_length;i++,j++)
									{
										temp_buff_day_summary[j] = MAX(temp_buff_day_summary[j],Flash_Struct.download_buffer[j]);
									}
								}
								else if(loop_exec_reg == 10)
								{
									loop_exec_reg = 11;
									for(uint16_t i=0,j=0;i<cycle_summary_data_length;i++,j++)
									{
										temp_buff_day_summary[j] = MAX(temp_buff_day_summary[j],Flash_Struct.download_buffer[j+(cycle_summary_data_length)]);
									}
								}
								else if(loop_exec_reg == 11)
								{
									loop_exec_reg = 12;
									for(uint16_t i=0,j=0;i<cycle_summary_data_length;i++,j++)
									{
										temp_buff_day_summary[j] = MAX(temp_buff_day_summary[j],Flash_Struct.download_buffer[j+(cycle_summary_data_length*2)]);
									}
								}
								////////////////////////////////////////////////////////////////////////////// SIXTH CONDITION ////////////////////////////////////////////////////////////////////////////
								if(total_number_of_cycle_summary>15)
								{
									flash_main_memory_page_read((START_PAGE_ADDRESS_FOR_CYCLE_SUMMARY+5),0);
									if(loop_exec_reg == 12)
									{
										loop_exec_reg = 13;
										for(uint16_t i=0,j=0;i<cycle_summary_data_length;i++,j++)
										{
											temp_buff_day_summary[j] = MAX(temp_buff_day_summary[j],Flash_Struct.download_buffer[j]);
										}
									}
									else if(loop_exec_reg == 13)
									{
										loop_exec_reg = 14;
										for(uint16_t i=0,j=0;i<cycle_summary_data_length;i++,j++)
										{
											temp_buff_day_summary[j] = MAX(temp_buff_day_summary[j],Flash_Struct.download_buffer[j+(cycle_summary_data_length)]);
										}
									}
									else if(loop_exec_reg == 14)
									{
										loop_exec_reg = 15;
										for(uint16_t i=0,j=0;i<cycle_summary_data_length;i++,j++)
										{
											temp_buff_day_summary[j] = MAX(temp_buff_day_summary[j],Flash_Struct.download_buffer[j+(cycle_summary_data_length*2)]);
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	for(uint8_t i=0;i<cycle_summary_data_length;i++)
	{
		Modbus_Struct.Day_Summary_buff[i] = temp_buff_day_summary[i];
	}
	loop_exec_reg   = 0;
	loop_exec_reg_1 = 0;
}

#endif /* DATALOGG_H_ */