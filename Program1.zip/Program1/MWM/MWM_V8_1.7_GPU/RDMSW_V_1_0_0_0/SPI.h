#ifndef _SPI_H_
#define _SPI_H_
#include "HEADERS.H"

void SPI_Byte_Send();
void at45dbx_wait_ready(void);
unsigned long int write_page_address;
unsigned char page_address_lo,page_address_hi;

/*
void SPI_Byte_Send(void)
{
	uint16_t temp;
	CLR_BIT(PORTD_OUT,0);//Flash Slave Select Set as High 
	SPIC_DATA='A';
	while(Recieved_Flag==0)
	{
		temp=SPIC_STATUS;
	}
	Recieved_Flag=0;
	temp=SPIC_DATA;
	SET_BIT(PORTD_OUT,0);//Flash Slave Select Set as High 
}
*/

void Global_Int_En(void)
{
	
	PMIC_CTRL|=PMIC_HILVLEN_bm|PMIC_MEDLVLEN_bm|PMIC_LOLVLEN_bm;// Activating the High Medium Low level Interrupts in the Controller
	SREG|=0x80;//Glbal interrupt enable register
	
}

void write_flash(uint32_t PageAddress)
{
	flash_buffer1_write();				//put the data in to flash buffer
 	at45dbx_wait_ready();
	_delay_ms(10);
 	flash_buffer1_to_main_memory_page_program_with_built_in_erase(PageAddress);	//write flash
	_delay_ms(10);
	at45dbx_wait_ready();
}

void at45dbx_wait_ready(void)
{
	uint8_t status;
	
	// Select the DF memory at45dbx_gl_ptr_mem points to.
	PORTD_OUT &= 0xFE;

	// Send the Status Register Read command.
	status = putspi(AT45DBX_CMDC_RD_STATUS_REG);
	// Read the status register until the DF is ready.
	do {
		// Send a dummy byte to read the status register.
		status = putspi(0x55);
	   } while ((status & AT45DBX_MSK_BUSY) == AT45DBX_BUSY);

	// Unselect the DF memory at45dbx_gl_ptr_mem points to.
	PORTD_OUT |= 0x01;
}
 
#endif