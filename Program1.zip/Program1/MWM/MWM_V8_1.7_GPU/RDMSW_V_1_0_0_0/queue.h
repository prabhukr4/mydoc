#ifndef _QUEUE_H_
#define _QUEUE_H_

///****************************************************
//Function definition for Write and Read form a Buffer
//*****************************************************/
unsigned char  write_queue(unsigned char *data,unsigned char Qcnt);
unsigned char *read_queue(unsigned char Qin);

/*************************************************
Function declaration for Write to the Queue buffer
**************************************************/
unsigned char write_queue(unsigned char *data, unsigned char Qcnt)
{	
	Qstart = data;
	Qout = Qin = Qstart;
	unsigned char i;
	while(*data != '\0')
	{
		Queue_buff[i] = *data++;
		i++;
		Qin++;
		
		if (Queue_buff[Qcnt] == Queue_buff[Qin])
		{
			return Qin;
		}
		
	}
}
/*************************************************
Function declaration for Read to the Queue buffer
**************************************************/
unsigned char *read_queue(unsigned char Qin)
{
	Qout = Qin-1;
	Qout = Qin - Qout;
	int i;
	for(i=Qout;i<=Qcnt;i++)
	{
		Queue_buff[i];
	}
	if(Qout == Qin)
	{
		Qin = Qout = Qstart;
	}
	return Queue_buff;
	
}
#endif