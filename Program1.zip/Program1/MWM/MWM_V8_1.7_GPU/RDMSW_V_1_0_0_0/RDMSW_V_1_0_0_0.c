//--------------------------------------------------------------------------------------------------//
//							Pin Description															//
//--------------------------------------------------------------------------------------------------//
//	Pin Number		    Pin Details					Pin Description									//
//--------------------------------------------------------------------------------------------------//
//		1				PA5						Analog Input 1										//
//		2				PA6						Analog Input 2										//
//		3				PA7						Analog Input 3										//
//		4				PB0						Analog Reference Voltage 2							//
//		5				PB1						Analog Input 4										//
//		6				PB2						DAC1												//
//		7				PB3						DAC2												//
//		8				GND																			//
//		9				VCC																			//
//		10				PC0						RTC_SDA												//
//		11				PC1						RTC_SCL												//
//		12				PC2						Touch Rxd (TTL)										//
//		13				PC3						Touch Txd (TTL)										//
//		14				PC4						Digital Output 1									//
//		15				PC5						MOSI												//
//		16				PC6						MISO												//
//		17				PC7						SCK													//
//		18				GND																			//
//		19				VCC																			//
//		20				PD0						Flash CS											//
//		21				PD1						Digital Output 4									//
//		22				PD2						GSM Txd (TTL)										//
//		23				PD3						GSM Rxd (TTL)										//
//		24				PD4						Digital Output 2									//
//		25				PD5						Digital Output 3									//
//		26				PD6						MCU Rxd (RS232 or RS485)							//
//		27				PD7						MCU Txd (RS232 or RS485)							//
//		28				PE0						MC Reset											//
//		29				PE1						Status LED											//
//		30				GND																			//
//		31				VCC																			//
//		32				PE2						RF Txd / Data Enable								//
//		33				PE3						RF Rxd												//
//		34				PDI_D					PDI_D Programming Data								//
//		35				PDI_C(RESET)			PDI_c Programming Control							//
//		36				PR0(XTAL2)																	//
//		37				PR1(XTAL1)																	//
//		38				GND																			//
//		39				VCC																			//
//		40				PA0						Analog Reference Voltage 1							//
//		41				PA1						Digital Input 4										//
//		42				PA2						Digital Input 3										//
//		43				PA3						Digital Input 2										//
//		44				PA4						Digital Input 1										//
//--------------------------------------------------------------------------------------------------//
//							Document History														//
//--------------------------------------------------------------------------------------------------//
//							MWM_V8_V1.7																//
//--------------------------------------------------------------------------------------------------//
//	1. GPS Validation Included																		//
//	2. Providing check points for Parameter broadcast with maximum possible data					//
//	3. Designed to overcome the Invalid data send to RDMS Termination.								//
//	4. Providing check points for Parameter broadcast with maximum possible data					//
//--------------------------------------------------------------------------------------------------//
//							MWM_V8_V1.6																//
//--------------------------------------------------------------------------------------------------//
//	1. Access Point Address changed via SMS Setting to internally for sending APN Setting and		//
//	Activate GPRS for USA SIM Card with 6 APN 														//
//	2. APN Settings Changed as per request from Sir(VP and Rajamurugan)								//
//		i) 	AIRTEL India - airtelgprs.com															//
//		ii)	VODAFONE USA - internetd.gdsp															//
//		iii)	M2M USA - m2m005067.attz															//
//		iv)	Verzion1 USA  - vzwinternet																//
//		v)	Verzion2 USA - TRACFONE.VZWENTP															//
//		vi)	BSNL India - bsnllive																	//
//--------------------------------------------------------------------------------------------------//
//							MWM_V8_V1.5																//
//--------------------------------------------------------------------------------------------------//
//	1. Send request to get parameter, info and summary via sms implementation						//
//--------------------------------------------------------------------------------------------------//
//							MWM_V8_V1.4																//
//--------------------------------------------------------------------------------------------------//
//	1. Baud rate changed to 19200 instead of 115200													//
//	2. Data Logging software tested																	//
//--------------------------------------------------------------------------------------------------//
//							MWM_V8_V1.3																//
//--------------------------------------------------------------------------------------------------//
//	1. Version Number provided via SMS notification													//
//	2. 3G to 4G Conversion Implantation																//
//--------------------------------------------------------------------------------------------------//
//								MWM_V8																//
//--------------------------------------------------------------------------------------------------//
//	1. New Design																					//
//	2. SMS functional implementation																//
//	3. APN Settings for cloud problem addressed and solved											//
//--------------------------------------------------------------------------------------------------//

#include "HEADERS.H"

int main(void)
{
	RDMSW_SYS_Init					();//Initializations of RDMSW system's Digital inputs,outputs,internal or external crystal etc..,
	Act_Uart_Cmmn					();//Activating the UART Communication
	Act_Clk_Tick_Timer				();//Activating the clock tick Timer
	Global_Int_En					();//Enabling the global interrupt level of Low,medium,High priority	
	init_buff						();//Initializations of all buffer values to 
	Store_APN_Config_and_IP_Details	();//Storing the APN settings to EEPROM 
	Check_Collect_EEPROM_From_Actual_Data_Register();//Collect the Product ID from the EEPROM
	read_cycle_sumry_para_actual_addr_of_eeprom();//reading cycle summary flash parameter from EEPROM
	Collect_page_address_queue_pos_from_EEPROM_actual_register(&Flash_Struct.ui32Current_Page_address,&Flash_Struct.Current_Que_In_Pos,&DataLogg_Struct.No_of_Records_Parameter,ACTUAL_START_PAGE_EEPROM_ADDRESS_FOR_PARAMETER,SHADOW_START_PAGE_EEPROM_ADDRESS_FOR_PARAMETER);
	collect_dig_out_status_frm_eeprom();//Collecting the digital output status from the EEPROM and fixing the corresponding to the same
	while(1)
	{
		checking_query_function ();//checking if any query from RDMS is reaching MWM. If yes corresponding function will execute
  		collect_data			();//Collecting the analog/digital inputs and outputs values
   		equip_status_exec		();//Executing the step by step status of Equipment side communication
  		gsm_status_exec			();//Executing the GSM Status functions
  		mwm_status_exec			();//Executing the MWM Status functions
		Data_Vaildation			();
 		sms_function			();//SMS reading and sending functions
	}
	return 0;
}


