#ifndef _MAIN_FUNCTIONS_H_
#define _MAIN_FUNCTIONS_H_
#include "HEADERS.H"

/******************************************************************************************************************************************************
Program: MAK WIRELESS MODULE(MWM) CONTROL LOGIC

Function Name: GSM_Status_Exec()

Function Description : This function which initialize all needed Functions in GSM by passing Suitable
AT commands if the commands is not returns OK  or respective positive response then the commands are 
passed up to the Maximum retry which was defined in definition file.

Parameters : None

List of AT Commands Used in this Function Note---> the following sequence only the commands executed for GSM initialization
1.AT 
2. ATE0 
3. AT+CREG? 
4.AT+CMGF = 1 
5. AT+CNMI = 1,1,0,0 
6.AT+CMGD = 1,4
7.AT+CSAS
8.AT#GPRS = 0
9.AT#GPRS = 1
10.AT#SCFG = 1,1,1500,0,60,50
11.AT#SCFGEXT = 1,3,0,0,0,0
12.AT#SD = 1,1,5038,\"54.173.19.24\",0,55038,1
13.AT$GPSP = 1
14.AT$GPSD = 2
15.AT$GPSSAV
16.AT+CGSN
17.AT+CPBR = 1
18.AT#GPRS?
*********************************************************************************************************************************************************/
void gsm_status_exec(void)
{
	switch(GSM_COMMAND_STATUS)
	{
		case SEND_GSM_INIT_AT:// Giving "AT" Command to GSM which tells the GSM is active or not
		GSM_AT_Cmd();
		break;
		
		case WAIT_FOR_GSM_AT_RESPONSE:
		delay_flag = 1;// Giving 100 ms delay
		if(Tick_count>=10)
		{
			Tick_count = 0;
			delay_flag = 0;
			GSM_AT_Check();// Checking that if "OK" string received form the GSM
		}
		break;
		
		case SEND_GSM_ECO_OFF://ATE0
		GSM_AT_ECO_OFF_Cmd();// Sending ECHO OFF command to GSM - which deactivate the command that have given to GSM from controller that getting back to the controller
		break;
		
		case WAIT_FOR_GSM_ECOOFF_RESPONSE:
		delay_flag = 1;
		if(Tick_count>=10)//Giving 100 ms delay to get the response
		{
			Tick_count = 0;
			delay_flag = 0;
			GSM_Echo_Check();// Checking that if "OK" string received form the GSM
		}
		break;
		
		case SEND_GSM_NETWORK_REGISTRATION://AT+CREG?
		GSM_AT_NETWRK_REG_Cmd();//Network Registration Command which will check if the SIM card is connected to network or not.
		break;
		
		case WAIT_FOR_GSM_NET_REG_RESPONSE:
		delay_flag = 1;
		if(Tick_count>=20)
		{
			Tick_count = 0;
			delay_flag = 0;
			Get_NetWrk_Status_Check();//Checking that if "+CREG : 0,1" string received from the GSM module. if received then the SIM card is registered with home network.
		}
		break;
		
		case SEND_GSM_SMS_MODE_CMD://AT+CREG?
		//GSM_AT_SMS_REG_Cmd();//Network Registration Command which will check if the SIM card is connected to network or not.
		send_gsm_CSMP_config();
		break;
		
		case WAIT_SMS_MODE_CMD_RES:
		delay_flag = 1;
		if(Tick_count>=20)
		{
			Tick_count = 0;
			delay_flag = 0;
			//Get_SMS_Status_Check();//Checking that if "+CREG : 0,1" string received from the GSM module. if received then the SIM card is registered with home network.
			GSM_CSMP_Check();
		}
		break;
		
		case SMS_INITIALIZATION_COMMANDS://Set of commands which is used for SMS initialization
		sms_init();
		break;
		
		case GSM_GPRS_DEACTIVATE_CMD:
		GPRS_DeActivate_cmd();//Command which deactivate the GPRS
		break;
		
		case WAIT_FOR_GPRS_DEACTIVATE_CMD://OK
		delay_flag = 1;
		if(Tick_count>=100)
		{
			delay_flag = 0;
			Tick_count = 0;
			Get_GPRS_Deactivate_Check();// Checking OK response from GSM
		}
		break;
		
		case SEND_GSM_GPRS_ACTIVATE_CMD://AT#GPRS=1
		GPRS_Activate_cmd();//Issuing this command will activate the GPRS content of the GSM
		break;
		
		case WAIT_FOR_GPRS_ACTIVATE_CMD:
		delay_flag = 1;
		if(Tick_count>=300)
		{
			Tick_count = 0;
			delay_flag = 0;
			Get_GPRS_STATUS_CHECK();//Checking the String "+IP:" has been received from GSM which tells that GPRS is activated in the network. If not then GPRS activated command will given to the GSM
		}
		break;
		
		case SEND_SOCKET_CONFIGURATION://AT#SCFG = 1,1,1500,0,60,50
		send_gsm_skt_config();//Giving this command will set the socket configurations like GPRS inactivity time out,Maximum number of data that we transmitting to cloud,
		break;
		case WAIT_FOR_SKT_RESPONSE:
		delay_flag = 1;
		if(Tick_count>=10)
		{
			Tick_count = 0;
			delay_flag = 0;
			get_socket_config_check();//Checking for OK response form GSM
		}
		break;
		
		case SEND_GSM_SOCKET_CONFIG_EXT://AT#SCFGEXT = 1,3,0,0,0,0
		GSM_Module_UDP_Init();//Giving this Command will set the Protocol type,Connection ID, RECEIVE MOLE.
		break;
		
		case WAIT_FOR_SOCKET_CONFIG_RESPONSE:
		delay_flag = 1;
		if(Tick_count>=10)
		{
			Tick_count = 0;
			delay_flag = 0;
			Get_Socket_Status_Check();// Checking for OK response form GSM
		}
		break;
		
		case SEND_SOCKET_DIAL://AT#SD = 1,1,5038,\"54.173.19.24\",0,55038,1
		GSM_SOCKET_DIAL();//This command will dial the socket to particular Port address and IP that the MWM wants to communicate with
		break;
		
		case WAIT_FOR_SOCKET_DIAL_RESPONSE:
		delay_flag = 1;
		if(Tick_count>=10)
		{
			Tick_count = 0;
			delay_flag = 0;
			Get_Socket_Dial_Status_Check();// Checking for OK response form GSM
		}
		break;
		
		case SEND_GSM_GPS_POWER_ON_CMD://AT$GPSP = 1
		GSM_GPS_Mod_Power_On();//Power Mode ON the GPS
		break;
		
		case WAIT_FOR_GPS_POWER_ON_CMD:
		delay_flag = 1;
		if(Tick_count>=10)
		{
			Tick_count = 0;
			delay_flag = 0;
			GPS_Power_on_Chk();// Checking for OK response form GPS
		}
		break;
		
		case SEND_GSM_GPS_CTRL_MOD://AT$GPSD = 2
		GSM_GPS_Mod_Cntrl_mode();//This command will set GPS Device Type Set as 2 which will set the GPS serial port connected to the GNSS serial port
		break;
		
		case WAIT_FOR_GPS_CTRL_MOD:
		delay_flag = 1;
		if(Tick_count>=10)
		{
			Tick_count = 0;
			delay_flag = 0;
			GPS_Ctrl_Mode_Chk();//Checking for OK response from GPS
		}
		break;
		
		case SEND_GSM_GPS_SAVE://AT$GPSSAV
		GSM_GPS_Save_Settings();// Save the settings that have been done for GPS
		break;
		
		case WAIT_FOR_GPS_SAVE:
		delay_flag = 1;
		if(Tick_count>=10)
		{
			Tick_count = 0;
			delay_flag = 0;
			GPS_Save_Settings_Chk();// Checking for OK response from GPS
		}
		break;
		
		case GET_IMEI_NUM_FROM_GSM://AT+CGSN
		get_imei_frm_gsm();//Getting IMEI number from the GSM
		break;
		
		case STORE_IMEI_FROM_GSM://Storing the received IMEI number in RAM
		delay_flag=1;
		if(Tick_count>=20)
		{
			delay_flag = 0;
			Tick_count = 0;
			store_imei_in_buff();
		}
		break;
		
		case GET_MOBILE_NUMBER://AT+CPBR=1
		get_mob_num_from_sim();//Getting the mobile number which is stored in the first location
		break;
		
		case STORE_MOBILE_NUMBER:
		delay_flag=1;
		if(Tick_count>=20)
		{
			delay_flag = 0;
			Tick_count = 0;
			store_mob_num_in_buff();//Storing the Number in an Array
		}
		break;

		case GPRS_CHECK_STATUS://AT#GPRS?
		delay_flag=1;
		if(Tick_count >= 50)
		{
			Tick_count = 0;
			delay_flag = 0;
			GSM_GPRS_Act_Deact_Check_Cmd();// This command will check the GPRS status of the Network which is connected with the Module
		}
		break;
		
		case WAIT_FOR_GPRS_CHECK_STATUS://Response - #GPRS: x (x=0(Not Activated) or 1(Activated))
		delay_flag=1;
		if(Tick_count>=20)
		{
			Tick_count = 0;
			delay_flag = 0;
			GSM_GPRS_Act_Deact_Find();
		}
		break;
		
		case APN_SETTINGS:
		GPRS_ACTIVATION_APN_Cmd();		//Send APN to GSM Modem
		break;
				
		case IDEAL_STATUS:// Do nothing
		break;
		
		default:
		break;
	}
}

/****************************************************************************************************
Program: MAK WIRELESS MODULE(MWM) CONTROL LOGIC

Function Name: MWM_Status_Exec()

Function Description : This function which Communicates with UDP by Passing Ping command  
at first and register itself to server after acknowledgment has been received
then corresponding next status will execute.

Parameters : None
*****************************************************************************************************/
/*PLEASE REFER PROTOCOL DOCUMENT FOR THE BYTE ALLOCATION FOR EACH PARAMETERS*/
void mwm_status_exec(void)
{
	switch(MWM_COMMAND_STATUS)
	{
		case PUT_RDMS_PING_COMMAND:
		Mode_A_PING_Command();//Ping command - which tells the server about its  dynamic IP obtained from network and tells the server this product is in on line
		break;
		case WAIT_FOR_RDMS_PING_ACK:
		CHK_RDMS_PING_ACK();//Waiting for acknowledgment from the server (time out 10 seconds)
		break;
		case PUT_RDMS_INFO_BROADCAST:
		MODE_A_INFO_BroadCast();//Info command - which will broadcast the entire informations about the Control panel of the unit
		break;
		case WAIT_FOR_RDMS_INFO_ACK:
		CHK_RDMS_INFO_ACK();//Waiting for acknowledgment from the server (time out 10 seconds)
		break;
		case PUT_RDMS_PARAMETERS_BROADCAST:
		MODE_A_Parameters_BroadCast();//Parameters Broadcast - Which transmit the entire parameters of the unit that is connected with MWM 
		break;
		case WAIT_FOR_RDMS_PARAMETERS_ACK:
		CHK_RDMS_PARAMETER_ACK();//Waiting for acknowledgment from the server (time out 10 seconds)
		break;
		case PUT_RDMS_DAY_SUMMARY_BROADCAST:
		MODE_A_Day_Summary_BroadCast();//Cycle summary and Day summary broadcast in the same function
		break;
		case WAIT_FOR_RDMS_DAY_SUMMARY_ACK:
		CHK_RDMS_DAYSUMMARY_ACK();//Waiting for acknowledgment from the server (time out 10 seconds)
		break;
		case PUT_RDMS_FAULT_WARNG_BROADCAST:
		MODE_A_Warning_Fault_Braodcast();//Fault and Warning broadcast - Once any fault present in the control panel this function will transmit the fault info to the server and for detailed fault and Warning mapping please refer Protocol document
		break;
		case WAIT_FOR_RDMS_FAULT_WARNG_ACK:
		CHK_RDMS_FAULT_WARNING_ACK();//Waiting for acknowledgment from the server (time out 10 seconds)
		break;
		case PUT_RDMS_SNAPSHOT_BROADCAST:
		SnapShot_Broadcast();//If any fault present in the equipment then a snapshot message will trigger from MWM which has 10 Parameter records before the fault happens and after fault happens
		break;
		case WAIT_FOR_SNAPSHOT_BROADCAST:
		CHK_RDMS_SNAPSHOT_ACK();// Waiting for the acknowledgment from the server(time out 10 seconds )
		break;
		case PROCESS_CONFIGURE_CMD:
		Process_Configure_Cmd();//Configure command which is used to configure the configuration of the equipment
		break;
		case MODE_C_RESPONSE:
		Mode_C_Response();//Giving the configuration command response to server
		break;
		case CHK_MODE_C_RESPONSE_FROM_UDP:
		CHK_RDMS_MODE_C_RESPONSE();//Waiting for the response from server for the response given for configure command
		break;
		case PROCESS_CONTROL_COMMAND://Control command will hold all control bytes to control the Analog output and Digital Output		
		Process_Control_Cmd();
		break;
		case SEND_CONTROL_COMMAND_RESPONSE:
		Mode_D_Response();//Giving response to the control command 
		break;
		case PROCESS_CONTROL_COMMAND_RESPONSE_FROM_UDP:
		CHK_RDMS_MODE_D_RESPONSE();//Waiting for the response from server 
		break;
		case CALCULATE_FOR_PERIODIC_INTERVAL:
		periodical_interval_function();//Calculating the periodical functions that should transmit to server at some periodical interval
		break;
		case EMPTY_STATUS_FOR_MWM://If any invalid command that the MWM receiving then it will come to this status and after 5 seconds the ping command will transmit to server
		Ping_interval_flag = 1;
		if(Ping_interval >= 500)
		{
			Ping_interval_flag = 0;
			Ping_interval      = 0;
			MWM_COMMAND_STATUS = CALCULATE_FOR_PERIODIC_INTERVAL;
		}
		break;
		case SEND_GSM_SMS_MODE:
		break;
		default:
		break;
	}
}
/*****************************************************************************************************
Program: MAK WIRELESS MODULE(MWM) CONTROL LOGIC

Function Name: Equip_Status_Exec()

Function Description : All the commands which is communicating with the Equipment is declared 
in the below functions.

Parameters : None
*****************************************************************************************************/
void equip_status_exec(void)
{
	equip_comm_flag = 1;//Setting this flag will increment the equip_comm_counter variable in interrupt for every 10 ms
	if(equip_comm_counter >= TIME_INTERVAL_FOR_EQUIP_COMM)//Checking if the equip_comm_counter is reached 500 ms 
	{
		equip_comm_flag    = 0;//Making the flag to zero because it should be reset for every communication
		equip_comm_counter = 0;//Making the counter variable to zero
		switch(ucModCommandStatus)//switching the ucModCommandStatus which is the status variable for Equipment side Communication
		{
			case SEND_PING:
			Ping_Command();//Ping command - Which will check the presence of the Equipment
			break;
			case WAIT_EQUIP_RESPONSE_FOR_PING:
			CHK_MOD_PING_CMD();//Waiting for the response for Ping command from the equipment and if the response got then the processing of the function will carnied out in this function
			break;
			case SEND_INFO:
			Get_MAK_Prod_Info();//Info Command - This command will have the informations of the control panel that is fitted in the Unit
			break;
			case WAIT_EQUIP_RESPONSE_FOR_INFO://Note - All the register like parameters,Cycle summary etc., will also send by the equipment in this Command response only
			CHK_MOD_INFO_CMD();//Waiting for the response for Info command from the equipment and if the response got then the collected informations will store in the EEPROM 
			break;
			case SEND_PARAMETER://The parameter command will send once for every 5 seconds to equipment and if fault present & broadcasting is ON then it will collect the parameters for every 1 second
 			Equipment_Parameter_delay_flag = 1;
 			if(Equipment_Parameter_interval >= 100 || (Fault_Warning_present_flag == 1 && Fault_Warning_Query_Bit==1) || Start_Broadcasting_flag == 1 || Fault_Warning_present_flag == 1 || Snapshot_Broadcast_Flag == 1)
 			{
 				Equipment_Parameter_delay_flag = 0;
 				Equipment_Parameter_interval   = 0;
				Get_MAK_Prod_Para_Info(((Config_struct.Parameters_start_page>>8)&0xFF),((Config_struct.Parameters_start_page)&0xFF),((Config_struct.Parameters_No_Regtrs_to_read>>8)&0xFF),((Config_struct.Parameters_No_Regtrs_to_read)&0xFF));
			}
			/*else
			{
				ucModCommandStatus = ANA_DIG_IO_STATUS_TXMSN;//If the timeout is not reached to getting the parameters from the equipment it will send the analog digital values
			}*/
			break;
			case WAIT_EQUIP_RESPONSE_FOR_PARAMETER:
			CHK_MOD_PARAMETERS_CMD();//All the parameters of the equipment like engine rpm, Oil pressure etc., will get from this command and it will store in a buffer
			break;
			case SEND_CYCLE_SUMMARY://For every Engine ON and OFF a cycle summary will trigger to the server which will have the minimum maximum values of all the parameters
			Get_MAK_Prod_Para_Info(((Config_struct.Cycle_Summary_Start_page>>8)&0xFF),((Config_struct.Cycle_Summary_Start_page)&0xFF),((Config_struct.Cycle_Summary_No_Regtrs_to_read>>8)&0xFF),((Config_struct.Cycle_Summary_No_Regtrs_to_read)&0xFF));
			break;
			case WAIT_EQUIP_RESPONSE_FOR_CYCLE_SUMMARY:
			CHK_MOD_CYCLE_SUMMARY_CMD();//Storing the response of the cycle summary in a array to transmit to the server
			break;
			case SEND_FAULT_WARNING://Collecting fault and warning from the equipment  ----> Please refer protocol document for fault and warning condition bits mapping
			Get_MAK_Prod_Para_Info(((Config_struct.Fault_Warning_Start_Page>>8)&0xFF),((Config_struct.Fault_Warning_Start_Page)&0xFF),((Config_struct.Fault_Warning_No_Regtrs_to_read>>8)&0xFF),((Config_struct.Fault_Warning_No_Regtrs_to_read)&0xFF));
			break;
			case WAIT_EQUIP_RESPONSE_FOR_FAULT_WARNG:
			CHK_MOD_FAULT_WARNING_CMD();//Storing the fault and warning condition bits in a array
			break;
			case ANA_DIG_IO_STATUS_TXMSN:
			Put_MAK_Prod_Para_Info(0x10,0xCB,0x00,0x08,0x10,Temp_Buffer);//Writing to the Slave the digital and analog inputs outputs values present in the MWM board.
			break;
			case WAIT_ANA_DIG_IO_STATUS_RESPONSE:
			CHK_ANA_DIG_STATUS_TXMSN_CMD();//Waiting for the response from the slave
			break;
			case CLEAR_BIT_STATUS:
			clear_bit_position();//Clearing the bit if any additional information like fault and warning , cycle summary bit is set in the ping register response.
			break;
			case WAIT_CLEAR_BIT_RESPONSE:
			chk_clear_bit_response();//Waiting for the response
			break;
			case SEND_CONFIG_INFO_TO_EQUIPMENT:
			Send_the_config_From_UDP_to_Equipment();//Writing the configurations to the equipment if the configurations is received from the server to MWM
			break; 
			case WAIT_EQUIP_RESPONSE_FOR_UDP_CONFIG:
			CHK_MOD_WRITE_CONFIG_TO_EQUIPMENT();//Waiting for the response from the Equipment
			break;
			case EMPTY_STATUS_FOR_EQUIPMENT:
			break;
			default:
			break;
		}
	}
}

void collect_data(void)//Which is implemented for 180 KVA GPU - Socket 2 AC current
{
	///////////////////////////////////////////  ADC  ////////////////////////////////////////////////
	Average_ADC_Value_CH0();
	ADC_Struct.ADC0_Read_Val = (ADC_Res_CH0 - 190);//collect channel 0  ADC value
	if(ADC_Struct.ADC0_Read_Val > 5000) ADC_Struct.ADC0_Read_Val = 0;
	Average_ADC_Value_CH1();
	ADC_Struct.ADC1_Read_Val = (ADC_Res_CH1 - 190);//collect channel 1  ADC value
	if(ADC_Struct.ADC1_Read_Val > 5000) ADC_Struct.ADC1_Read_Val = 0;
	Average_ADC_Value_CH2();
	ADC_Struct.ADC2_Read_Val = (ADC_Res_CH2 - 190);//collect channel 2  ADC value
	if(ADC_Struct.ADC2_Read_Val > 5000) ADC_Struct.ADC2_Read_Val = 0;
	Average_ADC_Value_CH3();
	ADC_Struct.ADC3_Read_Val = (ADC_Res_CH3 - 190);//collect channel 3  ADC value	
	if(ADC_Struct.ADC3_Read_Val > 5000) ADC_Struct.ADC3_Read_Val = 0;
	
	///////////////////////////////////  DAC  /////////////////////////////////////////////////////
	DAC_Struct.DAC0_write_Val = DACB_CH0DATA;//Collect channel 0 DAC value
	DAC_Struct.DAC1_write_Val = DACB_CH1DATA;//collect channel 1 DAC value
	
	//////////////////////////////////// DIGITAL OUTPUTS ////////////////////////////////////////////////////////////////
	Dig_Out_Struct.Out1_Write_Val = GET_BIT(PORTC_OUT,4);//Get the value of the output Pin PORTE 1
	Dig_Out_Struct.Out2_Write_Val = GET_BIT(PORTD_OUT,4);//Get the value of the output Pin PORTE 2
	Dig_Out_Struct.Out3_Write_Val = GET_BIT(PORTD_OUT,5);//Get the value of the output Pin PORTE 3
	Dig_Out_Struct.Out4_Write_Val = GET_BIT(PORTD_OUT,1);//Get the value of the output Pin PORTE 4
	
	/////////////////////////////////// DIGITAL INPUTS //////////////////////////////////////////////////////////////
	Dig_In_Struct.In1_Read_Val = GET_BIT(PORTA_IN,1);//Get the value of the Input pin PORTA 1
	Dig_In_Struct.In2_Read_Val = GET_BIT(PORTA_IN,2);//Get the value of the Input Pin PORTA 2
	Dig_In_Struct.In3_Read_Val = GET_BIT(PORTA_IN,3);//Get the value of the Input Pin PORTA 3
	Dig_In_Struct.In4_Read_Val = GET_BIT(PORTA_IN,4);//Get the value of the Input Pin PORTA 4
}

void checking_query_function(void)
{
	/*************************************************************************************************************************************************/
	/*    If Query has been received from UDP then by checking the corresponding Query bit the MWM command status is passed
	*************************************************************************************************************************************************/

	if(Incoming_Query_Bit == 1 && query_packets_rxd_bit == 1 && Modbus_Struct.cloud_txd_bit == 0)//Checking if any query has triggered the controller
	{
		Incoming_Query_Bit = 0;//Making zero to the bit
		if(Modbus_Struct.Device_absent_flag == 1)//if the equipment is not communicated with the MWM after sending the Equipment inactive alarm then force the MWM to do nothing
		{
			MWM_COMMAND_STATUS				= SEND_GSM_SMS_MODE;
		}
		else
		{
			if(Info_Query_Bit == 1)			//Get Product Info query
			{
				query_packets_rxd_bit       = 0;
				Modbus_Struct.cloud_txd_bit = 1;
				GPS_Location_Status         = AQUIRE_GPS_DATA;
				MWM_COMMAND_STATUS          = PUT_RDMS_INFO_BROADCAST;
			}
		
			else if(Parameter_Query_Bit == 1)//Get Parameters query
			{
				bMODRxdFlag1		        = 0;
				query_packets_rxd_bit       = 0;
				Modbus_Struct.cloud_txd_bit = 1;
				if(Modbus_Struct.Device_absent_flag == 1)//if the equipment is not communicated with the MWM after sending the Equipment inactive alarm then force the MWM to do nothing
				{
					MWM_COMMAND_STATUS		= SEND_GSM_SMS_MODE;
				}
				else
				{
					GPS_Location_Status		= AQUIRE_GPS_DATA;
					MWM_COMMAND_STATUS		= PUT_RDMS_PARAMETERS_BROADCAST;
				}
			}
		
			else if(Cycle_Summary_Query_Bit == 1)//Get Cycle summary query
			{
				bMODRxdFlag1		        = 0;
				query_packets_rxd_bit       = 0;
				Modbus_Struct.cloud_txd_bit = 1;
				ucModCommandStatus          = SEND_CYCLE_SUMMARY;
				GPS_Location_Status         = IDEAL_GPS;
				MWM_COMMAND_STATUS          = EMPTY_STATUS_FOR_MWM;
			}
		
			else if(Fault_Warning_Query_Bit == 1)//Get Fault warning Query
			{
				bMODRxdFlag1		        = 0;
				bMODRxdFlag                 = 0;
				query_packets_rxd_bit       = 0;
				Modbus_Struct.cloud_txd_bit = 1;
				ucModCommandStatus          = SEND_FAULT_WARNING;
				GPS_Location_Status         = IDEAL_GPS;
				MWM_COMMAND_STATUS          = EMPTY_STATUS_FOR_MWM;
			}
		
			else if(Snapshot_Query_Bit == 1)//Get Snapshot query
			{
				bMODRxdFlag1	                    = 0;
				snapshot_struct.Current_Page_Number = 0;
				query_packets_rxd_bit				= 0;
				snapshot_struct.Total_No_Pages	    = 20;
				Modbus_Struct.cloud_txd_bit         = 1;
				Snap_Shot_Present_Flag				= TRUE;//Made by Padmanathan 16/03/2015
				GPS_Location_Status                 = AQUIRE_GPS_DATA;
				MWM_COMMAND_STATUS                  = PUT_RDMS_SNAPSHOT_BROADCAST;
			}
		
			else if(Configure_Query_Bit == 1)//Set / Configure Product Info - This query is used to change the configurations of MWM
			{
				Modbus_Struct.cloud_txd_bit = 1;
				query_packets_rxd_bit       = 0;
				MWM_COMMAND_STATUS          = PROCESS_CONFIGURE_CMD;
				GPS_Location_Status         = IDEAL_GPS;			
			}
		}
	}	
}

void Data_Vaildation(void)
{
	unsigned int uiTemp16;
	
	uiTemp16 = (Modbus_Struct.Parameters_buff[0]  << 8 | Modbus_Struct.Parameters_buff[1]);
	if(uiTemp16 > 100)
	{
		Modbus_Struct.Parameters_buff[0] = 0;
		Modbus_Struct.Parameters_buff[1] = 0;
	}
}

#endif