#ifndef _flash_SPI_H
#define _flash_SPI_H
#include "HEADERS.H"

#define AT45DBX_MEM_CNT 1
//_____ D E F I N I T I O N S _____________________________________________

/*! \name AT45DBX Group A Commands
 */
//! @{
#define AT45DBX_CMDA_RD_PAGE              0xD2        //!< Main Memory Page Read (Serial/8-bit Mode).
#define AT45DBX_CMDA_RD_ARRAY_LEG         0xE8        //!< Continuous Array Read, Legacy Command (Serial/8-bit Mode).
#define AT45DBX_CMDA_RD_ARRAY_LF_SM       0x03        //!< Continuous Array Read, Low-Frequency Mode (Serial Mode).
#define AT45DBX_CMDA_RD_ARRAY_AF_SM       0x0B        //!< Continuous Array Read, Any-Frequency Mode (Serial Mode).
#define AT45DBX_CMDA_RD_SECTOR_PROT_REG   0x32        //!< Read Sector Protection Register (Serial/8-bit Mode).
#define AT45DBX_CMDA_RD_SECTOR_LKDN_REG   0x35        //!< Read Sector Lockdown Register (Serial/8-bit Mode).
#define AT45DBX_CMDA_RD_SECURITY_REG      0x77        //!< Read Security Register (Serial/8-bit Mode).
//! @}

/*! \name AT45DBX Group B Commands
 */
//! @{
#define AT45DBX_CMDB_ER_PAGE              0x81        //!< Page Erase (Serial/8-bit Mode).
#define AT45DBX_CMDB_ER_BLOCK             0x50        //!< Block Erase (Serial/8-bit Mode).
#define AT45DBX_CMDB_ER_SECTOR            0x7C        //!< Sector Erase (Serial/8-bit Mode).
#define AT45DBX_CMDB_ER_CHIP              0xC794809A  //!< Chip Erase (Serial/8-bit Mode).
#define AT45DBX_CMDB_XFR_PAGE_TO_BUF1     0x53        //!< Main Memory Page to Buffer 1 Transfer (Serial/8-bit Mode).
#define AT45DBX_CMDB_XFR_PAGE_TO_BUF2     0x55        //!< Main Memory Page to Buffer 2 Transfer (Serial/8-bit Mode).
#define AT45DBX_CMDB_CMP_PAGE_TO_BUF1     0x60        //!< Main Memory Page to Buffer 1 Compare (Serial/8-bit Mode).
#define AT45DBX_CMDB_CMP_PAGE_TO_BUF2     0x61        //!< Main Memory Page to Buffer 2 Compare (Serial/8-bit Mode).
#define AT45DBX_CMDB_PR_BUF1_TO_PAGE_ER   0x83        //!< Buffer 1 to Main Memory Page Program with Built-in Erase (Serial/8-bit Mode).
#define AT45DBX_CMDB_PR_BUF2_TO_PAGE_ER   0x86        //!< Buffer 2 to Main Memory Page Program with Built-in Erase (Serial/8-bit Mode).
#define AT45DBX_CMDB_PR_BUF1_TO_PAGE      0x88        //!< Buffer 1 to Main Memory Page Program without Built-in Erase (Serial/8-bit Mode).
#define AT45DBX_CMDB_PR_BUF2_TO_PAGE      0x89        //!< Buffer 2 to Main Memory Page Program without Built-in Erase (Serial/8-bit Mode).
#define AT45DBX_CMDB_PR_PAGE_TH_BUF1      0x82        //!< Main Memory Page Program through Buffer 1 (Serial/8-bit Mode).
#define AT45DBX_CMDB_PR_PAGE_TH_BUF2      0x85        //!< Main Memory Page Program through Buffer 2 (Serial/8-bit Mode).
#define AT45DBX_CMDB_RWR_PAGE_TH_BUF1     0x58        //!< Auto Page Rewrite through Buffer 1 (Serial/8-bit Mode).
#define AT45DBX_CMDB_RWR_PAGE_TH_BUF2     0x59        //!< Auto Page Rewrite through Buffer 2 (Serial/8-bit Mode).
//! @}

/*! \name AT45DBX Group C Commands
 */
//! @{
#define AT45DBX_CMDC_RD_BUF1_LF_SM        0xD1        //!< Buffer 1 Read, Low-Frequency Mode (Serial Mode).
#define AT45DBX_CMDC_RD_BUF2_LF_SM        0xD3        //!< Buffer 2 Read, Low-Frequency Mode (Serial Mode).
#define AT45DBX_CMDC_RD_BUF1_AF_SM        0xD4        //!< Buffer 1 Read, Any-Frequency Mode (Serial Mode).
#define AT45DBX_CMDC_RD_BUF2_AF_SM        0xD6        //!< Buffer 2 Read, Any-Frequency Mode (Serial Mode).
#define AT45DBX_CMDC_RD_BUF1_AF_8M        0x54        //!< Buffer 1 Read, Any-Frequency Mode (8-bit Mode).
#define AT45DBX_CMDC_RD_BUF2_AF_8M        0x56        //!< Buffer 2 Read, Any-Frequency Mode (8-bit Mode).
#define AT45DBX_CMDC_WR_BUF1              0x84        //!< Buffer 1 Write (Serial/8-bit Mode).
#define AT45DBX_CMDC_WR_BUF2              0x87        //!< Buffer 2 Write (Serial/8-bit Mode).
#define AT45DBX_CMDC_RD_STATUS_REG        0xD7        //!< Status Register Read (Serial/8-bit Mode).
#define AT45DBX_CMDC_RD_MNFCT_DEV_ID_SM   0x9F        //!< Manufacturer and Device ID Read (Serial Mode).
//! @}

/*! \name AT45DBX Group D Commands
 */
//! @{
#define AT45DBX_CMDD_EN_SECTOR_PROT       0x3D2A7FA9  //!< Enable Sector Protection (Serial/8-bit Mode).
#define AT45DBX_CMDD_DIS_SECTOR_PROT      0x3D2A7F9A  //!< Disable Sector Protection (Serial/8-bit Mode).
#define AT45DBX_CMDD_ER_SECTOR_PROT_REG   0x3D2A7FCF  //!< Erase Sector Protection Register (Serial/8-bit Mode).
#define AT45DBX_CMDD_PR_SECTOR_PROT_REG   0x3D2A7FFC  //!< Program Sector Protection Register (Serial/8-bit Mode).
#define AT45DBX_CMDD_LKDN_SECTOR          0x3D2A7F30  //!< Sector Lockdown (Serial/8-bit Mode).
#define AT45DBX_CMDD_PR_SECURITY_REG      0x9B000000  //!< Program Security Register (Serial/8-bit Mode).
#define AT45DBX_CMDD_PR_CONF_REG          0x3D2A80A6  //!< Program Configuration Register (Serial/8-bit Mode).
#define AT45DBX_CMDD_DEEP_PWR_DN          0xB9        //!< Deep Power-down (Serial/8-bit Mode).
#define AT45DBX_CMDD_RSM_DEEP_PWR_DN      0xAB        //!< Resume from Deep Power-down (Serial/8-bit Mode).
//! @}


/*! \name Bit-Masks and Values for the Status Register
 */
//! @{
#define AT45DBX_MSK_BUSY                  0x80        //!< Busy status bit-mask.
#define AT45DBX_BUSY                      0x00        //!< Busy status value (0x00 when busy, 0x80 when ready).
#define AT45DBX_MSK_DENSITY               0x3C        //!< Device density bit-mask.
//! @}

#if AT45DBX_MEM_SIZE==AT45DBX_500KB
/*! \name AT45DB041 Memories
 */
//! @{
#define AT45DBX_DENSITY                   0x1C        //!< Device density value.
#define AT45DBX_BYTE_ADDR_BITS            9           //!< Address bits for byte position within buffer.
//! @}

#elif AT45DBX_MEM_SIZE == AT45DBX_2MB

/*! \name AT45DB161 Memories
 */
//! @{
#define AT45DBX_DENSITY                   0x2C        //!< Device density value.
#define AT45DBX_BYTE_ADDR_BITS            10          //!< Address bits for byte position within buffer.
//! @}

#elif AT45DBX_MEM_SIZE == AT45DBX_4MB

/*! \name AT45DB321 Memories
 */
//! @{
#define AT45DBX_DENSITY                   0x34        //!< Device density value.
#define AT45DBX_BYTE_ADDR_BITS            10          //!< Address bits for byte position within buffer.
//! @}

#elif AT45DBX_MEM_SIZE == AT45DBX_8MB

/*! \name AT45DB642 Memories
 */
//! @{
#define AT45DBX_DENSITY                   0x3C        //!< Device density value.
#define AT45DBX_BYTE_ADDR_BITS            11          //!< Address bits for byte position within buffer.
//! @}

#else
	#error AT45DBX_MEM_SIZE is not defined to a supported value
#endif

//! Address bits for page selection.
#define AT45DBX_PAGE_ADDR_BITS            (AT45DBX_MEM_SIZE - AT45DBX_PAGE_BITS)

//! Number of bits for addresses within pages.
#define AT45DBX_PAGE_BITS                 (AT45DBX_BYTE_ADDR_BITS - 1)

//! Page size in bytes.
#define AT45DBX_PAGE_SIZE                 (1 << AT45DBX_PAGE_BITS)

//! Bit-mask for byte position within buffer in \ref at45dbx_gl_ptr_mem.
#define AT45DBX_MSK_PTR_BYTE              ((1 << AT45DBX_PAGE_BITS) - 1)

//! Bit-mask for page selection in \ref at45dbx_gl_ptr_mem.
#define AT45DBX_MSK_PTR_PAGE              (((1 << AT45DBX_PAGE_ADDR_BITS) - 1) << AT45DBX_PAGE_BITS)

//! Bit-mask for byte position within sector in \ref at45dbx_gl_ptr_mem.
#define AT45DBX_MSK_PTR_SECTOR            ((1 << AT45DBX_SECTOR_BITS) - 1)


/*! \brief Sends a dummy byte through SPI.
 */
#define spi_write_dummy()                 putspi(AT45DBX_SPI, 0xFF)


//! Boolean indicating whether memory is in busy state.
//static bool at45dbx_busy;

//! Memory data pointer.
//static uint32_t at45dbx_gl_ptr_mem;

/*
//--------------------------------------------------------------------------------------//
// read commands

#define CONTINUOUS_ARRAY_READ	0x03
#define MAIN_MEMORY_PAGE_READ	0xd2
#define BUFFER_1_READ			0xd1
#define BUFFER_2_READ			0xd3
#define STATUS_REGISTER_READ	0xd7*/

/*-------------------------------------------------------------------------------------------------------------*/
// program and erase commands

/*#define BUFFER_1_WRITE	0x84
#define BUFFER_2_WRITE	0x87
#define PAGE_ERASE		0x81
#define BLOCK_ERASE		0x50
#define MAIN_MEMORY_PAGE_PROGRAM_THROUGH_BUFFER_1	0x82
#define MAIN_MEMORY_PAGE_PROGRAM_THROUGH_BUFFER_2	0x85
#define BUFFER_1_TO_MAIN_MEMORY_PAGE_PROGRAM_WITH_BUILT_IN_ERASE		0x83
#define BUFFER_2_TO_MAIN_MEMORY_PAGE_PROGRAM_WITH_BUILT_IN_ERASE		0x86
#define BUFFER_1_TO_MAIN_MEMORY_PAGE_PROGRAM_WITHOUT_BUILT_IN_ERASE		0x88
#define BUFFER_2_TO_MAIN_MEMORY_PAGE_PROGRAM_WITHOUT_BUILT_IN_ERASE		0x89*/

/*-------------------------------------------------------------------------------------------------------------*/
//additional commands
/*#define MAIN_MEMORY_PAGE_TO_BUFFER_1_TRANSFER	0x53
#define MAIN_MEMORY_PAGE_TO_BUFFER_2_TRANSFER	0x55
#define MAIN_MEMORY_PAGE_TO_BUFFER_1_COMPARE	0x60
#define MAIN_MEMORY_PAGE_TO_BUFFER_2_COMPARE	0x61
#define AUTO_PAGE_REWRITE_THROUGH_BUFFER_1		0x58
#define AUTO_PAGE_REWRITE_THROUGH_BUFFER_2		0x59*/
/*-------------------------------------------------------------------------------------------------------------*/
//#define PAGE_SIZE		512         //number of bytes in a page
/*-------------------------------------------------------------------------------------------------------------*/
//-------------------------------------------------------------------------------------------------------------
// --------------------------------------------------------------------------------------//
// read commands
// 
// #define CONTINUOUS_ARRAY_READ	0xE8
// #define MAIN_MEMORY_PAGE_READ	0x52//0xd2
// #define BUFFER_1_READ			0xd4
// #define BUFFER_2_READ			0xd6
// #define STATUS_REGISTER_READ	0xd7
// 
// /*-------------------------------------------------------------------------------------------------------------*/
// //program and erase commands
// 
// #define BUFFER_1_WRITE	0x84
// #define BUFFER_2_WRITE	0x87
// #define PAGE_ERASE		0x81
// #define BLOCK_ERASE		0x50
// #define MAIN_MEMORY_PAGE_PROGRAM_THROUGH_BUFFER_1	0x82
// #define MAIN_MEMORY_PAGE_PROGRAM_THROUGH_BUFFER_2	0x85
// #define BUFFER_1_TO_MAIN_MEMORY_PAGE_PROGRAM_WITH_BUILT_IN_ERASE		0x83
// #define BUFFER_2_TO_MAIN_MEMORY_PAGE_PROGRAM_WITH_BUILT_IN_ERASE		0x86
// #define BUFFER_1_TO_MAIN_MEMORY_PAGE_PROGRAM_WITHOUT_BUILT_IN_ERASE		0x88
// #define BUFFER_2_TO_MAIN_MEMORY_PAGE_PROGRAM_WITHOUT_BUILT_IN_ERASE		0x89
// 
// /*-------------------------------------------------------------------------------------------------------------*/
// //additional commands
// #define MAIN_MEMORY_PAGE_TO_BUFFER_1_TRANSFER	0x53
// #define MAIN_MEMORY_PAGE_TO_BUFFER_2_TRANSFER	0x55
// #define MAIN_MEMORY_PAGE_TO_BUFFER_1_COMPARE	0x60
// #define MAIN_MEMORY_PAGE_TO_BUFFER_2_COMPARE	0x61
// #define AUTO_PAGE_REWRITE_THROUGH_BUFFER_1		0x58
// #define AUTO_PAGE_REWRITE_THROUGH_BUFFER_2		0x59
// /*-------------------------------------------------------------------------------------------------------------*/
// #define PAGE_SIZE		512         //number of bytes in a page
// /*-------------------------------------------------------------------------------------------------------------*/
// -------------------------------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------//
//read commands

#define CONTINUOUS_ARRAY_READ	0xE8
#define MAIN_MEMORY_PAGE_READ	0xD2
#define BUFFER_1_READ			0xD4
#define BUFFER_2_READ			0xD6
#define STATUS_REGISTER_READ	0x57

/*-------------------------------------------------------------------------------------------------------------*/
//program and erase commands

#define BUFFER_1_WRITE	0x84
#define BUFFER_2_WRITE	0x87
#define PAGE_ERASE		0x81
#define BLOCK_ERASE		0x50
#define MAIN_MEMORY_PAGE_PROGRAM_THROUGH_BUFFER_1	0x82
#define MAIN_MEMORY_PAGE_PROGRAM_THROUGH_BUFFER_2	0x85
#define BUFFER_1_TO_MAIN_MEMORY_PAGE_PROGRAM_WITH_BUILT_IN_ERASE		0x83
#define BUFFER_2_TO_MAIN_MEMORY_PAGE_PROGRAM_WITH_BUILT_IN_ERASE		0x86
#define BUFFER_1_TO_MAIN_MEMORY_PAGE_PROGRAM_WITHOUT_BUILT_IN_ERASE		0x88
#define BUFFER_2_TO_MAIN_MEMORY_PAGE_PROGRAM_WITHOUT_BUILT_IN_ERASE		0x89

/*-------------------------------------------------------------------------------------------------------------*/
//additional commands
#define MAIN_MEMORY_PAGE_TO_BUFFER_1_TRANSFER	0x53
#define MAIN_MEMORY_PAGE_TO_BUFFER_2_TRANSFER	0x55
#define MAIN_MEMORY_PAGE_TO_BUFFER_1_COMPARE	0x60
#define MAIN_MEMORY_PAGE_TO_BUFFER_2_COMPARE	0x61
#define AUTO_PAGE_REWRITE_THROUGH_BUFFER_1		0x58
#define AUTO_PAGE_REWRITE_THROUGH_BUFFER_2		0x59
/*-------------------------------------------------------------------------------------------------------------*/
#define PAGE_SIZE		512         //number of bytes in a page
/*-------------------------------------------------------------------------------------------------------------*/
//-------------------------------------------------------------------------------------------------------------



// /*-------------------------------------------------------------------------------------------------------------*/
// // read commands
// 
// #define CONTINUOUS_ARRAY_READ	0x03
// #define MAIN_MEMORY_PAGE_READ	0xd2
// #define BUFFER_1_READ			0xd1
// #define BUFFER_2_READ			0xd3
// #define STATUS_REGISTER_READ	0xd7
// 
// /*-------------------------------------------------------------------------------------------------------------*/
// // program and erase commands
// 
// #define BUFFER_1_WRITE	0x84
// #define BUFFER_2_WRITE	0x87
// #define PAGE_ERASE		0x81
// #define BLOCK_ERASE		0x50
// #define MAIN_MEMORY_PAGE_PROGRAM_THROUGH_BUFFER_1	0x82
// #define MAIN_MEMORY_PAGE_PROGRAM_THROUGH_BUFFER_2	0x85
// #define BUFFER_1_TO_MAIN_MEMORY_PAGE_PROGRAM_WITH_BUILT_IN_ERASE		0x83
// #define BUFFER_2_TO_MAIN_MEMORY_PAGE_PROGRAM_WITH_BUILT_IN_ERASE		0x86
// #define BUFFER_1_TO_MAIN_MEMORY_PAGE_PROGRAM_WITHOUT_BUILT_IN_ERASE		0x88
// #define BUFFER_2_TO_MAIN_MEMORY_PAGE_PROGRAM_WITHOUT_BUILT_IN_ERASE		0x89
// 
// /*-------------------------------------------------------------------------------------------------------------*/
// //additional commands
// #define MAIN_MEMORY_PAGE_TO_BUFFER_1_TRANSFER	0x53
// #define MAIN_MEMORY_PAGE_TO_BUFFER_2_TRANSFER	0x55
// #define MAIN_MEMORY_PAGE_TO_BUFFER_1_COMPARE	0x60
// #define MAIN_MEMORY_PAGE_TO_BUFFER_2_COMPARE	0x61
// #define AUTO_PAGE_REWRITE_THROUGH_BUFFER_1		0x58
// #define AUTO_PAGE_REWRITE_THROUGH_BUFFER_2		0x59
// /*-------------------------------------------------------------------------------------------------------------*/
// #define PAGE_SIZE		512         //number of bytes in a page
// /*-------------------------------------------------------------------------------------------------------------*/



unsigned char putspi(unsigned char input)
{
	//unsigned char temp;
	SPIC_DATA=input;
	while(Recieved_Flag==0);
	Recieved_Flag=0;
	return (SPIC_DATA);
}
void flash_memory_compare(void)
{

	CLR_BIT(PORTD_OUT,0);//Flash Slave Select
	putspi(MAIN_MEMORY_PAGE_TO_BUFFER_1_COMPARE);
	putspi(0x00);
	putspi(0x00);
	putspi(0x00);
	SET_BIT(PORTD_OUT,0);//Flash Slave DeSelect
	
}
void read_flash(void)
{
	
}



//-------------------------------------------------------------------------------------------------------------

//-------------------------------------------------------------------------------------------------------------

void flash_status_check(void)
{

	CLR_BIT(PORTD_OUT,0);//Flash Slave Select 
	_delay_ms(10);
	putspi(STATUS_REGISTER_READ);
	putspi(0x55);
	while (!(putspi(0x55) & 0x80 ));
	USARTD1_DATA=putspi(0x55);
	_delay_ms(10);
	SET_BIT(PORTD_OUT,0);//Flash Slave DeSelect 
	
}

//-------------------------------------------------------------------------------------------------------------

void flash_buffer1_read(void)
{
	unsigned short int i;
	PORTD_OUT &= 0xFE;//CLR_BIT(PORTD_OUT,0);//Flash Slave Select 
	putspi(BUFFER_1_READ);
	putspi(0x00);
	putspi(0x00);
	putspi(0x00);
	putspi(0x55);
	for ( i =0 ; i<512 ; i++ )      
	{
		Flash_Struct.download_buffer[i] = putspi (0x55);
	}
	//byte_address=putspi (0x00);
	PORTD_OUT |= 0x01;//SET_BIT(PORTD_OUT,0);//Flash Slave DeSelect 
}

//-------------------------------------------------------------------------------------------------------------

void flash_buffer2_read(void)
{
	static unsigned short int i;
	CLR_BIT(PORTD_OUT,0);//Flash Slave Select 
		_delay_ms(10);
	putspi(BUFFER_2_READ);
	putspi(0x00);
	putspi(0x00);
	putspi(0x00);
	putspi(0x55);
	for ( i =0 ; i<512 ; i++ )      
	{
		Flash_Struct.download_buffer[i] = putspi (0x00);
	}
		_delay_ms(10);
	SET_BIT(PORTD_OUT,0);//Flash Slave DeSelect 
}

//-------------------------------------------------------------------------------------------------------------

void flash_main_memory_page_read(unsigned char page_address_hi, unsigned char page_address_lo, unsigned char byte_address)
{
	static unsigned short int i;
	PORTD_OUT &= 0xFE;
	//CLR_BIT(PORTD_OUT,0);//Flash Slave Select 
	byte_address=0;
	putspi(MAIN_MEMORY_PAGE_READ);
	putspi(page_address_hi);
	putspi(page_address_lo);
	putspi(byte_address);
	putspi(0x00);
	putspi(0x00);
	putspi(0x00);	
	putspi(0x00);	
	for ( i =0 ; i<512 ; i++ )      
	{
		
		Flash_Struct.download_buffer[i] = putspi(0x00);
	}
	PORTD_OUT |= 0x01;//SET_BIT(PORTD_OUT,0);//Flash Slave DeSelect 
}

//-------------------------------------------------------------------------------------------------------------

void flash_buffer1_write(void)
{
	unsigned short int i;
	PORTD_OUT &= 0xFE;//CLR_BIT(PORTD_OUT,0);//Flash Slave Select 
		
	putspi(BUFFER_1_WRITE);
	putspi(0x00);
	putspi(0x00);
	putspi(0x00);
	for (i=0;i<512;i++)      
	{
		putspi(Flash_Struct.record_buffer[i]);
	}

	PORTD_OUT |= 0x01;//SET_BIT(PORTD_OUT,0);//Flash Slave DeSelect 
}

//-------------------------------------------------------------------------------------------------------------

void flash_buffer2_write(void)
{
	static unsigned short int i;
	CLR_BIT(PORTD_OUT,0);//Flash Slave Select 
		_delay_ms(10);
	putspi(BUFFER_2_WRITE);
	putspi(0x00);
	putspi(0x00);
	putspi(0x00);
	for (i=0;i<512;i++)      
	{
		putspi(Flash_Struct.record_buffer[i]);
	}
		_delay_ms(10);
	SET_BIT(PORTD_OUT,0);//Flash Slave DeSelect 
}

//-------------------------------------------------------------------------------------------------------------

void flash_buffer1_to_main_memory_page_program_with_built_in_erase(unsigned char page_address_hi, unsigned char page_address_lo)
{
	uint16_t page_address = (page_address_hi>>8);
	page_address = ((page_address)|(page_address_lo));
	page_address = page_address>>4;
	PORTD_OUT &= 0xFE;CLR_BIT(PORTD_OUT,0);//Flash Slave Select 
	putspi(BUFFER_1_TO_MAIN_MEMORY_PAGE_PROGRAM_WITH_BUILT_IN_ERASE);
	putspi(page_address_hi);
	putspi(page_address_lo);
	putspi(0x00);
	PORTD_OUT |= 0x01;//SET_BIT(PORTD_OUT,0);//Flash Slave DeSelect 
}

//-------------------------------------------------------------------------------------------------------------

void flash_buffer2_to_main_memory_page_program_with_built_in_erase(unsigned char page_address_hi, unsigned char page_address_lo)
{
	CLR_BIT(PORTD_OUT,0);//Flash Slave Select 
		_delay_ms(10);
	putspi(BUFFER_2_TO_MAIN_MEMORY_PAGE_PROGRAM_WITH_BUILT_IN_ERASE);
	putspi(page_address_hi);
	putspi(page_address_lo);
	putspi(0x00);
		_delay_ms(10);
	SET_BIT(PORTD_OUT,0);//Flash Slave DeSelect 
}

//-------------------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------------------

void flash_main_memory_page_write(unsigned char page_address_hi, unsigned char page_address_lo, unsigned char byte_address)
{
	static unsigned short int i;
	PORTD_OUT &= 0xFE;//CLR_BIT(PORTD_OUT,0);//Flash Slave Select
	_delay_ms(10);
	byte_address=0;
	putspi(MAIN_MEMORY_PAGE_PROGRAM_THROUGH_BUFFER_1);
	putspi(page_address_hi);
	putspi(page_address_lo);
	putspi(byte_address);
	//_delay_ms(10);
	for ( i =0 ; i<512 ; i++ )
	{
		putspi(Flash_Struct.record_buffer[i]);
		
	}
		_delay_ms(10);
	PORTD_OUT |= 0x01;//SET_BIT(PORTD_OUT,0);//Flash Slave DeSelect
}

//-------------------------------------------------------------------------------------------------------------
void flash_main_memory_cntnus_read(unsigned char page_address_hi, unsigned char page_address_lo, unsigned char byte_address)
{
	static unsigned short int i;
	CLR_BIT(PORTD_OUT,0);//Flash Slave Select
	_delay_ms(10);
	byte_address=0;
	putspi(0xE8);
	putspi(page_address_hi);
	putspi(page_address_lo);
	putspi(byte_address);
	putspi(0x55);
	putspi(0x55);
	putspi(0x55);
	putspi(0x55);
	_delay_ms(10);
	for ( i =0 ; i<512 ; i++ )
	{
		USARTD1_DATA = putspi (0x55);
		while(!((USARTD1_STATUS & 0x20)==0x20));
	}
		_delay_ms(10);
	SET_BIT(PORTD_OUT,0);//Flash Slave DeSelect
}

//-------------------------------------------------------------------------------------------------------------

void flash_page_erase(unsigned char page_address_hi, unsigned char page_address_lo)
{
	CLR_BIT(PORTD_OUT,0);//Flash Slave Select
		_delay_ms(10);
	putspi(0x81);
	putspi(page_address_hi);
	putspi(page_address_lo);
	putspi(0x00);
		_delay_ms(10);
	SET_BIT(PORTD_OUT,0);//Flash Slave DeSelect
}

//-------------------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------------------

void flash_block_erase(unsigned char page_address_hi, unsigned char page_address_lo)
{
	CLR_BIT(PORTD_OUT,0);//Flash Slave Select
	putspi(0x50);
	putspi(page_address_hi);
	putspi(page_address_lo);
	putspi(0x00);
	SET_BIT(PORTD_OUT,0);//Flash Slave DeSelect
}

//-------------------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------------------

void flash_buffer1_to_main_memory_page_program_without_built_in_erase(unsigned char page_address_hi, unsigned char page_address_lo)
{
	CLR_BIT(PORTD_OUT,0);//Flash Slave Select
		_delay_ms(10);
	putspi(BUFFER_1_TO_MAIN_MEMORY_PAGE_PROGRAM_WITHOUT_BUILT_IN_ERASE);
	putspi(page_address_hi);
	putspi(page_address_lo);
	putspi(0x00);
	_delay_ms(10);
	SET_BIT(PORTD_OUT,0);//Flash Slave DeSelect
}

//-------------------------------------------------------------------------------------------------------------

void flash_buffer2_to_main_memory_page_program_without_built_in_erase(unsigned char page_address_hi, unsigned char page_address_lo)
{
	CLR_BIT(PORTD_OUT,0);//Flash Slave Select
		_delay_ms(10);
	putspi(BUFFER_2_TO_MAIN_MEMORY_PAGE_PROGRAM_WITHOUT_BUILT_IN_ERASE);
	putspi(page_address_hi);
	putspi(page_address_lo);
	putspi(0x00);
		_delay_ms(10);
	SET_BIT(PORTD_OUT,0);//Flash Slave DeSelect
}

//-------------------------------------------------------------------------------------------------------------
void flash_main_mem_transfer_to_buff_1(unsigned char page_address_hi, unsigned char page_address_lo)
{
	CLR_BIT(PORTD_OUT,0);//Flash Slave Select
	_delay_ms(10);
	putspi(MAIN_MEMORY_PAGE_TO_BUFFER_1_TRANSFER);
	putspi(page_address_hi);
	putspi(page_address_lo);
	putspi(0x00);
	//_delay_ms(10);
	SET_BIT(PORTD_OUT,0);//Flash Slave DeSelect
}
#endif
