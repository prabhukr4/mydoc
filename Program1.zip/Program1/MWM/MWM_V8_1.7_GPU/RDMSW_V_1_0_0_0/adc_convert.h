#ifndef _adc_convert_h_
#define _adc_convert_h_

#include "HEADERS.H"

///////////////////////////////////////////////ADC CONVERSION OF CHANNEL 0 ////////////////////////////////////

void Average_ADC_Value_CH0(void)
{
		unsigned int y;
		unsigned long int ADC_total;

		ADC_total=0;

		for(y=0;y<512;y++)//Read continuously the ADC reading for 256 times
		{
			ADCA_CTRLA |= 0x08;//Channel 0 Selected
			ADCA_CH0_CTRL |= 0x81;//Channel 0 Start Conversion
			while(!((ADCA_CH0_INTFLAGS & 0x01)== 0x01));//wait for the corresponding interrupt flags to be set
			ADC_Res_CH0 = ADCA_CH0_RES;
			ADC_total += ADC_Res_CH0;
		}
		ADC_total = (ADC_total/512);//(ADC_total/256)
		ADC_Res_CH0 = ADC_total;
}

///////////////////////////////////////////////ADC CONVERSION OF CHANNEL 1/////////////////////////////////////////

void Average_ADC_Value_CH1(void)
{
		unsigned int y;
		unsigned long int ADC_total;

		ADC_total=0;

		for(y=0;y<512;y++)//Read continuously the ADC reading for 256 times
		{
			ADCA_CTRLA |= 0x08;//Channel 0 Selected
			ADCA_CH1_CTRL |= 0x81;//Channel 0 Start Conversion
			while(!((ADCA_CH1_INTFLAGS & 0x01)== 0x01));//wait for the corresponding interrupt flags to be set
			ADC_Res_CH1 = ADCA_CH1_RES;
			ADC_total += ADC_Res_CH1;
		}
		ADC_total = (ADC_total/512);//(ADC_total/256)
		ADC_Res_CH1 = ADC_total;
}
///////////////////////////////////////////////ADC CONVERSION OF CHANNEL 2/////////////////////////////////////////

void Average_ADC_Value_CH2(void)
{
		unsigned int y;
		unsigned long int ADC_total;

		ADC_total=0;
		for(y=0;y<512;y++)
		{
			ADCA_CTRLA |= 0x08;//Channel 0 Selected
			ADCA_CH2_CTRL |= 0x81;//Channel 0 Start Conversion
			while(!((ADCA_CH2_INTFLAGS & 0x01)== 0x01));
			ADC_Res_CH2 = ADCA_CH2_RES;
			ADC_total += ADC_Res_CH2;
		}
		ADC_total = (ADC_total/512);//(ADC_total/256)
		ADC_Res_CH2 = ADC_total;
}

///////////////////////////////////////////////ADC CONVERSION OF CHANNEL 3/////////////////////////////////////////

void Average_ADC_Value_CH3(void)
{
		unsigned int y;
		unsigned long int ADC_total;

		ADC_total=0;
		for(y=0;y<512;y++)
		{
			ADCA_CTRLA |= 0x08;//Channel 0 Selected
			ADCA_CH3_CTRL |= 0x81;//Channel 0 Start Conversion
			while(!((ADCA_CH3_INTFLAGS & 0x01)== 0x01));
			ADC_Res_CH3 = ADCA_CH3_RES;
			ADC_total += ADC_Res_CH3;
		}
		ADC_total = (ADC_total/512);//(ADC_total/256)
		ADC_Res_CH3 = ADC_total;
}

#endif