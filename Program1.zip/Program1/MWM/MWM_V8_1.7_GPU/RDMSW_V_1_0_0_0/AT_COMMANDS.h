#ifndef _AT_COMMANDS_H_
#define _AT_COMMANDS_H_

#include "HEADERS.H"

void AT_init()
{
	unsigned char ucGSMDataFrame[30] = {0x41,0x54,0x0D,0x0A};
	
	us
		
}







#endif
