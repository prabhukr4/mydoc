#ifndef _DAC_Convert_h
#define _DAC_Convert_h
#include "HEADERS.H"


void DAC_CHANNEL0_DATA(unsigned int z)
{
	DACB_CH0DATA = z;//Passing Digital Data to Channel 0 of DAC 
}

void DAC_CHANNEL1_DATA(unsigned int y)
{

	DACB_CH1DATA = y;//Passing Digital Data to Channel 1 of DAC
}
#endif
