			spi_selectChip(&AVR32_SPI1,0);
			spi_write_packet(&AVR32_SPI1,data,3);
			spi_read_packet(&AVR32_SPI1,data,3);
			spi_unselectChip(&AVR32_SPI1,0);
			
			// 			 spi_selectChip(&AVR32_SPI1,0);
			// 			spi_put(&AVR32_SPI1,0x00);
			// 			data0 = (uint8_t)spi_get(&AVR32_SPI1);// spi_read(&AVR32_SPI1,(uint16_t*)data0);// data0 = spi_read(&AVR32_SPI1,data0);
			// 			spi_put(&AVR32_SPI1,0xAA);
			// 			data1 = (uint8_t)spi_get(&AVR32_SPI1);//spi_read(&AVR32_SPI1,(uint16_t*)data1);// data1 = spi_get(&AVR32_SPI1);
			// 			spi_put(&AVR32_SPI1,0xAA);
			// 			data2 = (uint8_t)spi_get(&AVR32_SPI1);//spi_read(&AVR32_SPI1,(uint16_t*)data2);// data2 = spi_get(&AVR32_SPI1);
			// 			 spi_unselectChip(&AVR32_SPI1,0);
			// 			UART_Send_byte(data0);
			// 			UART_Send_byte(data1);
			//  			UART_Send_byte(data2);
			// 			delay_ms(50000);
			//
			// 			spi_selectChip(&AVR32_SPI1,0);
			// 			spi_put(&AVR32_SPI1,0x00);
			// 			data0 = (uint8_t)spi_get(&AVR32_SPI1);// spi_read(&AVR32_SPI1,(uint16_t*)data0);// data0 = spi_read(&AVR32_SPI1,data0);
			// 			spi_put(&AVR32_SPI1,0x55);
			// 			data1 = (uint8_t)spi_get(&AVR32_SPI1);//spi_read(&AVR32_SPI1,(uint16_t*)data1);// data1 = spi_get(&AVR32_SPI1);
			// 			spi_put(&AVR32_SPI1,0x55);
			// 			data2 = (uint8_t)spi_get(&AVR32_SPI1);//spi_read(&AVR32_SPI1,(uint16_t*)data2);// data2 = spi_get(&AVR32_SPI1);
			// 			spi_unselectChip(&AVR32_SPI1,0);
			// 			UART_Send_byte(data0);
			// 			UART_Send_byte(data1);
			// 			UART_Send_byte(data2);
			// 			delay_ms(50000);

			// 			x = 0x0001;
			// 			for(unsigned int i=0;i<16;i++)
			// 			{
			//
			//
			// 									spi_selectChip(&AVR32_SPI1,0);
			// 									spi_write(&AVR32_SPI1,0x00);
			// 									spi_read(&AVR32_SPI1,(uint16_t*)data0);
			// 									spi_write(&AVR32_SPI1,x>>8);
			// 									spi_read(&AVR32_SPI1,(uint16_t*)data1);
			// 									spi_write(&AVR32_SPI1,x);
			// 									spi_read(&AVR32_SPI1,(uint16_t*)data2);
			// 									spi_unselectChip(&AVR32_SPI1,0);
			// 								x=x<<1;
			// 								UART_Send_byte(data0);
			// 								UART_Send_byte(data1);
			// 								UART_Send_byte(data2);
			// 					delay_ms(50000);
			//  					delay_ms(50000);
			//  					delay_ms(50000);
			// 					delay_ms(50000);
			// 					delay_ms(50000);
			// 			}


			//
			// 									spi_selectChip(&AVR32_SPI1,0);
			// 									spi_write(&AVR32_SPI1,0x00);
			// 									spi_read(&AVR32_SPI1,(uint16_t*)data0);
			// 									spi_write(&AVR32_SPI1,0xAA);
			// 									spi_read(&AVR32_SPI1,(uint16_t*)data1);
			// 									spi_write(&AVR32_SPI1,0xAA);
			// 									spi_read(&AVR32_SPI1,(uint16_t*)data2);
			// 									spi_unselectChip(&AVR32_SPI1,0);
			// 									UART_Send_byte(data0);
			// 									UART_Send_byte(data1);
			// 									UART_Send_byte(data2);
			//
			// 									delay_ms(30000);
			// 									spi_selectChip(&AVR32_SPI1,0);
			// 									spi_write(&AVR32_SPI1,0x00);
			// 									spi_read(&AVR32_SPI1,(uint16_t*)data0);
			// 									spi_write(&AVR32_SPI1,0x55);
			// 									spi_read(&AVR32_SPI1,(uint16_t*)data1);
			// 									spi_write(&AVR32_SPI1,0x55);
			// 									spi_read(&AVR32_SPI1,(uint16_t*)data2);
			// 									spi_unselectChip(&AVR32_SPI1,0);
			// 									delay_ms(30000);
			// 									UART_Send_byte(data0);
			// 									UART_Send_byte(data1);
			// 									UART_Send_byte(data2);

			// 			UART_Send_byte(data1);
			// 			UART_Send_byte(data2);






	void Send_data(const char *ptr)
	{
		while(*ptr != '\0')
		{
			MCU_UART_Send_Byte(*ptr++);
			
		}
	}

	
		if(bMODRxdFlag1==1)
		{
			Mod_Data_process();
			bMODRxdFlag1=0;
		}


		unsigned char ucReadConfigCheck[8],ucReadConfigConst[8];
		switch(Reg)
		{
			
			case 0x01:
			for(unsigned int i=0;i<8;i++)
			{
				ucReadConfigCheck[i] = eeprom_read_byte((uint8_t*)_RDMSW_CONFIG_CHECK0_STRING_ADD+i);
				//ucReadConfigConst[i] = *_RDMSW_CONFIG_DONE_CHECK0_STRING++;
			}
			break;
			case 0x02:
			for(unsigned int i=0;i<8;i++)
			{
				ucReadConfigCheck[i] = eeprom_read_byte((uint8_t*)_RDMSW_CONFIG_CHECK1_STRING_ADD+i);
				//ucReadConfigConst[i] = *_RDMSW_CONFIG_DONE_CHECK1_STRING++;
			}
			break;
			default:
			break;
		}
		for(unsigned int i=0;i<8;i++)
		{
			if(ucReadConfigCheck[i] != ucReadConfigConst[i])return 0x00;
			
		}
		return Reg;
	
	
	unsigned int uiDataFrameLoc =0;
	//////////////////////////////////////////////////////////////////////////////////////
	for(unsigned int i=_RDMSW_DEVICE_ID_ADD0;i<sizeof(_RDMSW_DEVICE_ID_DATA);i++)
	{
		ucRDMSW_Config_Frame[i]= *_RDMSW_DEVICE_ID_DATA++;
		uiDataFrameLoc++;
	}
	for(unsigned int i=uiDataFrameLoc;i<_RDMSW_MNTH_MANFC_ADD0;i++)
	{
		ucRDMSW_Config_Frame[i]= 0;
		uiDataFrameLoc++;
	}
	///////////////////////////////////////////////////////////////////////////////////////
	for(unsigned int i=uiDataFrameLoc;i<sizeof(_RDMSW_MNTH_MANFC_DATA);i++)
	{
		ucRDMSW_Config_Frame[i]= *_RDMSW_MNTH_MANFC_DATA++;
		uiDataFrameLoc++;
	}
	for(unsigned int i=uiDataFrameLoc;i<_RDMSW_YEAR_MANFC_ADD0;i++)
	{
		ucRDMSW_Config_Frame[i]= 0;
		uiDataFrameLoc++;
	}
	///////////////////////////////////////////////////////////////////////////////////////////
	for(unsigned int i=uiDataFrameLoc;i<sizeof(_RDMSW_YEAR_MANFC_DATA);i++)
	{
		ucRDMSW_Config_Frame[i]= *_RDMSW_YEAR_MANFC_DATA++;
		uiDataFrameLoc++;
	}
	for(unsigned int i=uiDataFrameLoc;i<_RDMSW_QC_ENGNR_ADD0;i++)
	{
		ucRDMSW_Config_Frame[i]= 0;
		uiDataFrameLoc++;
	}
	///////////////////////////////////////////////////////////////////////////////////////////
	for(unsigned int i=uiDataFrameLoc;i<sizeof(_RDMSW_QC_ENGNR_DATA);i++)
	{
		ucRDMSW_Config_Frame[i]= *_RDMSW_QC_ENGNR_DATA++;
		uiDataFrameLoc++;
	}
	for(unsigned int i=uiDataFrameLoc;i<_RDMSW_DEV_MOB_NO_ADD0;i++)
	{
		ucRDMSW_Config_Frame[i]= 0;
		uiDataFrameLoc++;
	}
	///////////////////////////////////////////////////////////////////////////////////////////

	///////////////////////////////////////////////////////////////////////////////////////////
	for(unsigned int i=uiDataFrameLoc;i<sizeof(_RDMSW_DEV_MOB_NO_DATA);i++)
	{
		ucRDMSW_Config_Frame[i]= *_RDMSW_DEV_MOB_NO_DATA++;
		uiDataFrameLoc++;
	}
	for(unsigned int i=uiDataFrameLoc;i<_RDMSW_DEV_EMAIL_ID_ADD0;i++)
	{
		ucRDMSW_Config_Frame[i]= 0;
		uiDataFrameLoc++;
	}
	///////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////
	for(unsigned int i=uiDataFrameLoc;i<sizeof(_RDMSW_DEV_EMAIL_ID_DATA);i++)
	{
		ucRDMSW_Config_Frame[i]= *_RDMSW_DEV_EMAIL_ID_DATA++;
		uiDataFrameLoc++;
	}
	for(unsigned int i=uiDataFrameLoc;i<_RDMSW_DEV_PASSWORD_ADD0;i++)
	{
		ucRDMSW_Config_Frame[i]= 0;
		uiDataFrameLoc++;
	}
	///////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////
	for(unsigned int i=uiDataFrameLoc;i<sizeof(_RDMSW_DEV_PASSWORD_DATA);i++)
	{
		ucRDMSW_Config_Frame[i]= *_RDMSW_DEV_PASSWORD_DATA++;
		uiDataFrameLoc++;
	}
	for(unsigned int i=uiDataFrameLoc;i<_RDMSW_DEV_SMTP_ADD0;i++)
	{
		ucRDMSW_Config_Frame[i]= 0;
		uiDataFrameLoc++;
	}
	///////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////
	for(unsigned int i=uiDataFrameLoc;i<sizeof(_RDMSW_DEV_SMTP_DATA);i++)
	{
		ucRDMSW_Config_Frame[i]= *_RDMSW_DEV_SMTP_DATA++;
		uiDataFrameLoc++;
	}
	for(unsigned int i=uiDataFrameLoc;i<_RDMSW_DEV_REC1_MAIL_ADD0;i++)
	{
		ucRDMSW_Config_Frame[i]= 0;
		uiDataFrameLoc++;
	}
	///////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////
	for(unsigned int i=uiDataFrameLoc;i<sizeof(_RDMSW_DEV_REC1_MAIL_DATA);i++)
	{
		ucRDMSW_Config_Frame[i]= *_RDMSW_DEV_REC1_MAIL_DATA++;
		uiDataFrameLoc++;
	}
	for(unsigned int i=uiDataFrameLoc;i<_RDMSW_DEV_REC2_MAIL_ADD0;i++)
	{
		ucRDMSW_Config_Frame[i]= 0;
		uiDataFrameLoc++;
	}
	///////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////
	for(unsigned int i=uiDataFrameLoc;i<sizeof(_RDMSW_DEV_REC2_MAIL_DATA);i++)
	{
		ucRDMSW_Config_Frame[i]= *_RDMSW_DEV_REC2_MAIL_DATA++;
		uiDataFrameLoc++;
	}
	for(unsigned int i=uiDataFrameLoc;i<_RDMSW_DEV_REC3_MAIL_ADD0;i++)
	{
		ucRDMSW_Config_Frame[i]= 0;
		uiDataFrameLoc++;
	}
	///////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////
	for(unsigned int i=uiDataFrameLoc;i<sizeof(_RDMSW_DEV_REC3_MAIL_DATA);i++)
	{
		ucRDMSW_Config_Frame[i]= *_RDMSW_DEV_REC3_MAIL_DATA++;
		uiDataFrameLoc++;
	}
	for(unsigned int i=uiDataFrameLoc;i<_RDMSW_DEV_REC4_MAIL_ADD0;i++)
	{
		ucRDMSW_Config_Frame[i]= 0;
		uiDataFrameLoc++;
	}
	///////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////
	for(unsigned int i=uiDataFrameLoc;i<sizeof(_RDMSW_DEV_REC4_MAIL_DATA);i++)
	{
		ucRDMSW_Config_Frame[i]= *_RDMSW_DEV_REC4_MAIL_DATA++;
		uiDataFrameLoc++;
	}
	for(unsigned int i=uiDataFrameLoc;i<_RDMSW_DEV_REC5_MAIL_ADD0;i++)
	{
		ucRDMSW_Config_Frame[i]= 0;
		uiDataFrameLoc++;
	}
	///////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////
	for(unsigned int i=uiDataFrameLoc;i<sizeof(_RDMSW_DEV_REC5_MAIL_DATA);i++)
	{
		ucRDMSW_Config_Frame[i]= *_RDMSW_DEV_REC5_MAIL_DATA++;
		uiDataFrameLoc++;
	}
	for(unsigned int i=uiDataFrameLoc;i<_RDMSW_DEV_USR1_MOB_ADD0;i++)
	{
		ucRDMSW_Config_Frame[i]= 0;
		uiDataFrameLoc++;
	}
	///////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////
	for(unsigned int i=uiDataFrameLoc;i<sizeof(_RDMSW_DEV_USR1_MOB_DATA);i++)
	{
		ucRDMSW_Config_Frame[i]= _RDMSW_DEV_USR1_MOB_DATA++;
		uiDataFrameLoc++;
	}
	for(unsigned int i=uiDataFrameLoc;i<_RDMSW_DEV_USR2_MOB_ADD0;i++)
	{
		ucRDMSW_Config_Frame[i]= 0;
		uiDataFrameLoc++;
	}
	///////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////
	for(unsigned int i=uiDataFrameLoc;i<sizeof(_RDMSW_DEV_USR2_MOB_DATA);i++)
	{
		ucRDMSW_Config_Frame[i]= _RDMSW_DEV_USR2_MOB_DATA++;
		uiDataFrameLoc++;
	}
	for(unsigned int i=uiDataFrameLoc;i<_RDMSW_DEV_USR3_MOB_ADD0;i++)
	{
		ucRDMSW_Config_Frame[i]= 0;
		uiDataFrameLoc++;
	}
	///////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////
	for(unsigned int i=uiDataFrameLoc;i<sizeof(_RDMSW_DEV_USR3_MOB_DATA);i++)
	{
		ucRDMSW_Config_Frame[i]= _RDMSW_DEV_USR3_MOB_DATA++;
		uiDataFrameLoc++;
	}
	for(unsigned int i=uiDataFrameLoc;i<_RDMSW_DEV_USR4_MOB_ADD0;i++)
	{
		ucRDMSW_Config_Frame[i]= 0;
		uiDataFrameLoc++;
	}
	///////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////
	for(unsigned int i=uiDataFrameLoc;i<sizeof(_RDMSW_DEV_USR4_MOB_DATA);i++)
	{
		ucRDMSW_Config_Frame[i]= _RDMSW_DEV_USR4_MOB_DATA++;
		uiDataFrameLoc++;
	}
	for(unsigned int i=uiDataFrameLoc;i<_RDMSW_DEV_USR5_MOB_ADD0;i++)
	{
		ucRDMSW_Config_Frame[i]= 0;
		uiDataFrameLoc++;
	}
	///////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////
	for(unsigned int i=uiDataFrameLoc;i<sizeof(_RDMSW_DEV_USR5_MOB_DATA);i++)
	{
		ucRDMSW_Config_Frame[i]= _RDMSW_DEV_USR5_MOB_DATA++;
		uiDataFrameLoc++;
	}
	for(unsigned int i=uiDataFrameLoc;i<_RDMSW_DEV_UDP_ADD0;i++)
	{
		ucRDMSW_Config_Frame[i]= 0;
		uiDataFrameLoc++;
	}
	///////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////
	for(unsigned int i=uiDataFrameLoc;i<sizeof(_RDMSW_DEV_UDP_DATA);i++)
	{
		ucRDMSW_Config_Frame[i]= *_RDMSW_DEV_UDP_DATA++;
		uiDataFrameLoc++;
	}
	for(unsigned int i=uiDataFrameLoc;i<_RDMSW_SERVER_UDP_ADD0;i++)
	{
		ucRDMSW_Config_Frame[i]= 0;
		uiDataFrameLoc++;
	}
	///////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////
	for(unsigned int i=uiDataFrameLoc;i<sizeof(_RDMSW_SERVER_UDP_DATA);i++)
	{
		ucRDMSW_Config_Frame[i]= *_RDMSW_SERVER_UDP_DATA++;
		uiDataFrameLoc++;
	}
	for(unsigned int i=uiDataFrameLoc;i<_RDMSW_SNAP_SEVIRTY_LVL_ADD0;i++)
	{
		ucRDMSW_Config_Frame[i]= 0;
		uiDataFrameLoc++;
	}
	///////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////
	for(unsigned int i=uiDataFrameLoc;i<sizeof(_RDMSW_SNAP_SEVIRTY_LVL_DATA);i++)
	{
		ucRDMSW_Config_Frame[i]= *_RDMSW_SNAP_SEVIRTY_LVL_DATA++;
		uiDataFrameLoc++;
	}
	for(unsigned int i=uiDataFrameLoc;i<_RDMSW_DATA_CAPT_TIME_ADD0;i++)
	{
		ucRDMSW_Config_Frame[i]= 0;
		uiDataFrameLoc++;
	}
	///////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////
	for(unsigned int i=uiDataFrameLoc;i<sizeof(_RDMSW_DATA_CAPT_TIME_DATA);i++)
	{
		ucRDMSW_Config_Frame[i]= *_RDMSW_DATA_CAPT_TIME_DATA++;
		uiDataFrameLoc++;
	}
	for(unsigned int i=uiDataFrameLoc;i<_RDMSW_CONFIG_DATA_LENGTH-2;i++)
	{
		ucRDMSW_Config_Frame[i]= 0;
		uiDataFrameLoc++;
	}
	///////////////////////////////////////////////////////////////////////////////////////////

while(*_RDMSW_DEVICE_ID_DATA != '\0')
{
	ucRDMSW_Config_Frame[*_RDMSW_DEVICE_ID_ADD0++] = (*_RDMSW_DEVICE_ID_DATA++);
	
}
while(*_RDMSW_DEVICE_ID_ADD0 <*_RDMSW_MNTH_MANFC_ADD0)ucRDMSW_Config_Frame[*_RDMSW_DEVICE_ID_ADD0++]=0;
while(*_RDMSW_MNTH_MANFC_DATA != '\0')
{
	ucRDMSW_Config_Frame[*_RDMSW_MNTH_MANFC_ADD0++] = (*_RDMSW_MNTH_MANFC_DATA++);
	
}
while(*_RDMSW_MNTH_MANFC_ADD0 <*_RDMSW_YEAR_MANFC_ADD0)ucRDMSW_Config_Frame[*_RDMSW_MNTH_MANFC_ADD0++]=0;
while(*_RDMSW_YEAR_MANFC_DATA != '\0')
{
	ucRDMSW_Config_Frame[*_RDMSW_YEAR_MANFC_ADD0++] = (*_RDMSW_YEAR_MANFC_DATA++);
	
}
while(*_RDMSW_YEAR_MANFC_ADD0 <*_RDMSW_QC_ENGNR_ADD0)ucRDMSW_Config_Frame[*_RDMSW_YEAR_MANFC_ADD0++]=0;
while(*_RDMSW_QC_ENGNR_DATA != '\0')
{
	ucRDMSW_Config_Frame[*_RDMSW_QC_ENGNR_ADD0++] = (*_RDMSW_QC_ENGNR_DATA++);
	
}
while(*_RDMSW_QC_ENGNR_ADD0 <*_RDMSW_DEV_MOB_NO_ADD0)ucRDMSW_Config_Frame[*_RDMSW_QC_ENGNR_ADD0++]=0;
while(*_RDMSW_DEV_MOB_NO_DATA != '\0')
{
	ucRDMSW_Config_Frame[*_RDMSW_DEV_MOB_NO_ADD0++] = (*_RDMSW_DEV_MOB_NO_DATA++);
	
}
while(*_RDMSW_DEV_MOB_NO_ADD0 <*_RDMSW_DEV_EMAIL_ID_ADD0)ucRDMSW_Config_Frame[*_RDMSW_DEV_MOB_NO_ADD0++]=0;
while(*_RDMSW_DEV_EMAIL_ID_DATA != '\0')
{
	ucRDMSW_Config_Frame[*_RDMSW_DEV_EMAIL_ID_ADD0++] = (*_RDMSW_DEV_EMAIL_ID_DATA++);
	
}
while(*_RDMSW_DEV_EMAIL_ID_ADD0 <*_RDMSW_DEV_PASSWORD_ADD0)ucRDMSW_Config_Frame[*_RDMSW_DEV_EMAIL_ID_ADD0++]=0;
while(*_RDMSW_DEV_PASSWORD_DATA != '\0')
{
	ucRDMSW_Config_Frame[*_RDMSW_DEV_PASSWORD_ADD0++] = (*_RDMSW_DEV_PASSWORD_DATA++);
	
}
while(*_RDMSW_DEVICE_ID_ADD0 <*_RDMSW_MNTH_MANFC_ADD0)ucRDMSW_Config_Frame[*_RDMSW_DEVICE_ID_ADD0++]=0;
while(*_RDMSW_DEV_SMTP_DATA != '\0')
{
	ucRDMSW_Config_Frame[*_RDMSW_DEV_SMTP_ADD0++] = (*_RDMSW_DEV_SMTP_DATA++);
	
}
while(*_RDMSW_DEVICE_ID_ADD0 <*_RDMSW_MNTH_MANFC_ADD0)ucRDMSW_Config_Frame[*_RDMSW_DEVICE_ID_ADD0++]=0;
while(*_RDMSW_DEV_REC1_MAIL_DATA != '\0')
{
	ucRDMSW_Config_Frame[*_RDMSW_DEV_REC1_MAIL_ADD0++] = (*_RDMSW_DEV_REC1_MAIL_DATA++);
	
}
while(*_RDMSW_DEVICE_ID_ADD0 <*_RDMSW_MNTH_MANFC_ADD0)ucRDMSW_Config_Frame[*_RDMSW_DEVICE_ID_ADD0++]=0;
while(*_RDMSW_DEV_REC2_MAIL_DATA != '\0')
{
	ucRDMSW_Config_Frame[*_RDMSW_DEV_REC2_MAIL_ADD0++] = (*_RDMSW_DEV_REC2_MAIL_DATA++);
	
}
while(*_RDMSW_DEVICE_ID_ADD0 <*_RDMSW_MNTH_MANFC_ADD0)ucRDMSW_Config_Frame[*_RDMSW_DEVICE_ID_ADD0++]=0;
while(*_RDMSW_DEV_REC3_MAIL_DATA != '\0')
{
	ucRDMSW_Config_Frame[*_RDMSW_DEV_REC3_MAIL_ADD0++] = (*_RDMSW_DEV_REC3_MAIL_DATA++);
	
}
while(*_RDMSW_DEVICE_ID_ADD0 <*_RDMSW_MNTH_MANFC_ADD0)ucRDMSW_Config_Frame[*_RDMSW_DEVICE_ID_ADD0++]=0;
while(*_RDMSW_DEV_REC4_MAIL_DATA != '\0')
{
	ucRDMSW_Config_Frame[*_RDMSW_DEV_REC4_MAIL_ADD0++] = (*_RDMSW_DEV_REC4_MAIL_DATA++);
	
}
while(*_RDMSW_DEVICE_ID_ADD0 <*_RDMSW_MNTH_MANFC_ADD0)ucRDMSW_Config_Frame[*_RDMSW_DEVICE_ID_ADD0++]=0;
while(*_RDMSW_DEV_REC5_MAIL_DATA != '\0')
{
	ucRDMSW_Config_Frame[*_RDMSW_DEV_REC5_MAIL_ADD0++] = (*_RDMSW_DEV_REC5_MAIL_DATA++);
	
}
while(*_RDMSW_DEVICE_ID_ADD0 <*_RDMSW_MNTH_MANFC_ADD0)ucRDMSW_Config_Frame[*_RDMSW_DEVICE_ID_ADD0++]=0;
while(*_RDMSW_DEV_USR1_MOB_DATA != '\0')
{
	ucRDMSW_Config_Frame[*_RDMSW_DEV_USR1_MOB_ADD0++] = (*_RDMSW_DEV_USR1_MOB_DATA++);
	
}
while(*_RDMSW_DEVICE_ID_ADD0 <*_RDMSW_MNTH_MANFC_ADD0)ucRDMSW_Config_Frame[*_RDMSW_DEVICE_ID_ADD0++]=0;
while(*_RDMSW_DEV_USR2_MOB_DATA != '\0')
{
	ucRDMSW_Config_Frame[*_RDMSW_DEV_USR2_MOB_ADD0++] = (*_RDMSW_DEV_USR2_MOB_DATA++);
	
}
while(*_RDMSW_DEVICE_ID_ADD0 <*_RDMSW_MNTH_MANFC_ADD0)ucRDMSW_Config_Frame[*_RDMSW_DEVICE_ID_ADD0++]=0;
while(*_RDMSW_DEV_USR3_MOB_DATA != '\0')
{
	ucRDMSW_Config_Frame[*_RDMSW_DEV_USR3_MOB_ADD0++] = (*_RDMSW_DEV_USR3_MOB_DATA++);
	
}
while(*_RDMSW_DEVICE_ID_ADD0 <*_RDMSW_MNTH_MANFC_ADD0)ucRDMSW_Config_Frame[*_RDMSW_DEVICE_ID_ADD0++]=0;
while(*_RDMSW_DEV_USR4_MOB_DATA != '\0')
{
	ucRDMSW_Config_Frame[*_RDMSW_DEV_USR4_MOB_ADD0++] = (*_RDMSW_DEV_USR4_MOB_DATA++);
	
}
while(*_RDMSW_DEVICE_ID_ADD0 <*_RDMSW_MNTH_MANFC_ADD0)ucRDMSW_Config_Frame[*_RDMSW_DEVICE_ID_ADD0++]=0;
while(*_RDMSW_DEV_USR5_MOB_DATA != '\0')
{
	ucRDMSW_Config_Frame[*_RDMSW_DEV_USR5_MOB_ADD0++] = (*_RDMSW_DEV_USR5_MOB_DATA++);
	
}
while(*_RDMSW_DEVICE_ID_ADD0 <*_RDMSW_MNTH_MANFC_ADD0)ucRDMSW_Config_Frame[*_RDMSW_DEVICE_ID_ADD0++]=0;
while(*_RDMSW_DEV_UDP_DATA != '\0')
{
	ucRDMSW_Config_Frame[*_RDMSW_DEV_UDP_ADD0++] = (*_RDMSW_DEV_UDP_DATA++);
	
}
while(*_RDMSW_DEVICE_ID_ADD0 <*_RDMSW_MNTH_MANFC_ADD0)ucRDMSW_Config_Frame[*_RDMSW_DEVICE_ID_ADD0++]=0;
while(*_RDMSW_SERVER_UDP_DATA != '\0')
{
	ucRDMSW_Config_Frame[*_RDMSW_SERVER_UDP_ADD0++] = (*_RDMSW_SERVER_UDP_DATA++);
	
}
while(*_RDMSW_DEVICE_ID_ADD0 <*_RDMSW_MNTH_MANFC_ADD0)ucRDMSW_Config_Frame[*_RDMSW_DEVICE_ID_ADD0++]=0;
while(*_RDMSW_SNAP_SEVIRTY_LVL_DATA != '\0')
{
	ucRDMSW_Config_Frame[*_RDMSW_SNAP_SEVIRTY_LVL_ADD0++] = (*_RDMSW_SNAP_SEVIRTY_LVL_DATA++);
	
}
while(*_RDMSW_DEVICE_ID_ADD0 <*_RDMSW_MNTH_MANFC_ADD0)ucRDMSW_Config_Frame[*_RDMSW_DEVICE_ID_ADD0++]=0;
while(*_RDMSW_DATA_CAPT_TIME_DATA != '\0')
{
	ucRDMSW_Config_Frame[*_RDMSW_DATA_CAPT_TIME_ADD0++] = (*_RDMSW_DATA_CAPT_TIME_DATA++);
	
}
while(*_RDMSW_DEVICE_ID_ADD0 <*_RDMSW_MNTH_MANFC_ADD0)ucRDMSW_Config_Frame[*_RDMSW_DEVICE_ID_ADD0++]=0;


		eeprom_write_byte((uint8_t*)byte_address,0x33);
		MCU_UART_Send_Byte(eeprom_read_byte((uint8_t*)byte_address));

DACB_CH0DATA=4095;
//_delay_ms(20000);
//GSM_Module_EMAIL_Init();
_delay_ms(5000);
GSM_Module_Send_SMS(MY_MOB_NO,MY_MOB_SMS_TXT);
//GPS_Module_Init();
GSM_Module_Send_SMS(MY_MOB_NO,MY_MOB_SMS_TXT);
//GPS_Module_Init();
//Dummy File
void ConvertHextoAscii(unsigned int x);
void Average_ADC_Value(void);
unsigned int ADC_Res;

main()
{
	DACB_CH0DATA=4095;
	//	SET_BIT(PORTE_OUT,1);
		
	
	Average_ADC_Value();
	ConvertHextoAscii(ADC_Res);
	
	/*	
		USARTD1_DATA='A';
		while(!((USARTD1_STATUS & 0x20)==0x20));
       TGLE_BIT(PORTE_OUT,1);
	   _delay_ms(1000);
}	
 */
	
	void ConvertHextoAscii(unsigned int x)
	{
		unsigned char a[4],i;
		a[0]=x/1000;
		x=x%1000;
		a[1]=x/100;
		x=x%100;
		a[2]=x/10;
		x=x%10;
		a[3]=x;
		for(i=0;i<4;i++)
		{
			USARTD1_DATA=a[i]+0x30;
			while(!((USARTD1_STATUS & 0x20)==0x20));
		}
		USARTD1_DATA=0x0C;
		while(!((USARTD1_STATUS & 0x20)==0x20));
		USARTD1_DATA=0x0A;
		while(!((USARTD1_STATUS & 0x20)==0x20));
		
	}
	void Average_ADC_Value(void)
	{
		unsigned int y;
		unsigned long int ADC_total;

		ADC_total=0;
		for(y=0;y<256;y++)
		{
			ADCA_CTRLA |= 0x08;//Channel 0 Selected
			ADCA_CH3_CTRL |= 0x81;//Channel 0 Start Conversion
			while(!((ADCA_CH3_INTFLAGS & 0x01)== 0x01));
			ADC_Res=ADCA_CH3_RES;
			ADC_total+=ADC_Res;
		}
		ADC_total=ADC_total>>8;
		ADC_Res=ADC_total;
	}

/////////////////////////11/12/2013/////////////////////////////////////////////////////////
/*
		//Average_ADC_Value();
		//ConvertHextoAscii(ADC_Res);
		//_delay_ms(500);
		DS1374_Set_Time(6,10,20,30);
		//ADC_Res = DS1374_Read_Time();
		USARTD1_DATA = TWIC_MASTER_STATUS;
		while(!((USARTD1_STATUS & 0x20)==0x20));*/

#if(0)
void ConvertHextoAscii(unsigned int x)
{
	unsigned char a[4],i;
	a[0]=x/1000;
	x=x%1000;
	a[1]=x/100;
	x=x%100;
	a[2]=x/10;
	x=x%10;
	a[3]=x;
	for(i=0;i<4;i++)
	{
		USARTD1_DATA=a[i]+0x30;
		while(!((USARTD1_STATUS & 0x20)==0x20));
	}
	USARTD1_DATA=0x0C;
	while(!((USARTD1_STATUS & 0x20)==0x20));
	USARTD1_DATA=0x0A;
	while(!((USARTD1_STATUS & 0x20)==0x20));
	
}
void Average_ADC_Value(void)
{
	unsigned int y;
	unsigned long int ADC_total;

	ADC_total=0;
	for(y=0;y<100;y++)
	{
		//ADCA_CTRLA |= 0x40;//Channel 0 Selected
		ADCA_CH0_CTRL |= 0x81;//Channel 0 Start Conversion
		while(!((ADCA_CH0_INTFLAGS & 0x01)== 0x01));
		//_delay_us(20);
		ADC_Res=ADCA_CH0_RES;
		ADC_total+=ADC_Res;
	}
	ADC_total=ADC_total/100;
	ADC_Res=ADC_total;
	
/*	unsigned int y;
	unsigned long int ADC_total;

	ADC_total=0;
	for(y=0;y<256;y++)
	{
		//ADCA_CTRLA |= 0x40;//Channel 0 Selected
		ADCA_CH0_CTRL |= 0x81;//Channel 0 Start Conversion
		while(!((ADCA_CH0_INTFLAGS & 0x01)== 0x01));
		//_delay_us(20);
		ADC_Res=ADCA_CH0_RES;
		ADC_total+=ADC_Res>>4;
	}
	ADC_total=ADC_total>>4;
	ADC_Res=ADC_total;
*/
}

#endif
void Average_ADC_Value(void);
void ConvertHextoAscii(unsigned int x);
/////////////////////////////////////////////////////////////////////////////////////////////////////
/*
void Mod_Data_Response(void)
{

	
	ucModRxdSlaveID  = ucModRxDataBufferArr[0];
	ucModRxdFuncCode = ucModRxDataBufferArr[1];
	ucModRxdRegAddrH = ucModRxDataBufferArr[2];
	ucModRxdRegAddrL = ucModRxDataBufferArr[3];
	ucModRxdNoBytesH = ucModRxDataBufferArr[4];
	ucModRxdNoBytesL = ucModRxDataBufferArr[5];
	ucModRxdCrcValuH = ucModRxDataBufferArr[ucModprCnt];
	ucModRxdCrcValuL = ucModRxDataBufferArr[ucModprCnt+1];
	uiCalCRCValue=crc(ucModRxDataBufferArr,6);
	uiRxdCRCValue=(ucModRxDataBufferArr[ucModprCnt]);
	uiRxdCRCValue <<=8;
	uiRxdCRCValue |= (ucModRxDataBufferArr[ucModprCnt+1]);
	if(uiCalCRCValue == uiRxdCRCValue)
	{
		Mod_Data_Send_Reply(ucModRxdSlaveID,ucModRxdFuncCode,ucModRxdRegAddrH,ucModRxdRegAddrL,ucModRxdNoBytesH,ucModRxdNoBytesL,0, ucModRxdCrcValuH,ucModRxdCrcValuL);
	}
}

void Mod_Data_Send_Reply(unsigned char SlaveID,unsigned char FuncCode,unsigned char RegAddrH,unsigned char RegAddrL,unsigned char NoBytesH,unsigned char NoBytesL,unsigned char *Dataframe, unsigned char CrcValuH,unsigned char CrcValuL)
{

	MCU_UART_Send_Byte(SlaveID);
	MCU_UART_Send_Byte(FuncCode);
	MCU_UART_Send_Byte(RegAddrH);
	MCU_UART_Send_Byte(RegAddrL);
	MCU_UART_Send_Byte(NoBytesH);
	MCU_UART_Send_Byte(NoBytesL);
	MCU_UART_Send_Byte(CrcValuH);
	MCU_UART_Send_Byte(CrcValuL);

}*/
if(bMODRxdFlag1==1)
{
	ucModRxBuff=ucModRxBuff1;
	//Mod_Data_process();
	bMODRxdFlag1=0;
	switch(ucModRxBuff)
	{
		case '0':
		//////////////////////////////////////AT Init Command/////////////////////////////////////////////////
		Dataptr = &GSM_AT;
		while(*Dataptr != '\0')
		{
			GSM_UART_Send_Byte(*Dataptr++);
		}
		GSM_UART_Send_Byte(0x0D);
		GSM_UART_Send_Byte(0x0A);
		break;
		case '1':
		///////////////////////////////////Power Off ECHO Command//////////////////////////////////////////////
		Dataptr = &GSM_ECHO;
		while(*Dataptr != '\0')
		{
			GSM_UART_Send_Byte(*Dataptr++);
		}
		GSM_UART_Send_Byte('0');
		GSM_UART_Send_Byte(0x0D);
		GSM_UART_Send_Byte(0x0A);
		_delay_ms(1000);
		break;
		case '2':
		////////////////////////////////////Basic GSM CG Enable//////////////////////////////////////////////////
		Dataptr = &GSM_CMGF;
		while(*Dataptr != '\0')
		{
			GSM_UART_Send_Byte(*Dataptr++);
		}
		GSM_UART_Send_Byte('=');
		GSM_UART_Send_Byte('1');
		GSM_UART_Send_Byte(0x0D);
		GSM_UART_Send_Byte(0x0A);
		break;
		case '3':
		////////////////////////////////////Basic GSM CG SMS Enable//////////////////////////////////////////////////
		Dataptr = &GSM_CGSMS;
		while(*Dataptr != '\0')
		{
			GSM_UART_Send_Byte(*Dataptr++);
		}
		GSM_UART_Send_Byte('=');
		GSM_UART_Send_Byte('1');
		GSM_UART_Send_Byte(0x0D);
		GSM_UART_Send_Byte(0x0A);
		break;
		case '4':
		////////////////////////////////////Network Registration Verification/////////////////////////////////////////
		Dataptr = &GSM_CREG;
		while(*Dataptr != '\0')
		{
			GSM_UART_Send_Byte(*Dataptr++);
		}
		GSM_UART_Send_Byte('?');
		GSM_UART_Send_Byte(0x0D);
		GSM_UART_Send_Byte(0x0A);
		break;
		case '5':
		////////////////////////////////////Network Registration Verification/////////////////////////////////////////
		Dataptr = &GSM_CMGS;
		while(*Dataptr != '\0')
		{
			GSM_UART_Send_Byte(*Dataptr++);
		}
		GSM_UART_Send_Byte('=');
		Dataptr = &MY_MOB_NO;
		while(*Dataptr != '\0')
		{
			GSM_UART_Send_Byte(*Dataptr++);
		}
		GSM_UART_Send_Byte(0x0D);
		GSM_UART_Send_Byte(0x0A);
		_delay_ms(500);
		Dataptr = &MY_MOB_SMS_TXT;
		while(*Dataptr != '\0')
		{
			GSM_UART_Send_Byte(*Dataptr++);
		}
		GSM_UART_Send_Byte(0x1A);
		break;
		case '6':
		break;
		case '7':
		break;
		case '8':
		break;
		case '9':
		break;
		case 'A':
		break;
		case 'B':
		break;
		case 'C':
		break;
		case 'D':
		break;
		case 'E':
		break;
		case 'F':
		break;
		default :
		break;
		
	}
}

/*	Get_MAK_Prod_Info();
	MCU_UART_Send_Byte(0x0D);
	MCU_UART_Send_Byte(0x0A);
	Get_MAK_Prod_Para_Info(0x01,0x20,0x00,0x50);
	MCU_UART_Send_Byte(0x0D);
	MCU_UART_Send_Byte(0x0A);
	Put_MAK_Prod_BroadCast_Mod();
	MCU_UART_Send_Byte(0x0D);
	MCU_UART_Send_Byte(0x0A);*/

/*
void GSM_Send_SMS(unsigned char *Mobile_No, unsigned char *TextMsg)
{
	unsigned char i;
	////////////////////////////////////Send SMS /////////////////////////////////////////
	Dataptr = &GSM_CMGS;
	while(*Dataptr != '\0')
	{
		GSM_UART_Send_Byte(*Dataptr++);
	}
	GSM_UART_Send_Byte('=');
	i=0;
	while(Mobile_No[i] !='\0')
	{
		GSM_UART_Send_Byte(Mobile_No[i++]);
	}
	GSM_UART_Send_Byte(0x0D);
	GSM_UART_Send_Byte(0x0A);
	_delay_ms(500);
	i=0;
	while(TextMsg[i] !='\0')
	{
		GSM_UART_Send_Byte(TextMsg[i++]);
	}
	GSM_UART_Send_Byte(0x1A);
	_delay_ms(3000);
	if(bGSMRxdFlag==1)
	{
		MCU_UART_Send_Byte('1');
		MCU_UART_Send_Byte(':');
		for(i=0;i<ucGSMRxdBuffCnt;i++)
		{
			MCU_UART_Send_Byte(ucGSMRxdBuff[i]);
		}
		bGSMRxdFlag=0;
	}
	else
	{
		MCU_UART_Send_Byte('0');
		MCU_UART_Send_Byte('0');
	}
}


void GSM_Module_Verification()
{
	
}
void GSM_Module_Init()
{
	unsigned char *Dataptr,i;
	//////////////////////////////////////AT Init Command/////////////////////////////////////////////////
	ucGSMRxdBuffCnt=0;
	Dataptr = &GSM_AT;
	while(*Dataptr != '\0')
	{
		GSM_UART_Send_Byte(*Dataptr++);
	}
	GSM_UART_Send_Byte(0x0D);
	GSM_UART_Send_Byte(0x0A);
	_delay_ms(3000);
	if(bGSMRxdFlag==1)
	{
	//	MCU_UART_Send_Byte('1');
	//	MCU_UART_Send_Byte(':');
	//	for(i=0;i<ucGSMRxdBuffCnt;i++)
	//	{
	//		MCU_UART_Send_Byte(ucGSMRxdBuff[i]);
	//	}
		bGSMRxdFlag=0;
	}
	else
	{
		//MCU_UART_Send_Byte('0');
		//MCU_UART_Send_Byte('0');
	}
	///////////////////////////////////Power Off ECHO Command//////////////////////////////////////////////
	ucGSMRxdBuffCnt=0;
	Dataptr = &GSM_ECHO;
	while(*Dataptr != '\0')
	{
		GSM_UART_Send_Byte(*Dataptr++);
	}
	GSM_UART_Send_Byte('0');
	GSM_UART_Send_Byte(0x0D);
	GSM_UART_Send_Byte(0x0A);
	_delay_ms(3000);
	if(bGSMRxdFlag==1)
	{
		//MCU_UART_Send_Byte('1');
		//MCU_UART_Send_Byte(':');
		//for(i=0;i<ucGSMRxdBuffCnt;i++)
		//{
		//	MCU_UART_Send_Byte(ucGSMRxdBuff[i]);
		//}
		//bGSMRxdFlag=0;
	}
	else
	{
		//MCU_UART_Send_Byte('0');
		//MCU_UART_Send_Byte('0');
	}
	////////////////////////////////////Basic GSM CG Enable//////////////////////////////////////////////////
	ucGSMRxdBuffCnt=0;
	Dataptr = &GSM_CMGF;
	while(*Dataptr != '\0')
	{
		GSM_UART_Send_Byte(*Dataptr++);
	}
	GSM_UART_Send_Byte('=');
	GSM_UART_Send_Byte('1');
	GSM_UART_Send_Byte(0x0D);
	GSM_UART_Send_Byte(0x0A);
	_delay_ms(3000);
	if(bGSMRxdFlag==1)
	{
		//MCU_UART_Send_Byte('1');
		//MCU_UART_Send_Byte(':');
		//for(i=0;i<ucGSMRxdBuffCnt;i++)
		//{
		//	MCU_UART_Send_Byte(ucGSMRxdBuff[i]);
		//}
		bGSMRxdFlag=0;
	}
	else
	{
		//MCU_UART_Send_Byte('0');
		//MCU_UART_Send_Byte('0');
	}
	////////////////////////////////////Basic GSM CG SMS Enable//////////////////////////////////////////////////
	Dataptr = &GSM_CGSMS;
	while(*Dataptr != '\0')
	{
		GSM_UART_Send_Byte(*Dataptr++);
	}
	GSM_UART_Send_Byte('=');
	GSM_UART_Send_Byte('1');
	GSM_UART_Send_Byte(0x0D);
	GSM_UART_Send_Byte(0x0A);
	_delay_ms(3000);
	if(bGSMRxdFlag==1)
	{
		//MCU_UART_Send_Byte('1');
		//MCU_UART_Send_Byte(':');
		//for(i=0;i<ucGSMRxdBuffCnt;i++)
		//{
		//	MCU_UART_Send_Byte(ucGSMRxdBuff[i]);
		//}
		bGSMRxdFlag=0;
	}
	else
	{
		//MCU_UART_Send_Byte('0');
		//MCU_UART_Send_Byte('0');
	}
	////////////////////////////////////Network Registration Verification/////////////////////////////////////////
	Dataptr = &GSM_CREG;
	while(*Dataptr != '\0')
	{
		GSM_UART_Send_Byte(*Dataptr++);
	}
	GSM_UART_Send_Byte('?');
	GSM_UART_Send_Byte(0x0D);
	GSM_UART_Send_Byte(0x0A);
	_delay_ms(3000);
	if(bGSMRxdFlag==1)
	{
		//MCU_UART_Send_Byte('1');
		//MCU_UART_Send_Byte(':');
		//for(i=0;i<ucGSMRxdBuffCnt;i++)
		//{
		//	MCU_UART_Send_Byte(ucGSMRxdBuff[i]);
		//}
		bGSMRxdFlag=0;
	}
	else
	{
		//MCU_UART_Send_Byte('0');
		//MCU_UART_Send_Byte('0');
	}
	_delay_ms(5000);
	////////////////////////////////////Send SMS /////////////////////////////////////////*/
/*	Dataptr = &GSM_CMGS;
	while(*Dataptr != '\0')
	{
		GSM_UART_Send_Byte(*Dataptr++);
	}
	GSM_UART_Send_Byte('=');
	Dataptr = &MY_MOB_NO;
	while(*Dataptr != '\0')
	{
		GSM_UART_Send_Byte(*Dataptr++);
	}
	GSM_UART_Send_Byte(0x0D);
	GSM_UART_Send_Byte(0x0A);
	_delay_ms(500);
	Dataptr = &MY_MOB_SMS_TXT;
	while(*Dataptr != '\0')
	{
		GSM_UART_Send_Byte(*Dataptr++);
	}
	GSM_UART_Send_Byte(0x1A);
	_delay_ms(3000);
	if(bGSMRxdFlag==1)
	{
		MCU_UART_Send_Byte('1');
		MCU_UART_Send_Byte(':');
		for(i=0;i<ucGSMRxdBuffCnt;i++)
		{
			MCU_UART_Send_Byte(ucGSMRxdBuff[i]);
		}
		bGSMRxdFlag=0;
	}
	else
	{
		MCU_UART_Send_Byte('0');
		MCU_UART_Send_Byte('0');
	}*/
//}	
GSM_Module_Send_Email("\"hari0118@gamil.com\",\"hello\"","hhhhh");
_delay_ms(5000);