/*
 * GccApplication1.c
 *
 * Created: 3/5/2014 11:02:22 AM
 *  Author: rnd-u7
 */ 


#include <avr/io.h>

int main(void)
{
    while(1)
    {
        //TODO:: Please write your application code 
    }
}