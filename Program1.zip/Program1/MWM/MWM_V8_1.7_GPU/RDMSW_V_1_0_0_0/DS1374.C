/*********************************************************************************************************************************
******************************************TYPE Defenition File for RDMSW *********************************************************
**********************************************************************************************************************************
**********************************************************************************************************************************
**********************************************************************************************************************************
**********************************************************************************************************************************
******************File Description			:
******************Author Name				: RHG*********************************************************************************
******************Guide Name				: KTS*********************************************************************************
******************Project Version			: RDMSW_V_1_0_0_0*********************************************************************
******************Date of Creation			: 12th December 2013******************************************************************
******************Modified Version Name		: ************************************************************************************
******************Date of Modification		: ************************************************************************************
******************Reason For Modification	: ************************************************************************************
**********************************************************************************************************************************
**********************************************************************************************************************************
**********************************************************************************************************************************
**********************************************************************************************************************************
**********************************************************************************************************************************/

#ifndef _DS1374_C_
#define _DS1374_C_
#include "HEADERS.H"


#define DS1374_WRITE_ADDRESS 0xD0
#define DS1374_READ_ADDRESS 0xD1
#define DS1374_REG_TOD0		0x00 /* Time of Day */
#define DS1374_REG_TOD1		0x01
#define DS1374_REG_TOD2		0x02
#define DS1374_REG_TOD3		0x03
#define DS1374_REG_WDALM0	0x04 /* Watchdog/Alarm */
#define DS1374_REG_WDALM1	0x05
#define DS1374_REG_WDALM2	0x06
#define DS1374_REG_CR		0x07 /* Control */
#define DS1374_REG_CR_AIE	0x01 /* Alarm Int. Enable */
#define DS1374_REG_CR_WDALM	0x20 /* 1=Watchdog, 0=Alarm */
#define DS1374_REG_CR_WACE	0x40 /* WD/Alarm counter enable */
#define DS1374_REG_SR		0x08 /* Status */
#define DS1374_REG_SR_OSF	0x80 /* Oscillator Stop Flag */
#define DS1374_REG_SR_AF	0x01 /* Alarm Flag */
#define DS1374_REG_TCR		0x09 /* Trickle Charge */


void TWI_START(void)
{
	TWIC_MASTER_CTRLC = 0x01;
	//while(!((TWIC_MASTER_STATUS & 0x40)== 0x40));
}
void TWI_STOP(void)
{
	TWIC_MASTER_CTRLC = 0x03;
//	while(!((TWIC_MASTER_STATUS & 0x40)== 0x40));
	
}
void TWI_RESTART(void)
{
	TWIC_MASTER_CTRLC = 0x01;
//	while(!((TWIC_MASTER_STATUS & 0x40)== 0x40));
	
}
unsigned char TWI_READ(void)
{
	unsigned char demo;
	while(!((TWIC_MASTER_STATUS & 0x80)== 0x80));
	demo=TWIC_MASTER_DATA;
	return demo;
	
}
void TWI_WRITE(unsigned char Data)
{
	TWIC_MASTER_DATA=Data;
	while(!((TWIC_MASTER_STATUS & 0x40)== 0x40));
	TWIC_MASTER_STATUS &= 0xBF;

}
void TWI_WRITE_DATA(unsigned char Day, unsigned char Hrs, unsigned Min, unsigned Sec)
{
	TWI_START();
	TWIC_MASTER_ADDR=DS1374_WRITE_ADDRESS;
	while(!((TWIC_MASTER_STATUS & 0x40)== 0x40));
	TWIC_MASTER_STATUS &= 0xBF;
//	TWI_WRITE(DS1374_WRITE_ADDRESS);
	TWI_WRITE(DS1374_REG_TOD0);
	TWI_WRITE(Day);
	//TWI_WRITE(Hrs);
	//TWI_WRITE(Min);
	//TWI_WRITE(Sec);
	TWI_STOP();
}
void DS1374_Set_Time(unsigned char day,unsigned char Hrs, unsigned char Min, unsigned char Sec)
{
	TWI_WRITE_DATA(day,Hrs,Min,Sec);
	
}
unsigned char DS1374_Read_Time(void)
{
	unsigned char demo;
	TWI_START();
	TWIC_MASTER_ADDR=DS1374_WRITE_ADDRESS;
	while(!((TWIC_MASTER_STATUS & 0x40)== 0x40));
	//	TWI_WRITE(DS1374_WRITE_ADDRESS);
	TWI_WRITE(DS1374_REG_TOD0);
	TWI_RESTART();
	TWIC_MASTER_ADDR=DS1374_READ_ADDRESS;
	while(!((TWIC_MASTER_STATUS & 0x40)== 0x40));
	demo = TWI_READ();
	return demo;
}
#endif