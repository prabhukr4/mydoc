
#ifndef _PROTOCOL_FRAME_H
#define _PROTOCOL_FRAME_H
#include "HEADERS.H"
/********************************************************
MODE_A_(DATA LOGGING)FUNCTIONS DEFINITIONS
********************************************************/
void Mode_A_PING_Query(void);
void Mode_A_INFO_Query(void);
void Mode_A_Parameters_Query(void);
void Mode_A_Day_Summary_Query(void);
void Mode_A_Warning_Query(void);
void Mode_A_Fault_Query(void);
void Mode_A_Response();

/***************************************************
MODE_B_(Response)FUNCTIONS DEFINITIONS
****************************************************/
void Mode_B_INFO_Response(void);
void Mode_B_Parameters_Response(void);
void Mode_B_Day_Summary_Response(void);
void Mode_B_Warning_Response(void);
void Mode_B_Fault_Response(void);

/************************************************
MODE_C_(Response)FUNCTIONS DEFINITIONS
*************************************************/
void Mode_C_INFO_Response(void);
void Mode_C_Parameters_Response(void);
void Mode_C_Day_Summary_Response(void);
void Mode_C_SNAP_SHOT_Response(void);

/************************************************
MODE_D_(Response)FUNCTIONS DEFINITIONS
*************************************************/
void Mode_D_DIG_IN_Response(void);
void Mode_D_DIG_OUT_Response(void);
void Mode_D_ANA_IN_Response(void);
void Mode_D_ANA_OUT_Response(void);
void Mode_D_LISENCE_Respose(void);
void Mode_D_ALL_IN_ONE_Response(void);

#define START		0x5B
#define	DEVICE_ID_1	0x3F
#define DEVICE_ID_2	0x42
#define DEVICE_ID_3	0x0F
#define DEVICE_ID_4	0x00
#define COMMAND		0x5E
#define COMMAND_ID	0x00
#define PROD_ID_VERSION	0x01
#define PROD_ID_FAMILY	0x00
#define PROD_ID_NO_1	0x01
#define PROD_ID_NO_2	0x00
/**************************************************************
MACROS definition for Function Code and Command Name
**************************************************************/
#define FC_MODE_A_PING_QUERY_H				0x00
#define FC_MODE_A_PING_QUERY_L				0x00
#define FC_MODE_A_INFO_QUERY_H				0x00
#define FC_MODE_A_INFO_QUERY_L				0x01	
#define	FC_MODE_A_PARAMETERS_QUERY_H		0x00
#define FC_MODE_A_PARAMETERS_QUERY_L		0x02
#define FC_MODE_A_DAY_SUMMARY_QUERY_H		0X00
#define FC_MODE_A_DAY_SUMMARY_QUERY_L		0x03
#define	FC_MODE_A_WARNING_QUERY_H			0x00
#define FC_MODE_A_WARNING_QUERY_L			0x04
#define FC_MODE_A_FAULT_QUERY_H				0x00
#define FC_MODE_A_FAULT_QUERY_L				0x05

#define FC_MODE_B_INFO_RESPONSE_H			0x01
#define FC_MODE_B_INFO_RESPONSE_L			0x01
#define FC_MODE_B_PARAMETERS_RESPONSE_H		0x01
#define FC_MODE_B_PARAMETERS_RESPONSE_L		0x02
#define FC_MODE_B_DAY_SUMMARY_RESPONSE_H	0x01
#define FC_MODE_B_DAY_SUMMARY_RESPONSE_H	0x03
#define FC_MODE_B_WARNING_RESPONSE_H		0x01
#define FC_MODE_B_WARNING_RESPONSE_L		0x04	
#define FC_MODE_B_FAULT_RESPONSE_H			0x01
#define FC_MODE_B_FAULT_RESPONSE_L			0x05

#define FC_MODE_C_INFO_RESPONSE_H			0xFF
#define FC_MODE_C_INFO_RESPONSE_L			0x00	
#define FC_MODE_C_PARAMETERS_RESPONSE_H		0xFF
#define FC_MODE_C_PARAMETERS_RESPONSE_L		0x00
#define FC_MODE_C_DAY_SUMMARY_RESPONSE_H	0xFF	
#define FC_MODE_C_DAY_SUMMARY_RESPONSE_L	0x00
#define FC_MODE_C_SNAP_SHOT_RESPONSE_H		0xFF
#define FC_MODE_C_SNAP_SHOT_RESPONSE_L		0x00

#define FC_MODE_D_DIG_IN_RESPONSE_H			0xFF
#define FC_MODE_D_DIG_IN_RESPONSE_L			0x01
#define FC_MODE_D_DIG_OUT_RESPONSE_H		0xFF
#define FC_MODE_D_DIG_OUT_RESPONSE_L		0x02
#define FC_MODE_D_ANA_IN_RESPONSE_H			0xFF
#define FC_MODE_D_ANA_IN_RESPONSE_L			0x03
#define FC_MODE_D_ANA_OUT_RESPONSE_H		0XFF
#define FC_MODE_D_ANA_OUT_RESPONSE_L		0x04
#define FC_MODE_D_LISENCE_H					0xFF
#define FC_MODE_D_LISENCE_L					0x05
#define FC_MODE_D_ALL_IN_ONE_H				0xFF
#define FC_MODE_D_ALL_IN_ONE_L				0x06


void Mode_A_PING_Query()
{
	
}	

void MODE_A_INFO_Query()
{
	
}



#endif































 

					