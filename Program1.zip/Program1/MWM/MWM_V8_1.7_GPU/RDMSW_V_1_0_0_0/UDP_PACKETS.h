#ifndef _UDP_PACKETS_H_
#define _UDP_PACKETS_H_

#include "HEADERS.H"
extern void periodical_interval_function(void);

/***************************************************************************************************************
Procedure to Send Packets to UDP:

1. Send -  GSM_STATUS_Exec() Function 

2. Send - AT#SSEND=1 and Enter

3. Send the packets that we want to send to cloud and terminate the packets by giving CTRL+Z command 

or 0x1A value to the end of the command.

****************************************************************************************************************/
void UDP_RETRY(unsigned char Retry_status)
{
	if((GSM_Struct.Start_Transmission_command == 0) && (UDP_Retry_count<GSM_MAX_RETRY_COUNT))//retry function should be perform for the defined time out
	{
		Qin_GSM_Rxd_buff      = 0;
		Qout_GSM              = 0;
		Packets_Received_Flag = 0;
		ucGSMRxdBuffCnt       = 0;
		bGSMRxdFlag1          = 0;
		bGSMRxdFlag           = 0;
		UDP_Retry_count++;
		
		if(UDP_Retry_count>=GSM_MAX_RETRY_COUNT)
		{
			bGSMRxdFlag                           = 0;
			ucGSMRxdBuffCnt                       = 0;
			GSM_Struct.Start_Transmission_command = 0;
			Qin_GSM                               = 0;
			Qout_GSM                              = 0;
			UDP_Retry_count                       = 0;
			GSM_Struct.cloud_true_flag			  = 0;
			GSM_Struct.network_present			  = 0;
			sms.gsm_gprs_fail					  = 1;
			sms.gsm_gps_ok						  = 0;
			sms.gsm_gps_ok_Sts					  = 0;
			GSM_COMMAND_STATUS	= SEND_GSM_INIT_AT;
		}
		else
		{			
			MWM_COMMAND_STATUS  = Retry_status;
			GPS_Location_Status = AQUIRE_GPS_DATA;
		}		
	}
	else
	{
		GSM_Struct.Start_Transmission_command = 0;
		Qout_GSM							  = 0;
		GPS_Location_Status                   = AQUIRE_GPS_DATA;
		MWM_COMMAND_STATUS                    = PUT_RDMS_PING_COMMAND;		
	}
}

void GPRS_CHK_Cmd_test(void)
{
	if(bGSMRxdFlag==1)
	{		
		while(ucGSMRxdBuff[testcount] != ':')
		{
			testcount++;			
		}
		
		if(ucGSMRxdBuff[testcount+1] == '0')
		{
			GSM_COMMAND_STATUS = SEND_GSM_GPRS_ACTIVATE_CMD;
			testcount          = 0;
			ucGSMRxdBuffCnt    = 0;
			Qout_GSM           = 0;
			gsm_retry_count    = 0;
			bGSMRxdFlag        = 0;			
		}
		else if(ucGSMRxdBuff[testcount+1] == '1')
		{
			GSM_COMMAND_STATUS = SEND_GSM_NETWORK_REGISTRATION;
			testcount          = 0;
			ucGSMRxdBuffCnt    = 0;
			Qout_GSM           = 0;
			gsm_retry_count    = 0;
			bGSMRxdFlag        = 0;			
		}		
	}
	else
	{		
		if((GSM_Struct.Start_Transmission_command == 0) && (gsm_retry_count<GSM_MAX_RETRY_COUNT))
		{
			bGSMRxdFlag     = 0;
			testcount       = 0;
			ucGSMRxdBuffCnt = 0;
			Qout_GSM        = 0;
			gsm_retry_count++;
			
			if(gsm_retry_count>=GSM_MAX_RETRY_COUNT)
			{
				bGSMRxdFlag                           = 0;
				ucGSMRxdBuffCnt                       = 0;
				GSM_Struct.Start_Transmission_command = 0;
				Qin_GSM                               = 0;
				Qout_GSM                              = 0;
				gsm_retry_count                       = 0;
				Send_command_status                   = SEND_GSM_INIT_AT;
				
			}
			else
			{
				Send_command_status = 0x03;
				
			}			
		}
	}
}

/******************************************************************************************
Function Name: Mode_A_PING_Command

Function Description: Will register itself to the server regarding its IP and Port number
and initiates the communication. 

Function Parameters : None

Output :
*******************************************************************************************/
void Mode_A_PING_Command(void)
{
	// Local variables declaration
	unsigned int UDP_uICRC;
	unsigned char UDP_uICRCH,UDP_uICRCL;
	unsigned char End_Txt_Addr;
	unsigned char udpDataFrame[40];
	unsigned char tempDataFrame[40];
	unsigned char j=0;
	Modbus_Struct.cloud_txd_bit = 1;//Setting this bit will indicate that there is an transmission is going on with the cloud
	GPS_Data_Collect();//Collecting the GPS informations
	if(Transmit_data == 1)//if all the informations are got from the GPS then this bit will set to 1
	{
		Transmit_data = 0;
		//Loading all the values in a buffer
		tempDataFrame[0]  = 0x80;
		tempDataFrame[1]  = 0x00;
		tempDataFrame[2]  = PROD_ID_NO_3;
		tempDataFrame[3]  = PROD_ID_NO_4;
		tempDataFrame[4]  = CMD;
		tempDataFrame[5]  = CMD_ID;
		tempDataFrame[6]  = LAT_GPS_BYTE0;
		tempDataFrame[7]  = LAT_GPS_BYTE1;
		tempDataFrame[8]  = LAT_GPS_BYTE2;
		tempDataFrame[9]  = LAT_GPS_BYTE3;
		tempDataFrame[10] = LON_GPS_BYTE0;
		tempDataFrame[11] = LON_GPS_BYTE1;
		tempDataFrame[12] = LON_GPS_BYTE2;
		tempDataFrame[13] = LON_GPS_BYTE3;	
		tempDataFrame[14] = Speed;
		tempDataFrame[15] = info_code;
		tempDataFrame[16] = FC_MODE_A_PING_BROADCAST_H;//Function code for Ping command
		tempDataFrame[17] = FC_MODE_A_PING_BROADCAST_L;
		tempDataFrame[18] = DATA_LENGTH_PING_CMD_HI;	
		tempDataFrame[19] = DATA_LENGTH_PING_CMD_LO;
		tempDataFrame[20] = Time_Hr;
		tempDataFrame[21] = Time_Min;
		tempDataFrame[22] = Time_Sec;
		tempDataFrame[23] = Date_Byte1;
		tempDataFrame[24] = Date_Byte2;
	
		//****************************CRC Calculation********************************************//
		//CRC calculation should done without including the start of character '['									
		UDP_uICRC = crc(tempDataFrame,25);
		UDP_uICRCH=(UDP_uICRC>>8);
		UDP_uICRCL=(UDP_uICRC);
		//Loading the CRC values to the same buffer
		tempDataFrame[25]=UDP_uICRCH;
		tempDataFrame[26]=UDP_uICRCL;
		tempDataFrame[27]=END;
		//Loading the start of the character to the udp buffer
		udpDataFrame[0] = START;
		//Copying the values in the tempdataframe to udp buffer which has the start of character	and exact protocol format
		j=1;
		for(unsigned char i=0;i<28;i++)
		{
			udpDataFrame[j] = tempDataFrame[i];
			j++;
		}
		End_Txt_Addr = 29;
	
		//Sending the total bytes in the udp data frame to the Server by sending the AT Command--------> AT+SSENDEXT=1,data length (Enter) data
		GSM_Send_UART_String_2(GSM_SSENDEXT,'=',"1",29,0x0D,0x0A,udpDataFrame,End_Txt_Addr);//Loading all the data bytes and commands in a same buffer and transmitting via interrupt
		GSM_Struct.Start_Transmission_command = 1;
		USARTD0_DATA = GSM_Struct.Queue_GSM_Command_Buff[Qout_GSM];
	}
	if(transmit_flag == 1)//This flag is set when 0x0A character is found to be transmitting in interrupt this causes a small delay in transmitting the command and transmitting the data to the Server
	{
		transmit_flag                         = 0;
		Qout_GSM                              = Qout_GSM +1;
		GSM_Struct.Start_Transmission_command = 1;
		USARTD0_DATA                          = GSM_Struct.Queue_GSM_Command_Buff[Qout_GSM];
		MWM_COMMAND_STATUS					  = WAIT_FOR_RDMS_PING_ACK;//Changing the MWM status to wait for Ping acknowledge
	}
	else
	{
		Qout_GSM = 0;
	}		
}

/*************************************************************************************************
Function Name: INFO_Broadcast()

Function Description: Will load all the information about the equipment and laod in a buffer
udpDataFrame after that send to UDP

Function Parameters : None

Output :
************************************************************************************************/
void MODE_A_INFO_BroadCast(void)
{
	unsigned int uICRC,i,y,j;
	unsigned char uICRCH,uICRCL;
	unsigned char End_Txt_Addr;
	unsigned char udpDataFrame[100];
	unsigned char tempDataFrame[100];
	
	GPS_Data_Collect();//Collecting the GPS informations
	
	if(Transmit_data == 1)//if all the informations are got from the GPS then this bit will set to 1
	{
		Transmit_data = 0;
		//Loading all the values in a buffer
		tempDataFrame[0]  = 0x80;
		tempDataFrame[1]  = 0x00;
		tempDataFrame[2]  = PROD_ID_NO_3;
		tempDataFrame[3]  = PROD_ID_NO_4;
		tempDataFrame[4]  = CMD;
		tempDataFrame[5]  = CMD_ID;
		tempDataFrame[6]=LAT_GPS_BYTE0;
		tempDataFrame[7]=LAT_GPS_BYTE1;
		tempDataFrame[8]=LAT_GPS_BYTE2;
		tempDataFrame[9]=LAT_GPS_BYTE3;
		tempDataFrame[10]=LON_GPS_BYTE0;
		tempDataFrame[11]=LON_GPS_BYTE1;
		tempDataFrame[12]=LON_GPS_BYTE2;
		tempDataFrame[13]=LON_GPS_BYTE3;
		tempDataFrame[14]=Speed;
		tempDataFrame[15]=info_code;
	
		if(Info_Query_Bit == 1)
		{
			tempDataFrame[16]=FC_MODE_B_INFO_RESPONSE_H;
			tempDataFrame[17]=FC_MODE_B_INFO_RESPONSE_L;
		}
		else
		{
			tempDataFrame[16]=FC_MODE_A_INFO_BRAODCAST_H;
			tempDataFrame[17]=FC_MODE_A_INFO_BROADCAST_L;
		}
		tempDataFrame[18]=DATA_LENGTH_INFO_CMD_HI;
		tempDataFrame[19]=DATA_LENGTH_INFO_CMD_LO;
	
		/*************Collecting Informations stored in EEPROM*******************/
		Check_Collect_EEPROM_From_Actual_Data_Register();
		j=20;
		for(i=0;i<Qin_Config_info_UDP;i++)
		{
			tempDataFrame[j] = Config_info[i];
			j++;
		}
		/****************************************************************************/
		tempDataFrame[j]   =Engine_Hours_byte1;
		tempDataFrame[j+1] =Engine_Hours_byte2;
		tempDataFrame[j+2] =Engine_Hours_byte3;
		tempDataFrame[j+3] =Engine_Hours_byte4;	
		tempDataFrame[j+4] =Software_version_byte1;
		tempDataFrame[j+5] =Software_version_byte2;
		tempDataFrame[j+6] =Software_version_byte3;
		tempDataFrame[j+7] =Software_version_byte4;
		tempDataFrame[j+8] =Hardware_version_byte1;
		tempDataFrame[j+9] =Hardware_version_byte2;
		tempDataFrame[j+10] =Hardware_version_byte3;
		tempDataFrame[j+11] =Hardware_version_byte4;
		tempDataFrame[j+12]=Time_Hr;
		tempDataFrame[j+13]=Time_Min;
		tempDataFrame[j+14]=Time_Sec;
		tempDataFrame[j+15]=Date_Byte1;
		tempDataFrame[j+16]=Date_Byte2;
		//CRC calculation should done without including the start of character '['	
		uICRC = crc(tempDataFrame,(j+17));
		uICRCH=(uICRC>>8);
		uICRCL=(uICRC);
		//Loading the CRC values to the same buffer
		tempDataFrame[j+17]=uICRCH;
		tempDataFrame[j+18]=uICRCL;
		tempDataFrame[j+19]=END;
		//Loading the start of the character to the udp buffer
		udpDataFrame[0] = START;
		//Copying the values in the tempdataframe to udp buffer which has the start of character	and exact protocol format
		y=1;
		for(i=0;i<(j+20);i++)
		{
			udpDataFrame[y] = tempDataFrame[i];
			y++;
		}
		End_Txt_Addr = (j+21);
		/*MCU_UART_Send_String("SENDING_INFO_BROADCAST");*/
		////////////******************SENDING THE PACKETS TO UDP***********************///////////////////	
		//Sending the total bytes in the udp data frame to the Server by sending the AT Command--------> AT+SSENDEXT=1,data length (Enter) data
		GSM_Send_UART_String_2(GSM_SSENDEXT,'=',"1",(j+21),0x0D,0x0A,udpDataFrame,End_Txt_Addr);//Loading all the data bytes and commands in a same buffer and transmitting via interrupt
		GSM_Struct.Start_Transmission_command = 1;
		USARTD0_DATA = GSM_Struct.Queue_GSM_Command_Buff[Qout_GSM];		
	}
	if(transmit_flag == 1)//This flag is set when 0x0A character is found to be transmitting in interrupt this causes a small delay in transmitting the command and transmitting the data to the Server
	{
		transmit_flag                         = 0;
		Qout_GSM                              = Qout_GSM +1;
		GSM_Struct.Start_Transmission_command = 1;
		USARTD0_DATA                          = GSM_Struct.Queue_GSM_Command_Buff[Qout_GSM];
		MWM_COMMAND_STATUS	                  = WAIT_FOR_RDMS_INFO_ACK;//Changing the MWM status to Info Acknowledge
	}
	else
	{
		Qout_GSM = 0;
	}
}

/*************************************************************************************
Function Name: Mode_A_Parameters_Broadcast()

Function Description: Will load all the Parameters of equipment and send to UDP

Function Parameters : None 

Output : 
*************************************************************************************/
void MODE_A_Parameters_BroadCast(void)
{
	unsigned int uICRC,i;
	unsigned char uICRCH,uICRCL;
	unsigned char End_Txt_Addr;
	unsigned char y,j;
	uint16_t k;
	unsigned char udpDataFrame[150];
	unsigned char tempDataFrame[150];
	uint16_t udp_data_length;
	
	udp_data_length  = (Total_Parameter_data_length+5);//Storing the data length that is received from the equipment to udp_data_length (+5 denotes that additional bytes for Time and Date Stamp)
	GPS_Data_Collect();//Collecting the GPS informations
	
	if(Transmit_data == 1)//if all the informations are got from the GPS then this bit will set to 1
	{
		Transmit_data  = 0;
		//Loading all the values in a buffer
		tempDataFrame[0]  = 0x80;
		tempDataFrame[1]  = 0x00;
		tempDataFrame[2]  = PROD_ID_NO_3;
		tempDataFrame[3]  = PROD_ID_NO_4;
		tempDataFrame[4]  = CMD;
		tempDataFrame[5]  = CMD_ID;
		tempDataFrame[6]  = LAT_GPS_BYTE0;
		tempDataFrame[7]  = LAT_GPS_BYTE1;
		tempDataFrame[8]  = LAT_GPS_BYTE2;
		tempDataFrame[9]  = LAT_GPS_BYTE3;
		tempDataFrame[10] = LON_GPS_BYTE0;
		tempDataFrame[11] = LON_GPS_BYTE1;
		tempDataFrame[12] = LON_GPS_BYTE2;
		tempDataFrame[13] = LON_GPS_BYTE3;
		tempDataFrame[14] = Speed;
		tempDataFrame[15] = info_code;
		if(Parameter_Query_Bit==1)
		{
			tempDataFrame[16]=FC_MODE_B_PARAMETERS_RESPONSE_H;//Function Code for parameter command in Mode B - 0x0102
			tempDataFrame[17]=FC_MODE_B_PARAMETERS_RESPONSE_L;
		}
		else
		{
			tempDataFrame[16]=FC_MODE_A_PARAMETERS_BROADCAST_H;//Function Code for parameter command in Mode B - 0x0002
			tempDataFrame[17]=FC_MODE_A_PARAMETERS_BROADCAST_L;
		}
		tempDataFrame[18]=udp_data_length>>8;
		tempDataFrame[19]=udp_data_length;
		/* Here Modbus_struct.Parameters_buff  contains the values received from equipment
		now the values are copying to the temporary buffer fro UDP
		*/
		k=20;
		for(j=0;j<Total_Parameter_data_length;j++)
		{
			tempDataFrame[k] = Modbus_Struct.Parameters_buff[j];
			k+=1;
		}

		tempDataFrame[k]   = Time_Hr;
		tempDataFrame[k+1] = Time_Min;
		tempDataFrame[k+2] = Time_Sec;
		tempDataFrame[k+3] = Date_Byte1;
		tempDataFrame[k+4] = Date_Byte2;
		//CRC calculation should done without including the start of character '['	
		uICRC = crc(tempDataFrame,(k+5));
		uICRCH=(uICRC>>8);
		uICRCL=(uICRC);
		//Loading the CRC values to the same buffer
		tempDataFrame[k+5]=uICRCH;
		tempDataFrame[k+6]=uICRCL;
		tempDataFrame[k+7]=END;
		//Loading the start of the character to the udp buffer
		udpDataFrame[0] = START;
		//Copying the values in the tempdataframe to udp buffer which has the start of character	and exact protocol format
		y=1;
		for(i=0;i<(k+8);i++)
		{
			udpDataFrame[y] = tempDataFrame[i];
			y++;
		
		}
	
		End_Txt_Addr = (k+9);
		//SENDING THE PACKETS TO UDP
		//Sending the total bytes in the udp data frame to the Server by sending the AT Command--------> AT+SSENDEXT=1,data length (Enter) data
		GSM_Send_UART_String_2(GSM_SSENDEXT,'=',"1",(k+9),0x0D,0x0A,udpDataFrame,End_Txt_Addr);//Loading all the data bytes and commands in a same buffer and transmitting via interrupt
		GSM_Struct.Start_Transmission_command = 1;
		USARTD0_DATA                          = GSM_Struct.Queue_GSM_Command_Buff[Qout_GSM];
	}
	if(transmit_flag == 1)//This flag is set when 0x0A character is found to be transmitting in interrupt this causes a small delay in transmitting the command and transmitting the data to the Server
	{
		transmit_flag						  = 0;
		Qout_GSM                              = Qout_GSM +1;
		GSM_Struct.Start_Transmission_command = 1;
		USARTD0_DATA                          = GSM_Struct.Queue_GSM_Command_Buff[Qout_GSM];
		MWM_COMMAND_STATUS					  = WAIT_FOR_RDMS_PARAMETERS_ACK;//Changing the MWM status to wait for Parameters command acknowledgment
	}
	else
	{
		Qout_GSM                              = 0;
	}
}

/*************************************************************************************
Function Name: Mode_A_Day_Summary_Broadcast()

Function Description: WIll broadcast for each engine start and Stop
at the end of the day day summary will broadcast

Function Parameters : None

Output :
*************************************************************************************/
void MODE_A_Day_Summary_BroadCast(void)
{
	unsigned int uICRC,i;
	unsigned char uICRCH,uICRCL;
	unsigned char End_Txt_Addr;
	unsigned char y,j;
	unsigned char udpDataFrame[180];
	unsigned char tempDataFrame[180];
	uint16_t udp_data_length;
	uint16_t k;
	udp_data_length = (DataLogg_Struct.cycle_summary_total_data_length+5);//Storing the data length that is received from the equipment to udp_data_length (+5 denotes that additional bytes for Time and Date Stamp)
		
	GPS_Data_Collect();//Collecting the GPS informations
	
	if(Transmit_data == 1)//if all the informations are got from the GPS then this bit will set to 1
	{
		Transmit_data = 0;
		//Loading all the values in a buffer
		tempDataFrame[0]  = 0x80;
		tempDataFrame[1]  = 0x00;
		tempDataFrame[2]  = PROD_ID_NO_3;
		tempDataFrame[3]  = PROD_ID_NO_4;
		tempDataFrame[4]  = CMD;
		tempDataFrame[5]  = CMD_ID;
		tempDataFrame[6]  = LAT_GPS_BYTE0;
		tempDataFrame[7]  = LAT_GPS_BYTE1;
		tempDataFrame[8]  = LAT_GPS_BYTE2;
		tempDataFrame[9]  = LAT_GPS_BYTE3;
		tempDataFrame[10] = LON_GPS_BYTE0;
		tempDataFrame[11] = LON_GPS_BYTE1;
		tempDataFrame[12] = LON_GPS_BYTE2;
		tempDataFrame[13] = LON_GPS_BYTE3;
		tempDataFrame[14] = Speed;
		tempDataFrame[15] = info_code;
		if(Cycle_Summary_Query_Bit==1)
		{
			tempDataFrame[16]=FC_MODE_B_DAY_SUMMARY_RESPONSE_H;//Function Code forCycle summary in Mode B - 0x0103
			tempDataFrame[17]=FC_MODE_B_DAY_SUMMARY_RESPONSE_L;
		}
		else
		{
			tempDataFrame[16]=FC_MODE_A_DAY_SUMMARY_BROADCAST_H;//Function Code for parameter command in Mode B - 0x0003
			tempDataFrame[17]=FC_MODE_A_DAY_SUMMARY_BROADCAST_L;
		}
		tempDataFrame[18]=udp_data_length>>8;
		tempDataFrame[19]=udp_data_length;

		/*	
		HereModbus_Struct.Day_Summary_buff contains the values received from equipment
		now the values are copying to the temporary buffer fro UDP	
		*/
		if(Day_Summary_Interval_flag == 1)//This flag will be set if the day summary time interval reaches
		{
			//Making the start date, time and End date, time to zero this is because the server will identify that the upcoming command is  Day summary
			tempDataFrame[20]         = 0;
			tempDataFrame[21]         = 0;
			tempDataFrame[22]         = 0;
			tempDataFrame[23]         = 0;
			tempDataFrame[24]         = 0;
			tempDataFrame[25]         = 0;
			tempDataFrame[26]         = 0;
			tempDataFrame[27]         = 0;
			k=28;
			for(j=8;j<chk_udp_data_length;j++)
			{
				tempDataFrame[k] = Modbus_Struct.Day_Summary_buff[j];
				k+=1;
			}
		}
		else
		{	//Copying the values in the tempdataframe to udp buffer which has the start of character	and exact protocol format
			k=20;
			for(j=0;j<chk_udp_data_length;j++)
			{
				tempDataFrame[k] = Modbus_Struct.Day_Summary_buff[j];
				k+=1;
			}
		}

		tempDataFrame[k]   = Time_Hr;
		tempDataFrame[k+1] = Time_Min;
		tempDataFrame[k+2] = Time_Sec;
		tempDataFrame[k+3] = Date_Byte1;
		tempDataFrame[k+4] = Date_Byte2;
	
		uICRC              = crc(tempDataFrame,(k+5));
		uICRCH             = (uICRC>>8);
		uICRCL             = (uICRC);
		tempDataFrame[k+5] = uICRCH;
		tempDataFrame[k+6] = uICRCL;
		tempDataFrame[k+7] = END;

	
		udpDataFrame[0] = START;
	
		y=1;
		for(i=0;i<(k+8);i++)
		{
			udpDataFrame[y] = tempDataFrame[i];
			y++;
		}
	
		End_Txt_Addr = (k+9);
		//SENDING THE PACKETS TO UDP
		//Sending the total bytes in the udp data frame to the Server by sending the AT Command--------> AT+SSENDEXT=1,data length (Enter) data
	
		GSM_Send_UART_String_2(GSM_SSENDEXT,'=',"1",(k+9),0x0D,0x0A,udpDataFrame,End_Txt_Addr);//Loading all the data bytes and commands in a same buffer and transmitting via interrupt
		GSM_Struct.Start_Transmission_command = 1;
		USARTD0_DATA                          = GSM_Struct.Queue_GSM_Command_Buff[Qout_GSM];		                     
	}
		
	if(transmit_flag == 1)//This flag is set when 0x0A character is found to be transmitting in interrupt this causes a small delay in transmitting the command and transmitting the data to the Server
	{
		transmit_flag						  = 0;
		Qout_GSM                              = Qout_GSM +1;
		GSM_Struct.Start_Transmission_command = 1;
		USARTD0_DATA                          = GSM_Struct.Queue_GSM_Command_Buff[Qout_GSM];
		MWM_COMMAND_STATUS                    = WAIT_FOR_RDMS_DAY_SUMMARY_ACK;//Changing the MWM status to wait for day summary and Cycle summary
	}
	else
	{
		Qout_GSM = 0;
	}
}

/*
*	Function Name : Mode_A_Warning_Fault_Broadcast()
*	Function Description : The fault and warning bytes that is got from the Equipment will transmit to server 
*	Function parameter : None
*/
void MODE_A_Warning_Fault_Braodcast(void)
{
	unsigned int uICRC,i;
	unsigned char uICRCH,uICRCL;
	unsigned char End_Txt_Addr;
	unsigned char y,j;
	unsigned char udpDataFrame[40];
	unsigned char tempDataFrame[40];
	uint16_t udp_data_length;
	uint16_t k;
	
	udp_data_length = (8+5);
	
	GPS_Data_Collect();//Collecting the GPS informations
	if(Transmit_data == 1)//if all the informations are got from the GPS then this bit will set to 1
	{
		Transmit_data = 0;
		tempDataFrame[0]  = 0x80;
		tempDataFrame[1]  = 0x00;
		tempDataFrame[2]  = PROD_ID_NO_3;
		tempDataFrame[3]  = PROD_ID_NO_4;
		tempDataFrame[4]  = CMD;
		tempDataFrame[5]  = CMD_ID;
		tempDataFrame[6]  = LAT_GPS_BYTE0;
		tempDataFrame[7]  = LAT_GPS_BYTE1;
		tempDataFrame[8]  = LAT_GPS_BYTE2;
		tempDataFrame[9]  = LAT_GPS_BYTE3;
		tempDataFrame[10] = LON_GPS_BYTE0;
		tempDataFrame[11] = LON_GPS_BYTE1;
		tempDataFrame[12] = LON_GPS_BYTE2;
		tempDataFrame[13] = LON_GPS_BYTE3;
		tempDataFrame[14] = Speed;
		tempDataFrame[15] = info_code;
		if(Fault_Warning_Query_Bit==1)
		{
			tempDataFrame[16]=FC_MODE_B_FAULT_WARNG_RESPONSE_H;
			tempDataFrame[17]=FC_MODE_B_FAULT_WARNG_RESPONSE_L;
		}
		else
		{
			tempDataFrame[16]=FC_MODE_A_FAULT_WARNG_BROADCAST_H;
			tempDataFrame[17]=FC_MODE_A_FAULT_WARNG_BROADCAST_L;
		}
	
		tempDataFrame[18]=udp_data_length>>8;
		tempDataFrame[19]=udp_data_length;
	
		/***********Here flash data buff contains the values received from equipment***************************
		************now the values are copying to the temporary buffer fro udp******************************/
		if(Modbus_Struct.Device_absent_flag == 1)//if the device is fail to communicate then make the MSB bit of Most significant byte as 1
		{
			Modbus_Struct.Fault_Warning_buff[0] |= 0x80;
		}
		k=20;
		for(j=0;j<(udp_data_length-5);j++)
		{
			tempDataFrame[k] = Modbus_Struct.Fault_Warning_buff[j];
			k+=1;
		}

		tempDataFrame[k]=Time_Hr;
		tempDataFrame[k+1]=Time_Min;
		tempDataFrame[k+2]=Time_Sec;
		tempDataFrame[k+3]=Date_Byte1;
		tempDataFrame[k+4]=Date_Byte2;
	
	
		uICRC             = crc(tempDataFrame,(k+5));
		uICRCH            = (uICRC>>8);
		uICRCL            = (uICRC);
		tempDataFrame[k+5] = uICRCH;
		tempDataFrame[k+6] = uICRCL;
		tempDataFrame[k+7] = END;

		udpDataFrame[0] = START;
	
		y=1;
		for(i=0;i<(k+8);i++)
		{
			udpDataFrame[y] = tempDataFrame[i];
			y++;
		
		}

		End_Txt_Addr = (k+9);
	
		//SENDING THE PACKETS TO UDP
		//Sending the total bytes in the udp data frame to the Server by sending the AT Command--------> AT+SSENDEXT=1,data length (Enter) data

		GSM_Send_UART_String_2(GSM_SSENDEXT,'=',"1",(k+9),0x0D,0x0A,udpDataFrame,End_Txt_Addr);
		GSM_Struct.Start_Transmission_command = 1;
		USARTD0_DATA                          = GSM_Struct.Queue_GSM_Command_Buff[Qout_GSM];
	}
	if(transmit_flag == 1)//This flag is set when 0x0A character is found to be transmitting in interrupt this causes a small delay in transmitting the command and transmitting the data to the Server
	{
		transmit_flag						  = 0;
		Qout_GSM                              = Qout_GSM +1;
		GSM_Struct.Start_Transmission_command = 1;
		USARTD0_DATA                          = GSM_Struct.Queue_GSM_Command_Buff[Qout_GSM];
		MWM_COMMAND_STATUS					  = WAIT_FOR_RDMS_FAULT_WARNG_ACK;
	}
	else
	{
		Qout_GSM = 0;
	}	
}

/*
*	Function Name : SnapShot_Broadcast()
*	Function Description : if any fault occurs then snapshot broadcast will send to the server which has 10 records before the 
					  fault occurs and 10 records after the Fault occurs
*	Function parameter : None
*/
void SnapShot_Broadcast(void)
{
	unsigned int uICRC,i;
	unsigned char uICRCH,uICRCL;
	unsigned char End_Txt_Addr;
	unsigned char y,j;
	unsigned char udpDataFrame [140];
	unsigned char tempDataFrame[140];
	uint16_t udp_data_length;
	uint16_t k=0;
	
	udp_data_length = (Parameter_data_length+9);//This +9 includes the current page number and maximum number and Time date stamp
	
	GPS_Data_Collect();//Collecting the GPS informations
	
	if(Transmit_data == 1)//if all the informations are got from the GPS then this bit will set to 1
	{
		Transmit_data = 0;
		tempDataFrame[0]  = 0x80;
		tempDataFrame[1]  = 0x00;
		tempDataFrame[2]  = PROD_ID_NO_3;
		tempDataFrame[3]  = PROD_ID_NO_4;
		tempDataFrame[4]  = CMD;
		tempDataFrame[5]  = CMD_ID;
		tempDataFrame[6]  = LAT_GPS_BYTE0;
		tempDataFrame[7]  = LAT_GPS_BYTE1;
		tempDataFrame[8]  = LAT_GPS_BYTE2;
		tempDataFrame[9]  = LAT_GPS_BYTE3;
		tempDataFrame[10] = LON_GPS_BYTE0;
		tempDataFrame[11] = LON_GPS_BYTE1;
		tempDataFrame[12] = LON_GPS_BYTE2;
		tempDataFrame[13] = LON_GPS_BYTE3;
		tempDataFrame[14] = Speed;
		tempDataFrame[15] = info_code;
		if(Snapshot_Query_Bit==1)//if snapshot query has been raised then the function code of MODE B should be loaded in the buffer
		{
			tempDataFrame[16] = FC_MODE_B_SNAPSHOT_RESPONSE_H;
			tempDataFrame[17] = FC_MODE_B_SNAPSHOT_RESPONSE_L;
		}
		else
		{
			tempDataFrame[16]       = FC_MODE_A_SNAPSHOT_BROADCAST_H;
			tempDataFrame[17]       = FC_MODE_A_SNAPSHOT_BROADCAST_L;
		}
		tempDataFrame[18]=udp_data_length>>8;
		tempDataFrame[19]=udp_data_length;
		tempDataFrame[20]=snapshot_struct.Current_Page_Number>>8;//Current page number and Total no of pages that present for snapshot
		tempDataFrame[21]=snapshot_struct.Current_Page_Number;
		tempDataFrame[22]=snapshot_struct.Total_No_Pages>>8;
		tempDataFrame[23]=snapshot_struct.Total_No_Pages;
		//**************************************************************************************************************************************************************//
		//If snapshot query has been raised by any user
		if(Snapshot_Query_Bit == TRUE)
		{
			if(snapshot_struct.Current_Page_Number == 0)//if the snapshot current page number is equal to zero
			{
				k=24;//Copying the current parameters to the tempdataframe
				for(j=0;j<Total_Parameter_data_length;j++)
				{
					tempDataFrame[k] = Modbus_Struct.Parameters_buff[j];
					k+=1;
				}
			}
			else
			{
				//Reading the snapshot informations that is stored in the flash
				read_snapshot_from_flash(snapshot_struct.Current_Page_Number);
				k=24;
				for(j=0;j<Total_Parameter_data_length;j++)
				{
					tempDataFrame[k] = snapshot_struct.temp_buff[j];
					k+=1;
				}
			}
		}
		//**************************************************************************************************************************************************************//
		else//This condition for broadcast the snapshot
		{
			//if the current page number is less than the total no of pages
			if(snapshot_struct.Current_Page_Number <= (snapshot_struct.Total_No_Pages/2))
			{
				//If the fifo overflow happen in the snapshot buffer ---> first 10 records of snapshot pre data
				if(Modbus_Struct.fifo_overflow_bit == 1)
				{
					k=24;
					for(j=0;j<(Total_Parameter_data_length);j++)
					{
						tempDataFrame[k] = Modbus_Struct.snapshot_buffer[Modbus_Struct.snap_buff_fifo_position];
						Modbus_Struct.snap_buff_fifo_position++;k++;
						if(Modbus_Struct.snap_buff_fifo_position >= Modbus_Struct.Snapshot_total_buffer_size)
						{
							Modbus_Struct.snap_buff_fifo_position = 0;
						}
					}
					store_snapshot_for_query(Total_Parameter_data_length,TRUE);//First 10 records
				}
				else//if there is no overflow happpens on the snapshot buffer
				{
					k=24;
					for(j=0;j<(Parameter_data_length);j++)
					{
						tempDataFrame[k] = Modbus_Struct.snapshot_buffer[Modbus_Struct.snap_buff_fifo_position];
						Modbus_Struct.snap_buff_fifo_position++;k++;
					}
				}
			}
			else//Post records of the snapshot
			{
				k=24;
				for(j=0;j<Total_Parameter_data_length;j++)
				{
					tempDataFrame[k] = Modbus_Struct.Parameters_buff[j];
					k+=1;
				}
				Snapshot_Broadcast_Flag    = 1;
				store_snapshot_for_query(Total_Parameter_data_length,FALSE);//Second 10 records
			}
		}

		tempDataFrame[k]   = Time_Hr;
		tempDataFrame[k+1] = Time_Min;
		tempDataFrame[k+2] = Time_Sec;
		tempDataFrame[k+3] = Date_Byte1;
		tempDataFrame[k+4] = Date_Byte2;
	
		uICRC              = crc(tempDataFrame,(k+5));
		uICRCH             = (uICRC>>8);
		uICRCL             = (uICRC);
		tempDataFrame[k+5] = uICRCH;
		tempDataFrame[k+6] = uICRCL;
		tempDataFrame[k+7] = END;

		udpDataFrame[0]    = START;
		y=1;
		for(i=0;i<(k+8);i++)
		{
			udpDataFrame[y] = tempDataFrame[i];
			y++;
		}
		End_Txt_Addr = (k+9);
	
		////////////******************SENDING THE PACKETS TO UDP***********************///////////////////
		GSM_Send_UART_String_2(GSM_SSENDEXT,'=',"1",(k+9),0x0D,0x0A,udpDataFrame,End_Txt_Addr);
		GSM_Struct.Start_Transmission_command = 1;
		USARTD0_DATA                          = GSM_Struct.Queue_GSM_Command_Buff[Qout_GSM];
 	}
	if(transmit_flag == 1)
	{
		transmit_flag						  = 0;
		Qout_GSM                              = Qout_GSM +1;
		GSM_Struct.Start_Transmission_command = 1;
		USARTD0_DATA                          = GSM_Struct.Queue_GSM_Command_Buff[Qout_GSM];
		MWM_COMMAND_STATUS                    = WAIT_FOR_SNAPSHOT_BROADCAST;
	}
	else
	{
		Qout_GSM = 0;
	}
}

///Mode C configure command response 
void Mode_C_Response(void)
{
	///Local variables declaration
	unsigned int uICRC,i;
	unsigned char uICRCH,uICRCL;
	unsigned char End_Txt_Addr;
	unsigned char y;
	unsigned char udpDataFrame[40];
	unsigned char tempDataFrame[40];
		
	GPS_Data_Collect();//Collecting the GPS informations
		
	if(Transmit_data == 1)//if all the info of GPS got then this bit will enable
	{
		Transmit_data = 0;
		tempDataFrame[0]  = 0x80;
		tempDataFrame[1]  = 0x00;
		tempDataFrame[2]  = PROD_ID_NO_3;
		tempDataFrame[3]  = PROD_ID_NO_4;
		tempDataFrame[4]  = CMD;
		tempDataFrame[5]  = CMD_ID;
		tempDataFrame[6]  = LAT_GPS_BYTE0;
		tempDataFrame[7]  = LAT_GPS_BYTE1;
		tempDataFrame[8]  = LAT_GPS_BYTE2;
		tempDataFrame[9]  = LAT_GPS_BYTE3;
		tempDataFrame[10] = LON_GPS_BYTE0;
		tempDataFrame[11] = LON_GPS_BYTE1;
		tempDataFrame[12] = LON_GPS_BYTE2;
		tempDataFrame[13] = LON_GPS_BYTE3;
		tempDataFrame[14] = Speed;
		tempDataFrame[15] = info_code;
		tempDataFrame[16] = FC_MODE_C_RESPONSE_H;
		tempDataFrame[17] = FC_MODE_C_RESPONSE_L;
		tempDataFrame[18] = DATA_LENGTH_CONFIGURE_RESPONSE_H;
		tempDataFrame[19] = DATA_LENGTH_CONFIGURE_RESPONSE_L;
		tempDataFrame[20] = Time_Hr;
		tempDataFrame[21] = Time_Min;
		tempDataFrame[22] = Time_Sec;
		tempDataFrame[23] = Date_Byte1;
		tempDataFrame[24] = Date_Byte2;
			
		uICRC = crc(tempDataFrame,25);
		uICRCH=(uICRC>>8);
		uICRCL=(uICRC);
		
		tempDataFrame[25]=uICRCH;
		tempDataFrame[26]=uICRCL;
		tempDataFrame[27]=END;
		udpDataFrame[0] = START;
		
		y=1;
		for(i=0;i<28;i++)
		{
			udpDataFrame[y] = tempDataFrame[i];
			y++;
		}
		End_Txt_Addr = 29;
		
		////////////******************SENDING THE PACKETS TO UDP***********************///////////////////
		GSM_Send_UART_String_2(GSM_SSENDEXT,'=',"1",29,0x0D,0x0A,udpDataFrame,End_Txt_Addr);
		GSM_Struct.Start_Transmission_command = 1;
		USARTD0_DATA                          = GSM_Struct.Queue_GSM_Command_Buff[Qout_GSM];
	}
	if(transmit_flag == 1)
	{
		transmit_flag						  = 0;
		Qout_GSM                              = Qout_GSM +1;
		GSM_Struct.Start_Transmission_command = 1;
		USARTD0_DATA                          = GSM_Struct.Queue_GSM_Command_Buff[Qout_GSM];
		MWM_COMMAND_STATUS                    = CHK_MODE_C_RESPONSE_FROM_UDP;
	}
	else
	{
		Qout_GSM = 0;
	}
}

/**********************************************************************************************************************************
Function Description: Function to process the byte values that have received from UDP. In this function the values are directly
stored to the corresponding parameter and these process will happened according to the Control Byte (Read or Write)
ref- Protocol Document
***********************************************************************************************************************************/
void Process_Control_Cmd(void)
{
		
	if(Packets_Received_Flag == 1 || Start_Broadcasting_flag == 1)//if control command all the bytes received in ISR the the Packets received flag will be set 
	{
		Packets_Received_Flag = 0;
		UDP_CRC = crc(ucGSMRxdBuff,(Qin_GSM_Rxd_buff-2));//Calculating the CRC for all the bytes received
		UDP_CRC_HIGH = (UDP_CRC>>8);
		UDP_CRC_LOW = UDP_CRC;

		if(((UDP_CRC_HIGH == ucGSMRxdBuff[Qin_GSM_Rxd_buff-2]) && (UDP_CRC_LOW == ucGSMRxdBuff[Qin_GSM_Rxd_buff-1]))|| Start_Broadcasting_flag == 1 || End_Broadcasting_bit == 1)//if crc is equal
		{
			Qin_GSM_Rxd_buff = 0;
			Qout_GSM         = 0;
			UDP_Retry_count  = 0;
			ucGSMRxdBuffCnt  = 0;
			bGSMRxdFlag      = 0;
			if(Start_Broadcasting_flag == 1 || End_Broadcasting_bit == 1)Analog_Digital_Status = 0x01;///Start broadcasting is enable in the remote diagnosis of RDMS 
			else Analog_Digital_Status = ucGSMRxdBuff[12];
			/*
				1.READ
				2.WRITE
				3.Start broadcasting
				4.Stop broadcasting

			*/						
			switch(Analog_Digital_Status)//Switch case running of Analog_Digital_Status which implies in the remote diagnosis Option
			{
				case 0x01://Read command
				
				ADC0_H = (ADC_Struct.ADC0_Read_Val>>8);
				ADC0_L = ADC_Struct.ADC0_Read_Val;
				
				ADC1_H = (ADC_Struct.ADC1_Read_Val>>8);
				ADC1_L = ADC_Struct.ADC1_Read_Val;
				
				ADC2_H = (ADC_Struct.ADC2_Read_Val>>8);
				ADC2_L = ADC_Struct.ADC2_Read_Val;
				
				ADC3_H = (ADC_Struct.ADC3_Read_Val>>8);
				ADC3_L = ADC_Struct.ADC3_Read_Val;
				
				Control_bytes[0] = Dig_In_Struct.In1_Read_Val;
				Control_bytes[1] = Dig_In_Struct.In2_Read_Val;
				Control_bytes[2] = Dig_In_Struct.In3_Read_Val;
				Control_bytes[3] = Dig_In_Struct.In4_Read_Val;
				
				Control_bytes[4] = Dig_Out_Struct.Out1_Write_Val;
				Control_bytes[5] = Dig_Out_Struct.Out2_Write_Val;
				Control_bytes[6] = Dig_Out_Struct.Out3_Write_Val;
				Control_bytes[7] = Dig_Out_Struct.Out4_Write_Val;
				
				Control_bytes[8]  = ADC0_H;
				Control_bytes[9]  = ADC0_L;
				Control_bytes[10] = ADC1_H;
				Control_bytes[11] = ADC1_L;
								
				Control_bytes[12] = ADC2_H;
				Control_bytes[13] = ADC2_L;
				Control_bytes[14] = ADC3_H;
				Control_bytes[15] = ADC3_L;
				
				Control_bytes[16] = DAC_Struct.DAC0_write_Val>>8;
				Control_bytes[17] = DAC_Struct.DAC0_write_Val;
				Control_bytes[18] = DAC_Struct.DAC1_write_Val>>8;
				Control_bytes[19] = DAC_Struct.DAC1_write_Val;
				
				Control_bytes[20] = 0xFF;
				Control_bytes[21] = 0xFF;
				Control_bytes[22] = 0xFF;
				Control_bytes[23] = 0xFF;
							
				Control_bytes[24] = LICENSE_BYTE_4;
				Control_bytes[25] = LICENSE_BYTE_3;
				Control_bytes[26] = LICENSE_BYTE_2;
				Control_bytes[27] = LICENSE_BYTE_1;
								
				if(Start_Broadcasting_flag == 1 || End_Broadcasting_bit == 1)
				{
					MWM_COMMAND_STATUS = SEND_CONTROL_COMMAND_RESPONSE;
					GPS_Location_Status = AQUIRE_GPS_DATA;
				}
				
				else
				{
					MWM_COMMAND_STATUS = SEND_CONTROL_COMMAND_RESPONSE;
					GPS_Location_Status = AQUIRE_GPS_DATA;
				}
				break;
				
				case 0x02://Write
				///////////////////////////DIGITAL OUTPUT CONFIGURATION/////////////////////////////

				if(ucGSMRxdBuff[17])ENABLE_DOUT_1//if the status of Digital output is One then enabling the 
				else DISABLE_DOUT_1
				if(ucGSMRxdBuff[18])ENABLE_DOUT_2
				else DISABLE_DOUT_2
				if(ucGSMRxdBuff[19])ENABLE_DOUT_3
				else DISABLE_DOUT_3
				if(ucGSMRxdBuff[20])ENABLE_DOUT_4
				else DISABLE_DOUT_4		
				//Storing the Digital outputs values in EEPROM
				ucEEPROM_Array[0] = ucGSMRxdBuff[17];
				ucEEPROM_Array[1] = ucGSMRxdBuff[18];
				ucEEPROM_Array[2] = ucGSMRxdBuff[19];
				ucEEPROM_Array[3] = ucGSMRxdBuff[20];
				uICRC = crc(ucEEPROM_Array,4);
				ucEEPROM_Array[4] = ((uICRC>>8)&0xFF);
				ucEEPROM_Array[5] = (uICRC&0xFF);
				RDMSW_Config_Write_To_EEPROM(ACTUAL_REGISTER_ADDRESS_OF_DIG_OUTPUTS,TOTAL_NO_OF_BYTES_DIG_OUT);//Actual Register 
				RDMSW_Config_Write_To_EEPROM(SHADOW_REGISTER_ADDRESS_OF_DIG_OUTPUTS,TOTAL_NO_OF_BYTES_DIG_OUT);//Shadow Register
				
				///////////////////////////ANALOG OUTPUT CONTROL///////////////////////////////////////			
				
				DAC_1 = ucGSMRxdBuff[29];
				DAC_1 = (DAC_1<<8);
				DAC_1 = ((DAC_1)|(ucGSMRxdBuff[30]));
				
				DAC_2 = ucGSMRxdBuff[31];
				DAC_2 = (DAC_2<<8);
				DAC_2 = ((DAC_2)|(ucGSMRxdBuff[32]));				
				
				DAC_CHANNEL1_DATA(DAC_2);
				
				_delay_ms(100);
				
				collect_data();
				ADC0_H = (ADC_Struct.ADC0_Read_Val>>8);
				ADC0_L = ADC_Struct.ADC0_Read_Val;
				
				ADC1_H = (ADC_Struct.ADC1_Read_Val>>8);
				ADC1_L = ADC_Struct.ADC1_Read_Val;
				
				ADC2_H = (ADC_Struct.ADC2_Read_Val>>8);
				ADC2_L = ADC_Struct.ADC2_Read_Val;
				
				ADC3_H = (ADC_Struct.ADC3_Read_Val>>8);
				ADC3_L = ADC_Struct.ADC3_Read_Val;
				
				Control_bytes[0] = Dig_In_Struct.In1_Read_Val;
				Control_bytes[1] = Dig_In_Struct.In2_Read_Val;
				Control_bytes[2] = Dig_In_Struct.In3_Read_Val;
				Control_bytes[3] = Dig_In_Struct.In4_Read_Val;
				
				Control_bytes[4] = Dig_Out_Struct.Out1_Write_Val;
				Control_bytes[5] = Dig_Out_Struct.Out2_Write_Val;
				Control_bytes[6] = Dig_Out_Struct.Out3_Write_Val;
				Control_bytes[7] = Dig_Out_Struct.Out4_Write_Val;
				
				Control_bytes[8]  = ADC0_H;
				Control_bytes[9]  = ADC0_L;
				Control_bytes[10] = ADC1_H;
				Control_bytes[11] = ADC1_L;
				
				Control_bytes[12] = ADC2_H;
				Control_bytes[13] = ADC2_L;
				Control_bytes[14] = ADC3_H;
				Control_bytes[15] = ADC3_L;
				
				Control_bytes[16] = DAC_Struct.DAC0_write_Val>>8;
				Control_bytes[17] = DAC_Struct.DAC0_write_Val;
				Control_bytes[18] = DAC_Struct.DAC1_write_Val>>8;
				Control_bytes[19] = DAC_Struct.DAC1_write_Val;
				
				Control_bytes[20] = 0xFF;
				Control_bytes[21] = 0xFF;
				Control_bytes[22] = 0xFF;
				Control_bytes[23] = 0xFF;
				;
				Control_bytes[24] = LICENSE_BYTE_4;
				Control_bytes[25] = LICENSE_BYTE_3;
				Control_bytes[26] = LICENSE_BYTE_2;
				Control_bytes[27] = LICENSE_BYTE_1;
				
				MWM_COMMAND_STATUS  = SEND_CONTROL_COMMAND_RESPONSE;
				GPS_Location_Status = AQUIRE_GPS_DATA;
				bGSMRxdFlag1        = 0;
				break;
				
				case 0x03://Start broadcasting 
				Start_Broadcasting_flag = 1;
				if(Modbus_Struct.Device_absent_flag == 1)//if the equipment is not communicated with the MWM after sending the Equipment inactive alarm then force the MWM to do nothing
				{
					MWM_COMMAND_STATUS               = SEND_GSM_SMS_MODE;
				}
				else
				{
					MWM_COMMAND_STATUS     = PUT_RDMS_PARAMETERS_BROADCAST;
					GPS_Location_Status    = AQUIRE_GPS_DATA;
				}
				break;
				
				default:
				MWM_COMMAND_STATUS  = CALCULATE_FOR_PERIODIC_INTERVAL;
				GPS_Location_Status = AQUIRE_GPS_DATA;
				break;
			}
		}
		else
		{
			Qin_GSM_Rxd_buff = 0;
			Qout_GSM         = 0;
			UDP_Retry_count  = 0;
			ucGSMRxdBuffCnt  = 0;
			bGSMRxdFlag1     = 0;
			bGSMRxdFlag      = 0;
		}
	}
}

////Mode D control command response
void Mode_D_Response(void)
{
	unsigned int uICRC,i;
	unsigned char uICRCH,uICRCL;
	unsigned char End_Txt_Addr;
	unsigned char y,j;
	unsigned char tempDataFrame[65];
	unsigned char udpDataFrame[65];
	
	GPS_Data_Collect();//Collecting the GPS informations 
	
	if(Transmit_data == 1)//after all the bytes get from the GPS this flag will be set to 1
	{
		Transmit_data = 0;
		tempDataFrame[0]  = 0x80;
		tempDataFrame[1]  = 0x00;
		tempDataFrame[2]  = PROD_ID_NO_3;
		tempDataFrame[3]  = PROD_ID_NO_4;
		tempDataFrame[4]  = CMD;
		tempDataFrame[5]  = CMD_ID;
		tempDataFrame[6]=LAT_GPS_BYTE0;
		tempDataFrame[7]=LAT_GPS_BYTE1;
		tempDataFrame[8]=LAT_GPS_BYTE2;
		tempDataFrame[9]=LAT_GPS_BYTE3;
		tempDataFrame[10]=LON_GPS_BYTE0;
		tempDataFrame[11]=LON_GPS_BYTE1;
		tempDataFrame[12]=LON_GPS_BYTE2;
		tempDataFrame[13]=LON_GPS_BYTE3;
		tempDataFrame[14]=Speed;
		tempDataFrame[15]=info_code;
		tempDataFrame[16]=FC_MODE_D_RESPONSE_H;
		tempDataFrame[17]=FC_MODE_D_RESPONSE_L;
		tempDataFrame[18]=DATA_LENGTH_CONTROL_CMD_RESPONSE_H;
		tempDataFrame[19]=DATA_LENGTH_CONTROL_CMD_RESPONSE_L;
		
		j=20;
		for(unsigned char k=0;k<28;k++)
		{
			tempDataFrame[j] = Control_bytes[k];
			j++;
		}
		tempDataFrame[48]=Time_Hr;
		tempDataFrame[49]=Time_Min;
		tempDataFrame[50]=Time_Sec;
		tempDataFrame[51]=Date_Byte1;
		tempDataFrame[52]=Date_Byte2;
		
		uICRC = crc(tempDataFrame,53);
		uICRCH=(uICRC>>8);
		uICRCL=(uICRC);
		
		tempDataFrame[53]=uICRCH;
		tempDataFrame[54]=uICRCL;
		tempDataFrame[55]=END;
		
		udpDataFrame[0] = START;
		
		y=1;
		for(i=0;i<56;i++)
		{
			udpDataFrame[y] = tempDataFrame[i];
			y++;
		}
		End_Txt_Addr = 57;

		GSM_Send_UART_String_2(GSM_SSENDEXT,'=',"1",57,0x0D,0x0A,udpDataFrame,End_Txt_Addr);
		GSM_Struct.Start_Transmission_command = 1;
		USARTD0_DATA                   = GSM_Struct.Queue_GSM_Command_Buff[Qout_GSM];
	}
	if(transmit_flag == 1)
	{
		transmit_flag						  = 0;
		Qout_GSM                              = Qout_GSM +1;
		GSM_Struct.Start_Transmission_command = 1;
		USARTD0_DATA                          = GSM_Struct.Queue_GSM_Command_Buff[Qout_GSM];
		MWM_COMMAND_STATUS                    = PROCESS_CONTROL_COMMAND_RESPONSE_FROM_UDP;
	}
	else
	{
		Qout_GSM = 0;
	}
}

void CHK_RDMS_MODE_D_RESPONSE(void)
{
	if(Response_flag == 1 && Packets_Received_Flag == 1)
	{
		Packets_Received_Flag = 0;
		Response_flag         = 0;
		UDP_CRC = crc(ucGSMRxdBuff,(Qin_GSM_Rxd_buff-2));
		UDP_CRC_HIGH = (UDP_CRC>>8);
		UDP_CRC_LOW = UDP_CRC;
		
		if((UDP_CRC_HIGH == ucGSMRxdBuff[Qin_GSM_Rxd_buff-2]) && (UDP_CRC_LOW == ucGSMRxdBuff[Qin_GSM_Rxd_buff-1]))
		{
			if(Start_Broadcasting_flag == 1)
			{
				End_Broadcasting_bit = 0;
				if(Modbus_Struct.Device_absent_flag == 1)//if the equipment is not communicated with the MWM after sending the Equipment inactive alarm then force the MWM to do nothing
				{
					MWM_COMMAND_STATUS	= SEND_GSM_SMS_MODE;
				}
				else
				{
					MWM_COMMAND_STATUS	= PUT_RDMS_PARAMETERS_BROADCAST;
					GPS_Location_Status	= AQUIRE_GPS_DATA;
				}
			}
			else if(End_Broadcasting_bit == 1)
			{
				End_Broadcasting_bit   = 0;
				Start_Broadcasting_flag = 0;
				MWM_COMMAND_STATUS     = CALCULATE_FOR_PERIODIC_INTERVAL;
				GPS_Location_Status    = AQUIRE_GPS_DATA;
				      
			}
			else
			{
				MWM_COMMAND_STATUS  = CALCULATE_FOR_PERIODIC_INTERVAL;
				GPS_Location_Status = AQUIRE_GPS_DATA;
			}

			Qin_GSM_Rxd_buff = 0;
			Qout_GSM         = 0;
			UDP_Retry_count  = 0;
			ucGSMRxdBuffCnt  = 0;
			bGSMRxdFlag1     = 0;
			bGSMRxdFlag      = 0;
			delay_flag	     = 0;
			Tick_count	     = 0;
		}
		else
		{
			UDP_RETRY(SEND_CONTROL_COMMAND_RESPONSE);
		}
	}
	else
	{
		delay_flag = 1;
		if(Tick_count >= TIME_OUT_FOR_UDP_RESPONSE)
		{
			Tick_count = 0;
			delay_flag=0;
			UDP_RETRY(SEND_CONTROL_COMMAND_RESPONSE);
		}
	}
}

/*
	Function Name		 : CHK_RDMS_PING_ACK
	Function description	: If the ping command reaches the server and the server will response to the Module 
	Note ---------> Please refer protocol document for the response for Ping command

*/
void CHK_RDMS_PING_ACK(void)
{
	if(Response_flag == 1 && Packets_Received_Flag == 1)//Once all the response bytes received in the interrupt
	{	
		//GSM_Struct.cloud_true_flag= 1;//This flag is used to set the status Led in the interrupt
		sms.gsm_gprs_ok           = 0;
		Packets_Received_Flag     = 0;
		Response_flag             = 0;
		UDP_CRC                   = crc(ucGSMRxdBuff,(Qin_GSM_Rxd_buff-2));//calaculating the CRC for the response
		UDP_CRC_HIGH              = (UDP_CRC>>8);
		UDP_CRC_LOW               = UDP_CRC;

		if((UDP_CRC_HIGH == ucGSMRxdBuff[Qin_GSM_Rxd_buff-2]) && (UDP_CRC_LOW == ucGSMRxdBuff[Qin_GSM_Rxd_buff-1]))//if the CRC is equal 
		{
			GSM_Struct.cloud_true_flag	= 1;//This flag is used to set the status Led in the interrupt
			MWM_COMMAND_STATUS          = PUT_RDMS_INFO_BROADCAST;// changing the MWM status to broadcast the Info command
			GPS_Location_Status         = AQUIRE_GPS_DATA;//Changing the GPS status to acquire the GPS postion
			Modbus_Struct.cloud_txd_bit = 0;
			Qin_GSM_Rxd_buff            = 0;
			testing_flag		        = 0;
			Qout_GSM                    = 0;
			UDP_Retry_count             = 0;
			ucGSMRxdBuffCnt             = 0;
			bGSMRxdFlag1                = 0;
			bGSMRxdFlag                 = 0;
			delay_flag			        = 0;
			Tick_count			        = 0;
		}
		else
		{
			UDP_RETRY(PUT_RDMS_PING_COMMAND);//retry function to broadcast the ping command of CRC is not equal
		}
	}
	else
	{
		delay_flag = 1;
		if(Tick_count>=TIME_OUT_FOR_UDP_RESPONSE)
		{
			Tick_count = 0;
			delay_flag = 0;
			UDP_RETRY(PUT_RDMS_PING_COMMAND);//retry function for after time out reached 10sec
		}
	}
}

/*
	Function Name		 : CHK_RDMS_INFO_ACK
	Function description	: If the info command reaches the server and the server will response to the Module 
	Note ---------> Please refer protocol document for the response for Info command

*/
void CHK_RDMS_INFO_ACK(void)
{
	if(Response_flag == 1 && Packets_Received_Flag == 1)
	{
		Packets_Received_Flag = 0;
		Response_flag         = 0;
		UDP_CRC               = crc(ucGSMRxdBuff,(Qin_GSM_Rxd_buff-2));
		UDP_CRC_HIGH          = (UDP_CRC>>8);
		UDP_CRC_LOW           = UDP_CRC;
		
		if((UDP_CRC_HIGH == ucGSMRxdBuff[Qin_GSM_Rxd_buff-2]) && (UDP_CRC_LOW == ucGSMRxdBuff[Qin_GSM_Rxd_buff-1]))
		{
			GSM_Struct.cloud_true_flag	= 1;//This flag is used to set the status Led in the interrupt
			if(Info_Query_Bit == 1)// if info query received then the following operation will perform
			{
				Info_Query_Bit              = 0;
				Modbus_Struct.cloud_txd_bit = 0;
				MWM_COMMAND_STATUS          = CALCULATE_FOR_PERIODIC_INTERVAL;
				GPS_Location_Status         = AQUIRE_GPS_DATA;
			}
			else//when the first time the MWM is turning On after the Ping command the Info broadcast will send to server
			{
				if(Modbus_Struct.Device_absent_flag == 1)//if the equipment is not communicated with the MWM after sending the Equipment inactive alarm then force the MWM to do nothing
				{
					MWM_COMMAND_STATUS	= SEND_GSM_SMS_MODE;
				}
				else
				{
					GPS_Location_Status = AQUIRE_GPS_DATA;
					MWM_COMMAND_STATUS  = PUT_RDMS_PARAMETERS_BROADCAST;
				}
			}
			//Resetting all the variables associated with GSM
			Qin_GSM_Rxd_buff      = 0;
			Qout_GSM              = 0;
			UDP_Retry_count       = 0;
			ucGSMRxdBuffCnt       = 0;
			bGSMRxdFlag1          = 0;
			bGSMRxdFlag           = 0;
			delay_flag			  = 0;
			Tick_count			  = 0;
		}
		else
		{
			UDP_RETRY(PUT_RDMS_INFO_BROADCAST);//If CRC does nit matches
		}
	}
	else
	{
		delay_flag = 1;//Time out calculation
		if(Tick_count >= TIME_OUT_FOR_UDP_RESPONSE)
		{
			Tick_count = 0;
			delay_flag = 0;
			UDP_RETRY(PUT_RDMS_INFO_BROADCAST);
		}
	}
}

/*
	Function Name		 : CHK_RDMS_PARAMETER_ACK
	Function description	: If the Parameters broadcast reaches the server and the server will response to the Module 
	Note ---------> Please refer protocol document for the response for Parameter
*/
void CHK_RDMS_PARAMETER_ACK(void)
{
	if(Response_flag == 1 && Packets_Received_Flag == 1)
	{
		Packets_Received_Flag = 0;
		Response_flag         = 0;
		UDP_CRC               = crc(ucGSMRxdBuff,(Qin_GSM_Rxd_buff-2));
		UDP_CRC_HIGH          = (UDP_CRC>>8);
		UDP_CRC_LOW           = UDP_CRC;
		
		if((UDP_CRC_HIGH == ucGSMRxdBuff[Qin_GSM_Rxd_buff-2]) && (UDP_CRC_LOW == ucGSMRxdBuff[Qin_GSM_Rxd_buff-1]))
		{
			GSM_Struct.cloud_true_flag	= 1;//This flag is used to set the status Led in the interrupt
			if(Parameter_Query_Bit == 1)
			{
				Parameter_Query_Bit         = 0;
				Modbus_Struct.cloud_txd_bit = 0;
				MWM_COMMAND_STATUS          = CALCULATE_FOR_PERIODIC_INTERVAL;
				GPS_Location_Status         = AQUIRE_GPS_DATA;
			}
			else if(Start_Broadcasting_flag == 1)//If start broadcasting is enable directly it pass to the Process control command
			{
				GPS_Location_Status   = AQUIRE_GPS_DATA;
				MWM_COMMAND_STATUS    = PROCESS_CONTROL_COMMAND;
			}
			else
			{
				GPS_Location_Status         = AQUIRE_GPS_DATA;
				MWM_COMMAND_STATUS          = CALCULATE_FOR_PERIODIC_INTERVAL;
				Modbus_Struct.cloud_txd_bit = 0;
			}
			
			Qin_GSM_Rxd_buff      = 0;
			Qout_GSM              = 0;
			UDP_Retry_count       = 0;
			ucGSMRxdBuffCnt       = 0;
			bGSMRxdFlag1          = 0;
			bGSMRxdFlag           = 0;
			delay_flag			  = 0;
			Tick_count			  = 0;
		}
		else
		{
			UDP_RETRY(PUT_RDMS_PARAMETERS_BROADCAST);
		}
	}
	else
	{
		delay_flag = 1;
		if(Tick_count >= TIME_OUT_FOR_UDP_RESPONSE)
		{
			Tick_count = 0;
			delay_flag = 0;
			UDP_RETRY(PUT_RDMS_PARAMETERS_BROADCAST);
		}
	}
}

/*
	Function Name		 : CHK_RDMS_FAULT_WARNING_ACK
	Function description	: If the fault warning broadcast reaches the server and the server will response to the Module 
	Note ---------> Please refer protocol document for the response for Ping command
*/
void CHK_RDMS_FAULT_WARNING_ACK(void)
{
	if(Response_flag == 1 && Packets_Received_Flag == 1)
	{
		Packets_Received_Flag = 0;
		Response_flag         = 0;
		UDP_CRC               = crc(ucGSMRxdBuff,(Qin_GSM_Rxd_buff-2));
		UDP_CRC_HIGH          = (UDP_CRC>>8);
		UDP_CRC_LOW           = UDP_CRC;
		
		if((UDP_CRC_HIGH == ucGSMRxdBuff[Qin_GSM_Rxd_buff-2]) && (UDP_CRC_LOW == ucGSMRxdBuff[Qin_GSM_Rxd_buff-1]))
		{
			GSM_Struct.cloud_true_flag	= 1;//This flag is used to set the status Led in the interrupt
			if(Fault_Warning_Query_Bit == 1)//Fault and query is received then after sending the fault and warning bytes changing the status to calculate the periodic interval 
			{
				Fault_Warning_Query_Bit     = 0;
				Fault_Warning_present_flag  = 0;
				MWM_COMMAND_STATUS          = CALCULATE_FOR_PERIODIC_INTERVAL;
				GPS_Location_Status         = AQUIRE_GPS_DATA;
			}
			else
			{
				if(Fault_Warning_present_flag == 1)//if the fault and warning present in the system
				{
					if(testing_flag == 1)//this flag is initialized as 1 in main this checking is because of if any fault and warnings are present in the equipment at the power ON state
					{
						testing_flag				= 0;
						Fault_Warning_present_flag	= 0;
						GSM_Struct.cloud_true_flag  = 1;
						sms.gsm_gprs_ok             = 0;
						GPS_Location_Status         = AQUIRE_GPS_DATA;
						MWM_COMMAND_STATUS          = PUT_RDMS_INFO_BROADCAST;
					}

					else//otherwise send the snapshot after that
					{
						Fault_Warning_present_flag							 = 0;
						Snap_Shot_Present_Flag								 = TRUE;
						MWM_COMMAND_STATUS                                   = PUT_RDMS_SNAPSHOT_BROADCAST;
						GPS_Location_Status                                  = AQUIRE_GPS_DATA;
						if(Modbus_Struct.fifo_overflow_bit)store_snapshot_for_query(Total_Parameter_data_length,TRUE);
					}
				}
			}
			if(Modbus_Struct.Device_absent_flag == 1)//if the equipment is not communicated with the MWM after sending the Equipment inactive alarm then force the MWM to do nothing
			{
				MWM_COMMAND_STATUS               = SEND_GSM_SMS_MODE;
			}
			Modbus_Struct.cloud_txd_bit = 0;
			Qin_GSM_Rxd_buff            = 0;
			Qout_GSM                    = 0;
			UDP_Retry_count             = 0;
			ucGSMRxdBuffCnt             = 0;
			bGSMRxdFlag1                = 0;
			bGSMRxdFlag                 = 0;
			delay_flag			        = 0;
			Tick_count			        = 0;
		}
		else
		{
			UDP_RETRY(PUT_RDMS_FAULT_WARNG_BROADCAST);
		}
	}
	else
	{
		delay_flag = 1;//Time out operation
		if(Tick_count >= TIME_OUT_FOR_UDP_RESPONSE)
		{
			Tick_count = 0;
			delay_flag = 0;
			UDP_RETRY(PUT_RDMS_FAULT_WARNG_BROADCAST);
		}
	}
}

void CHK_RDMS_SNAPSHOT_ACK(void)
{
	if(Response_flag == 1 && Packets_Received_Flag == 1 && Snap_Shot_Present_Flag == 1)
	{
		Packets_Received_Flag = 0;
		UDP_CRC               = crc(ucGSMRxdBuff,(Qin_GSM_Rxd_buff-2));
		UDP_CRC_HIGH          = (UDP_CRC>>8);
		UDP_CRC_LOW           = UDP_CRC;
		
		if((UDP_CRC_HIGH == ucGSMRxdBuff[Qin_GSM_Rxd_buff-2]) && (UDP_CRC_LOW == ucGSMRxdBuff[Qin_GSM_Rxd_buff-1]))
		{
			GSM_Struct.cloud_true_flag	= 1;//This flag is used to set the status Led in the interrupt
			if(Snapshot_Query_Bit == 1)
			{
				if(snapshot_struct.Current_Page_Number != snapshot_struct.Total_No_Pages)
				{
					snapshot_struct.Current_Page_Number++;
					MWM_COMMAND_STATUS         = PUT_RDMS_SNAPSHOT_BROADCAST;
					GPS_Location_Status        = AQUIRE_GPS_DATA;
					Snapshot_Broadcast_Flag    = 1;
					Fault_Warning_present_flag = 0;
				}
				else
				{
					snapshot_struct.Current_Page_Number	= 0;
					Snap_Shot_Present_Flag  = 0;
					snapshot_struct.Total_No_Pages      = Config_struct.No_of_Pre_Data+Config_struct.No_of_Post_Data;
					
					if(GSM_OK_flag == 1 && send_cycle_day_summary == 1 && Snap_Shot_Present_Flag == FALSE) // 17/03/2015 After checking that again got pbm in Cycle Summery
					{
						send_cycle_day_summary = 0;
						GPS_Location_Status         = AQUIRE_GPS_DATA;
						MWM_COMMAND_STATUS          = PUT_RDMS_DAY_SUMMARY_BROADCAST;
						Modbus_Struct.cloud_txd_bit	= 1;
					}
					
					Snapshot_Query_Bit                  = FALSE;
					Modbus_Struct.cloud_txd_bit			= FALSE;
					MWM_COMMAND_STATUS                  = CALCULATE_FOR_PERIODIC_INTERVAL;
					GPS_Location_Status                 = AQUIRE_GPS_DATA;
				}
			}
			else
			{
				if(Modbus_Struct.fifo_overflow_bit == 1)
				{
					if(snapshot_struct.Current_Page_Number != snapshot_struct.Total_No_Pages)
					{
						snapshot_struct.Current_Page_Number++;
						MWM_COMMAND_STATUS             = PUT_RDMS_SNAPSHOT_BROADCAST;
						GPS_Location_Status            = AQUIRE_GPS_DATA;
						snapshot_struct.Total_No_Pages = 20;
						Fault_Warning_present_flag     = 0;
					}
					else
					{
						snapshot_struct.Current_Page_Number = 0;
						snapshot_struct.Total_No_Pages      = Config_struct.No_of_Pre_Data+Config_struct.No_of_Post_Data;
						Snap_Shot_Present_Flag  = 0;
						
						snapshot_struct.record_buffer_pos_1 = 0;
						snapshot_struct.record_buffer_pos	= 0;
						
						if(GSM_OK_flag == 1 && send_cycle_day_summary == 1 && Snap_Shot_Present_Flag == FALSE) // 17/03/2015 After checking that again got pbm in Cycle Summery
						{
							send_cycle_day_summary = 0;
							GPS_Location_Status         = AQUIRE_GPS_DATA;
							MWM_COMMAND_STATUS          = PUT_RDMS_DAY_SUMMARY_BROADCAST;
							Modbus_Struct.cloud_txd_bit	= 1;
						}
						
						Snapshot_Query_Bit                  = 0;
						Snapshot_Broadcast_Flag             = 0;
						MWM_COMMAND_STATUS                  = CALCULATE_FOR_PERIODIC_INTERVAL;
						GPS_Location_Status                 = AQUIRE_GPS_DATA;
					}
				}
				else
				{
					if(snapshot_struct.Current_Page_Number != (Modbus_Struct.temp_fifo_position/Total_Parameter_data_length))
					{
						snapshot_struct.Current_Page_Number++;
						snapshot_struct.Total_No_Pages = (Modbus_Struct.temp_fifo_position/Total_Parameter_data_length);
						MWM_COMMAND_STATUS             = PUT_RDMS_SNAPSHOT_BROADCAST;
						GPS_Location_Status            = AQUIRE_GPS_DATA;
						Fault_Warning_present_flag     = 0;
					}
					else
					{
						snapshot_struct.Current_Page_Number = 0;
						Snap_Shot_Present_Flag  = 0;
						snapshot_struct.Total_No_Pages      = Config_struct.No_of_Pre_Data+Config_struct.No_of_Post_Data;
												
						if(GSM_OK_flag == 1 && send_cycle_day_summary == 1 && Snap_Shot_Present_Flag == FALSE) // 17/03/2015 After checking that again got pbm in Cycle Summery
						{
							send_cycle_day_summary = 0;
							GPS_Location_Status         = AQUIRE_GPS_DATA;
							MWM_COMMAND_STATUS          = PUT_RDMS_DAY_SUMMARY_BROADCAST;
							Modbus_Struct.cloud_txd_bit	= 1;
						}
						
						Snapshot_Query_Bit                  = 0;
						Snapshot_Broadcast_Flag             = 0;
						MWM_COMMAND_STATUS                  = CALCULATE_FOR_PERIODIC_INTERVAL;
						GPS_Location_Status                 = AQUIRE_GPS_DATA;
					}
				}
			}
			
			Qin_GSM_Rxd_buff        = 0;
			Qout_GSM                = 0;
			Packets_Received_Flag   = 0;
			UDP_Retry_count         = 0;
			ucGSMRxdBuffCnt         = 0;
			bGSMRxdFlag1            = 0;
			bGSMRxdFlag             = 0;
			delay_flag			    = 0;
			Tick_count			    = 0;
		}
		else
		{
			UDP_RETRY(PUT_RDMS_SNAPSHOT_BROADCAST);
		}
	}
	else
	{
		delay_flag = 1;
		if(Tick_count >= TIME_OUT_FOR_UDP_RESPONSE)
		{
			Tick_count = 0;
			delay_flag = 0;
			UDP_RETRY(PUT_RDMS_SNAPSHOT_BROADCAST);
		}
	}
}

uint64_t Change_Hours_Mins_Seconds_in_Milli_Seconds(uint8_t Hour,uint8_t Min, uint8_t Sec)
{
	uint16_t Hour_to_Seconds,Min_to_Seconds;
	uint64_t Total_MilliSeconds;
	
	Hour_to_Seconds = ((Hour*60)*60);
	Min_to_Seconds  = (Min*60);
	Total_MilliSeconds = ((Hour_to_Seconds+Min_to_Seconds+Sec)*100);
	
	return Total_MilliSeconds;
}

uint64_t Calculate_Day_Summary_Interval(uint8_t No_of_Summaries_Hi, uint8_t No_of_Summaries_Lo)
{
	uint16_t No_of_Summaries_In_a_day;
	uint64_t value_of_time_to_get_day_summary;
	
	No_of_Summaries_In_a_day = Char_To_Integer(No_of_Summaries_Hi,No_of_Summaries_Lo);
	value_of_time_to_get_day_summary = (86400000 / No_of_Summaries_In_a_day);
	
	return value_of_time_to_get_day_summary;
	
}

void Configuration_from_UDP_write_to_EEPROM(void)
{
	unsigned int uiCRCValue;
	
	/////////////////////////////Change the Product ID in the EEPROM as per the configure received from the configure command////////////////////////////////////////////
	ucEEPROM_Array[0] =  PROD_ID_NO_1;//ucGSMRxdBuff[12];
	ucEEPROM_Array[1] =  PROD_ID_NO_2;//ucGSMRxdBuff[13];
	ucEEPROM_Array[2] =  PROD_ID_NO_3;//ucGSMRxdBuff[14];
	ucEEPROM_Array[3] =  PROD_ID_NO_4;//ucGSMRxdBuff[15];// Product ID storing in EEPROM
		
	/////////////////////////////Change the Serial NO in the EEPROM as per the configure received from the configure command////////////////////////////////////////////////
	ucEEPROM_Array[4]    = ucGSMRxdBuff[16];
	ucEEPROM_Array[5]    = ucGSMRxdBuff[17];//Serial Number of the Unit
	Modbus_Struct.serial_no = Char_To_Integer(ucGSMRxdBuff[16],ucGSMRxdBuff[17]);

	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	ucEEPROM_Array[6]   = ucGSMRxdBuff[18];
	ucEEPROM_Array[7]   = ucGSMRxdBuff[19];//Panel version

	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	ucEEPROM_Array[8]   = ucGSMRxdBuff[20];
	ucEEPROM_Array[9] = ucGSMRxdBuff[21];//Panel Capability
	Modbus_Struct.panel_capab = Char_To_Integer(ucGSMRxdBuff[20],ucGSMRxdBuff[21]);

	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	ucEEPROM_Array[10]		= ucGSMRxdBuff[22];//Month of Manufacturing
	Modbus_Struct.month = ucGSMRxdBuff[22];

	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	ucEEPROM_Array[11]		= ucGSMRxdBuff[23];//Year of Manufacturing
	Modbus_Struct.year = ucGSMRxdBuff[23];
		
	/*----------------------------- Made by Padmanathan-----------------------------------------
	---------------------------------Hour Meter Reset-----------------------------------------------*/
	if(sms.Engine_HMR_Proc_Flag == 1) // Configuration from mobile SMS this loop executes
	{
		sms.Engine_HMR_Proc_Flag = 0;
		Engine_Hours_byte1              = engine_hrs >> 8;//ucModRxDataBufferArr[35];
		ucEEPROM_Array[12] = Engine_Hours_byte1;
		Engine_Hours_byte2              = engine_hrs;//ucModRxDataBufferArr[36];
		ucEEPROM_Array[13] = Engine_Hours_byte2; // Run hours
		Engine_Hours_byte3              = 0;//ucModRxDataBufferArr[37];
		ucEEPROM_Array[14] = Engine_Hours_byte3;
		Engine_Hours_byte4              = engine_min;//ucModRxDataBufferArr[38];
		ucEEPROM_Array[15] = Engine_Hours_byte4;//Engine Run Mins
		sms.HMR_Reset_Flag = 1;
	}
		
	else// Configuration from the RDMS this loop executes
	{
		Engine_Hours_byte1              = ucGSMRxdBuff[36];
		ucEEPROM_Array[12] = Engine_Hours_byte1;
		Engine_Hours_byte2              = ucGSMRxdBuff[37];
		ucEEPROM_Array[13] = Engine_Hours_byte2;
		Engine_Hours_byte3              = ucGSMRxdBuff[38];
		ucEEPROM_Array[14] = Engine_Hours_byte3;
		Engine_Hours_byte4              = ucGSMRxdBuff[39];
		ucEEPROM_Array[15] = Engine_Hours_byte4;//Engine Hours
	}		
				
	Hardware_version_byte1          = ucGSMRxdBuff[40];
	ucEEPROM_Array[16] = Hardware_version_byte1;
	Hardware_version_byte2          = ucGSMRxdBuff[41];
	ucEEPROM_Array[17] = Hardware_version_byte2;
	Hardware_version_byte3          = ucGSMRxdBuff[42];
	ucEEPROM_Array[18] = Hardware_version_byte3;
	Hardware_version_byte4          = ucGSMRxdBuff[43];
	ucEEPROM_Array[19] = Hardware_version_byte4;//Hardware version
		
	Software_version_byte1          = ucGSMRxdBuff[44];
	ucEEPROM_Array[20] = Software_version_byte1;
	Software_version_byte2          = ucGSMRxdBuff[45];
	ucEEPROM_Array[21] = Software_version_byte2;
	Software_version_byte3          = ucGSMRxdBuff[46];
	ucEEPROM_Array[22] = Software_version_byte3;
	Software_version_byte4          = ucGSMRxdBuff[47];
	ucEEPROM_Array[23] = Software_version_byte4;//Software Version
		
		
	Config_struct.Parameter_Sending_time_interval = ((ucGSMRxdBuff[25] * 60)+ucGSMRxdBuff[26]);//Storing the parameters sending periodical interval time
		
	ucEEPROM_Array[24] = ((Config_struct.Parameter_Sending_time_interval>>8)&0xFF);
	ucEEPROM_Array[25] = Config_struct.Parameter_Sending_time_interval;

	uiCRCValue = crc(ucEEPROM_Array,26);
	ucEEPROM_Array[26] = (uiCRCValue>>8);
	ucEEPROM_Array[27] = (uiCRCValue);
	RDMSW_Config_Write_To_EEPROM(EEPROM_CONFIG_ACTUAL_REG_ADDR,CONFIG_TOTAL_NO_OF_BYTES);
	RDMSW_Config_Write_To_EEPROM(EEPROM_CONFIG_SHADOW_REG_ADDR,CONFIG_TOTAL_NO_OF_BYTES);
		
	//#ifdef CONFIG_ENABLE
		
	//              = Change_Hours_Mins_Seconds_in_Milli_Seconds(ucGSMRxdBuff[24],ucGSMRxdBuff[25],ucGSMRxdBuff[26]);
				
	//Config_struct.Day_Summary_Sending_time_interval            = Calculate_Day_Summary_Interval(ucGSMRxdBuff[30],ucGSMRxdBuff[31]);
				
	//Config_struct.No_of_Pre_Data					           = ucGSMRxdBuff[32];
				
	//Config_struct.No_of_Post_Data					           = ucGSMRxdBuff[33];
				
	//Config_struct.Equipment_Parameter_Collecting_Time_interval = Change_Hours_Mins_Seconds_in_Milli_Seconds(0,ucGSMRxdBuff[34],ucGSMRxdBuff[35]);
		
	//Total_No_Pages											   = (Config_struct.No_of_Pre_Data + Config_struct.No_of_Post_Data);
		
	//#endif
}

//Checking the cycle summary and day summary acknowledge from the server
void CHK_RDMS_DAYSUMMARY_ACK(void)
{
	if(Response_flag == 1 && Packets_Received_Flag == 1)//Checking if all the bytes received and response flag is set
	{
		Packets_Received_Flag = 0;
		Response_flag         = 0;
		UDP_CRC               = crc(ucGSMRxdBuff,(Qin_GSM_Rxd_buff-2));//calculating CRC for the received response
		UDP_CRC_HIGH          = (UDP_CRC>>8);
		UDP_CRC_LOW           = UDP_CRC;
		
		if((UDP_CRC_HIGH == ucGSMRxdBuff[Qin_GSM_Rxd_buff-2]) && (UDP_CRC_LOW == ucGSMRxdBuff[Qin_GSM_Rxd_buff-1]))//checking the CRC
		{
			GSM_Struct.cloud_true_flag	= 1;//This flag is used to set the status Led in the interrupt
			if(Cycle_Summary_Query_Bit == 1)//if the cycle summary query is received then the status should be transfer to calculating the periodic interval
			{
				Cycle_Summary_Query_Bit     = 0;
				MWM_COMMAND_STATUS          = CALCULATE_FOR_PERIODIC_INTERVAL;
				GPS_Location_Status         = AQUIRE_GPS_DATA;
			}
			else if(Day_Summary_Interval_flag == 1)//If the day summary interval has been reached also the status should be transfer to 
			{
				Day_Summary_Interval_flag = 0;
				MWM_COMMAND_STATUS        = CALCULATE_FOR_PERIODIC_INTERVAL;
				GPS_Location_Status       = AQUIRE_GPS_DATA;
			}
			else//if cycle summary broadcasting happens then the MWM should go for calculate periodic interval
			{
				GPS_Location_Status     = AQUIRE_GPS_DATA;
				MWM_COMMAND_STATUS      = CALCULATE_FOR_PERIODIC_INTERVAL;
			}
			//Resetting all the variables associated with the GSM communication			
			Modbus_Struct.cloud_txd_bit = 0;
			Qin_GSM_Rxd_buff            = 0;
			Qout_GSM                    = 0;
			UDP_Retry_count             = 0;
			ucGSMRxdBuffCnt             = 0;
			bGSMRxdFlag1                = 0;
			bGSMRxdFlag                 = 0;
			delay_flag			        = 0;
			Tick_count			        = 0;			
		}
		else
		{
			UDP_RETRY(PUT_RDMS_DAY_SUMMARY_BROADCAST);//Retrying the same command
		}
	}	
	else
	{
		delay_flag = 1;//Calculating the time out for 
		if(Tick_count >= TIME_OUT_FOR_UDP_RESPONSE)
		{
			Tick_count = 0;
			delay_flag = 0;
			UDP_RETRY(PUT_RDMS_DAY_SUMMARY_BROADCAST);//after timeout reaches retrying the same command
		}
	}	
}

///Function to processing the configure command 
//The configure command will have the set of configurations which is for the equipment as well as for MWM too

void Process_Configure_Cmd(void)
{
	if(Configure_Query_Bit == 1 && Packets_Received_Flag == 1)
	{
		UDP_CRC               = crc(ucGSMRxdBuff,(Qin_GSM_Rxd_buff-2));//Checking the CRC
		UDP_CRC_HIGH          = (UDP_CRC>>8);
		UDP_CRC_LOW           = UDP_CRC;
		if((UDP_CRC_HIGH == ucGSMRxdBuff[Qin_GSM_Rxd_buff-2]) && (UDP_CRC_LOW == ucGSMRxdBuff[Qin_GSM_Rxd_buff-1]))
		{
			GSM_Struct.cloud_true_flag	= 1;//This flag is used to set the status Led in the interrupt
			Configuration_from_UDP_write_to_EEPROM();//Writing  the configurations to EEPROM
			ucModCommandStatus    = SEND_CONFIG_INFO_TO_EQUIPMENT;//setting this status will send the configuration bytes that is received from the server to the Equipment 
			MWM_COMMAND_STATUS    = MODE_C_RESPONSE;//Will give the configuration mode C response ---> refer protocol document
			GPS_Location_Status   = AQUIRE_GPS_DATA;
			Packets_Received_Flag = 0;
			Qin_GSM_Rxd_buff      = 0;
			Qout_GSM              = 0;
			UDP_Retry_count       = 0;
			ucGSMRxdBuffCnt       = 0;
			bGSMRxdFlag1          = 0;
			bGSMRxdFlag           = 0;
		}
		else
		{
			MWM_COMMAND_STATUS    = CALCULATE_FOR_PERIODIC_INTERVAL;//if the CRC does not matches then it will switch to calculate the periodic interval
			Packets_Received_Flag = 0;//resetting all the variables
			Qin_GSM_Rxd_buff      = 0;
			Qout_GSM              = 0;
			UDP_Retry_count       = 0;
			ucGSMRxdBuffCnt       = 0;
			bGSMRxdFlag1          = 0;
			bGSMRxdFlag           = 0;
		}
	}
}

//Checking Mode C response 
void CHK_RDMS_MODE_C_RESPONSE(void)
{
	if(Response_flag == 1 && Packets_Received_Flag == 1)//If response flag is set and all the packets received in the interrupt
	{
		Packets_Received_Flag = 0;
		Response_flag         = 0;
		UDP_CRC               = crc(ucGSMRxdBuff,(Qin_GSM_Rxd_buff-2));//Calaculating the CRC
		UDP_CRC_HIGH          = (UDP_CRC>>8);
		UDP_CRC_LOW           = UDP_CRC;
		
		if((UDP_CRC_HIGH == ucGSMRxdBuff[Qin_GSM_Rxd_buff-2]) && (UDP_CRC_LOW == ucGSMRxdBuff[Qin_GSM_Rxd_buff-1]))//Checking the CRC
		{
			GSM_Struct.cloud_true_flag	= 1;//This flag is used to set the status Led in the interrupt
			MWM_COMMAND_STATUS          = CALCULATE_FOR_PERIODIC_INTERVAL;//Changing the MWM status to periodic INterval calaculation
			GPS_Location_Status         = AQUIRE_GPS_DATA;
			Configure_Query_Bit         = 0;//Resetting all the variables associated with the communnication
			Modbus_Struct.cloud_txd_bit = 0;
			Qin_GSM_Rxd_buff            = 0;
			Qout_GSM                    = 0;
			UDP_Retry_count             = 0;
			ucGSMRxdBuffCnt             = 0;
			bGSMRxdFlag1                = 0;
			bGSMRxdFlag                 = 0;
		}
		else
		{
			UDP_RETRY(MODE_C_RESPONSE);//Retry the Mode C response if the CRC is wrong 
		}
	}
	else
	{
		delay_flag = 1;//Time out for getting the response
		if(Tick_count >= TIME_OUT_FOR_UDP_RESPONSE)//checking the counter attained the timeout resposne
		{
			Tick_count = 0;
			delay_flag = 0;
			UDP_RETRY(MODE_C_RESPONSE);//If no response received although the time out reached then retry the same command
		}
	}
}

//Periodical interval function
//In this function only the MWM will broadcast the periodical interval broadcasting like Parameters for 5 mins once etc.,
void periodical_interval_function(void)
{
	if(Start_Broadcasting_flag == 1)//If start broadcasting bit is set in the Remote diagnosis screen of RDMS then change the parameters broadcast
	{//Reason for checking the Bit in this area ----> if broadcasting is activaed through Remote diagnosis screen of RDMS intermediate a query is raised and after responding the query the MWM t will automatically continue the broadcasting
		if(Modbus_Struct.Device_absent_flag == 1)//if the equipment is not communicated with the MWM after sending the Equipment inactive alarm then force the MWM to do nothing
		{
			MWM_COMMAND_STATUS		= SEND_GSM_SMS_MODE;
		}
		else
		{
			MWM_COMMAND_STATUS		= PUT_RDMS_PARAMETERS_BROADCAST;
			GPS_Location_Status		= AQUIRE_GPS_DATA;
		}
	}
	else
	{
		Periodic_interval_Delay_flag = TRUE;//If this bit set to true then the MWM will calculate the periodical interval by incrementing the tick count in the clock tick interrupt 	
		if(Parameter_tick_count >= (Config_struct.Parameter_Sending_time_interval*100))//After reaching the time interval 
		{
			GSM_Struct.cloud_true_flag	= 1;//This flag is used to set the status Led in the interrupt
			Periodic_interval_Delay_flag = 0;//Making the counter and the starting bit will become zero 
			Parameter_tick_count         = 0;
			Modbus_Struct.cloud_txd_bit  = 1;
			if(Modbus_Struct.Device_absent_flag == 1)//if the equipment is not communicated with the MWM after sending the Equipment inactive alarm then force the MWM to do nothing
			{
				MWM_COMMAND_STATUS		= SEND_GSM_SMS_MODE;
			}
			else
			{
				MWM_COMMAND_STATUS		= PUT_RDMS_PARAMETERS_BROADCAST;//changing the MWM status to do the parameters broadcast
				GPS_Location_Status		= AQUIRE_GPS_DATA;
			}
			DataLogg_Struct.No_of_Records_Parameter++;
			DataLogg_Struct.Total_Stored_Bytes_in_a_Page = (NO_OF_BYTES_AT_FRONT_OF_PARAMETERS+Total_Parameter_data_length+NO_OF_BYTES_AT_BACK_OF_PARAMETERS);//Counting the No of parameters bytes of the parameters command
			Store_Parameters_to_Flash_memory();//Storing the parameters to flash memory after sending the broadcast to the server
		}
		day_summary_timr_flag = TRUE;//Day summary timer flag which will activate to increment the counter in the clock tick interrupt
		if(Day_Summary_Tick_Count >= MAX_DAY_SUMMARY_TIME_INTERVAL_IN_MINS)//if the counter reaches the day summary interval
		{
			Day_Summary_Tick_Count       = 0;//Making the counter and the starting bit will become zero 
			day_summary_timr_flag		 = 0;
			Day_Summary_Interval_flag    = 1;
			Modbus_Struct.cloud_txd_bit	 = 1;
			MWM_COMMAND_STATUS           = PUT_RDMS_DAY_SUMMARY_BROADCAST;//changing the MWM status to put the Day summary broadcast to the server
			GPS_Location_Status          = AQUIRE_GPS_DATA;
			day_summary_calculation(DataLogg_Struct.cycle_summary_total_data_length,DataLogg_Struct.No_of_Records_Cycle_Summary);//After performing the day summary calculation 
		}
	}
}

#endif
