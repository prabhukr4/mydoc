/*
-----------------------------------------
			VT100 Setup
-----------------------------------------
DATA				ROW			COLUMN
-----------------------------------------
Heading				1			10
ADC COUNT - 		2			1
ADC DATA			2			13
UNIT				2			16
-----------------------------------------
*/


#define true 1
#define false 0

void uart_init(void);
void uart1_out(unsigned char);
void uart1_con_out(unsigned char *);
void delay_sec(unsigned int);
void u1htd2(unsigned int);
void u1htd3(unsigned int);
void u1htd4(unsigned int);


bool usart_set_baudrate(USART_t *usart, uint32_t baud, uint32_t cpu_hz);

void uart_init(void)
{
	/////////// MCU UART   ///////////////////////////////////////////////////////////////
	PORTD_DIR			|= 0x80;					// TXD0-PD7 as output, RXD-PD6 as input
	PORTD_OUTSET		 = 0x80;					// TXD0-PD3 IS Must be HIGH while initially
	
	USARTD1_STATUS		= 0x80;					// Flags are zero
	USARTD1_CTRLA		= 0x3C;					// High Priority for Interrupts
	USARTD1_CTRLB		= 0x18;					// Set the Transmitter Enable and Receiver Enable(if only transmitter put 0x08)
	USARTD1_CTRLC		= 0x03;					// Asynchronous Mode, NO Parity, 1 stop bit and 8 bit data
	//USARTD1_BAUDCTRLA	= 0x19;					// BSEL value is 25, by 9600 baud rate for 4MHZ frequency with considered BSCALE as 0.
	//USARTD1_BAUDCTRLB	= 0x00;					// BSCALE is 0 and BSEL upper bits 0.
	usart_set_baudrate(&USARTD1,9600, 4000000);	// Setting the baud rate to high level 9600
	
}
void uart1_out(unsigned char data_tx)
{
	USARTD1_DATA = data_tx;						// Put data to DATA register
	while(!((USARTD1_STATUS & 0x20)==0x20));	// Check the bit whether the data is sent or not
}
void uart1_con_out(unsigned char *data_con_tx)
{
	while(*data_con_tx)
	{
		uart1_out(*data_con_tx++);
	}
}

void u1htd2(unsigned int hexdata2)			// 57
{
	unsigned int b_data,c_data;
	b_data = hexdata2/10;					// b_data  = 57/10 = 5
	hexdata2 = hexdata2%10;					// hexdata = 57%10 = 7
	c_data = hexdata2;						// c_data  = 5
	uart1_out(b_data + '0');
	uart1_out(c_data + '0');	
}
void u1htd3(unsigned int hexdata3)			// 125
{
	unsigned int a_data,b_data,c_data;
	a_data = hexdata3/100;					// a_data  = 125/100 = 1
	hexdata3 = hexdata3%100;				// hexdata = 125%100 = 25
	b_data = hexdata3/10;					// b_data  = 25/10 = 2
	hexdata3 = hexdata3%10;					// hexdata = 25%10 = 5	
	c_data = hexdata3;						// c_data  = 5
	uart1_out(a_data + '0');
	uart1_out(b_data + '0');
	uart1_out(c_data + '0');
}
void u1htd4(unsigned int hexdata4)			// 1257
{
	unsigned int a_data,b_data,c_data,d_data;
	d_data	 = hexdata4/1000;				// d_data  = 1257/1000 = 1
	hexdata4 = hexdata4%1000;				// d_data  = 1257%1000 = 257
	a_data = hexdata4/100;					// a_data  = 257/100 = 2
	hexdata4 = hexdata4%100;				// hexdata = 257%100 = 57
	b_data = hexdata4/10;					// b_data  = 57/10 = 5
	hexdata4 = hexdata4%10;					// hexdata = 57%10 = 7
	c_data = hexdata4;						// c_data  = 5
	uart1_out(d_data + '0');
	uart1_out(a_data + '0');
	uart1_out(b_data + '0');
	uart1_out(c_data + '0');
}

bool usart_set_baudrate(USART_t *usart, uint32_t baud, uint32_t cpu_hz)
{
	int8_t exp;
	uint32_t div;
	uint32_t limit;
	uint32_t ratio;
	uint32_t min_rate;
	uint32_t max_rate;
	baud = baud*2;
	/*
	 * Check if the hardware supports the given baud rate
	 */
	/* 8 = (2^0) * 8 * (2^0) = (2^BSCALE_MIN) * 8 * (BSEL_MIN) */
	max_rate = cpu_hz / 8;
	/* 4194304 = (2^7) * 8 * (2^12) = (2^BSCALE_MAX) * 8 * (BSEL_MAX+1) */
	min_rate = cpu_hz / 4194304;

	if (!((usart)->CTRLB & USART_CLK2X_bm)) {
		max_rate /= 2;
		min_rate /= 2;
	}

	if ((baud > max_rate) || (baud < min_rate)) {
		return false;
	}

	/* Check if double speed is enabled. */
	if (!((usart)->CTRLB & USART_CLK2X_bm)) {
		baud *= 2;
	}

	/* Find the lowest possible exponent. */
	limit = 0xfffU >> 4;
	ratio = cpu_hz / baud;

	for (exp = -7; exp < 7; exp++) {
		if (ratio < limit) {
			break;
		}

		limit <<= 1;

		if (exp < -3) {
			limit |= 1;
		}
	}

	/*
	 * Depending on the value of exp, scale either the input frequency or
	 * the target baud rate. By always scaling upwards, we never introduce
	 * any additional inaccuracy.
	 *
	 * We are including the final divide-by-8 (aka. right-shift-by-3) in
	 * this operation as it ensures that we never exceeed 2**32 at any
	 * point.
	 *
	 * The formula for calculating BSEL is slightly different when exp is
	 * negative than it is when exp is positive.
	 */
	if (exp < 0) {
		/* We are supposed to subtract 1, then apply BSCALE. We want to
		 * apply BSCALE first, so we need to turn everything inside the
		 * parenthesis into a single fractional expression.
		 */
		cpu_hz -= 8 * baud;

		/* If we end up with a left-shift after taking the final
		 * divide-by-8 into account, do the shift before the divide.
		 * Otherwise, left-shift the denominator instead (effectively
		 * resulting in an overall right shift.)
		 */
		if (exp <= -3) {
			div = ((cpu_hz << (-exp - 3)) + baud / 2) / baud;
		} else {
			baud <<= exp + 3;
			div = (cpu_hz + baud / 2) / baud;
		}
	} else {
		/* We will always do a right shift in this case, but we need to
		 * shift three extra positions because of the divide-by-8.
		 */
		baud <<= exp + 3;
		div = (cpu_hz + baud / 2) / baud - 1;
	}

	(usart)->BAUDCTRLB = (uint8_t)(((div >> 8) & 0X0F) | (exp << 4));
	(usart)->BAUDCTRLA = (uint8_t)div;

	return true;
}

