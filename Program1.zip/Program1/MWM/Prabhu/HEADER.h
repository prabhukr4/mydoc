/************************************************************************/
/*						HEADERS DECLARATIONS                            */
/************************************************************************/
#include <avr/io.h>
#include<avr/interrupt.h>
#include<util/delay.h>
#include <stdbool.h>
#include "uart.h"
#include "ISR.h"
#include "CRC_CALC.h"
#define FCPU 4e6


