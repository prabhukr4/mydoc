//VT100_Setting();
//StatusLED_TOGL;
//Get_ADC();
//	uart1_out(27); uart1_con_out("[5;15H"); u1htd4(clocktick);
//D1OUT_TOGL;
//uart1_out('A');
////usart_rx();
//_delay_ms(500);_delay_ms(500);
//_delay_ms(500);_delay_ms(500);

#include "HEADER.h"
/************************************************************************

						GPIO CONTROL DEFINITION                  
						       
************************************************************************/

#define StatusLED_ON	(PORTE_OUTCLR = 0x02)		// Status LED pin at PE1
#define StatusLED_OFF	(PORTE_OUTSET = 0x02)
#define StatusLED_TOGL	(PORTE_OUTTGL = 0x02)
#define RS485_Enable	(PORTE_OUTCLR = 0x04)		// RS485 Enable and Disable pin at PE2
#define RS485_Disable	(PORTE_OUTSET = 0x04)
#define D1OUT_ON		(PORTC_OUTSET = 0x10)		// Digital Out/LED pin at PC4
#define D1OUT_OFF		(PORTC_OUTCLR = 0x10)
#define D1OUT_TOGL		(PORTC_OUTTGL = 0x10)
#define D2OUT_ON		(PORTD_OUTSET = 0x10)		// Digital Out/LED pin at PD4
#define D2OUT_OFF		(PORTD_OUTCLR = 0x10)
#define D2OUT_TOGL		(PORTD_OUTTGL = 0x10)
#define D3OUT_ON		(PORTD_OUTSET = 0x20)		// Digital Out/LED pin at PD5
#define D3OUT_OFF		(PORTD_OUTCLR = 0x20)
#define D3OUT_TOGL		(PORTD_OUTTGL = 0x20)
#define D4OUT_ON		(PORTD_OUTSET = 0x02)		// Digital Out/LED pin at PD1
#define D4OUT_OFF		(PORTD_OUTCLR = 0x02)
#define D4OUT_TOGL		(PORTD_OUTTGL = 0x02)
#define DAC1_REF_DATA_CH0	((2.5*4095)/3.3)		// DAC_DATA=((VDAC output * 12bit resolution)/VRef)
// MODBUS
#define SlaveAddr		0x01
#define FunctionCode	0x03

/************************************************************************

						FUNCTIONS DECLARATIONS                         
						 
************************************************************************/
void System_init(void);								// System initilization
void VT100_Setting(void);							// VT100 terminal format
void Get_ADC(void);									// Get the ADC voltage
void usart_rx(void);								// 
void GetRegisterData(void);

/************************************************************************

						VARIABLE DECLARATIONS                          
						
************************************************************************/
unsigned int i=0,clocktick=0,tick=0,a=0,temp=0, ModArray[40];
unsigned char rx_data;
unsigned long int AvgVoltage=0;
//typedef enum {false1 = 0, true1 = 1} myenum;

/************************************************************************

						MAIN FUNCTION ROUTINE                          
						
************************************************************************/
int main()
{
	System_init();
	StatusLED_OFF;
	while(1)
	{
		u1htd3(temp);
		temp++;
		uart1_out(0x0a); uart1_out(0x0d);
		_delay_ms(500);_delay_ms(500);
	}
}

void GetRegisterData()
{
	ModArray[0] = SlaveAddr;
	ModArray[1] = FunctionCode;
	ModArray[2] = 0x00;
	ModArray[3] = 0x05;
	ModArray[4] = 0x00;
	ModArray[5] = 0x03;
//	ModArray[6] = crc(*ModArray,6);
	for (i=0; i<=5; i++)
	{
		uart1_out(ModArray[i]);
	}
}
void usart_rx()
{
	while(!(USARTD1_STATUS & USART_RXCIF_bm));
	char ch = USARTD1_DATA;
	StatusLED_TOGL;
	uart1_out(ch);
}
/************************************************************************

						SYSTEM INITIALIZATION
						
************************************************************************/
void System_init(void)
{
	PORTE_DIR |= 0b00000110;			// PE1 is Status LED and PE2 is RS485 Enable both act as output
	PORTD_DIR |= 0b00110010;			// I/O LED
	PORTC_DIR |= 0b00010000;			// LED
	PORTB_DIR |= 0b00000100;			// PB2 (DAC) as output
	uart_init();						// uart initialization
	RS485_Enable;						// Enable the RS485 pin
	
/*-----------------------------------------------------------------------------------
								ADC Initialization				
-----------------------------------------------------------------------------------*/
	PORTA_DIR |= 0x00;					// PORTA act as input
	PORTB_DIR |= 0b00000100;			// PB2 as output, for ADC reference
	//Registers
	ADCA_CTRLA		= 0x01;				//DMA off,Conversion disable, Flush off
	ADCA_CTRLB		= 0x00;				//High impedance, Current NO limit, 12Bit
	ADCA_REFCTRL	= 0x20;				//PortA AREFA, No band gap, No temp. measurement
	ADCA_PRESCALER	= 0x03;				// Prescalar is DIV32
	//Channel
	ADCA_CH0_CTRL	= 0x00;				//Do not ADC conversion, gain as 1
	ADCA_CH0_MUXCTRL= 0x28;				//Mux configured to Channel ADC5 (i.e.) PA5
	ADCA_CH0_INTCTRL= 0x00;				//interrupt When conversion is complete
	
/*-----------------------------------------------------------------------------------
								DAC-Channel 0  Initialization				
-----------------------------------------------------------------------------------*/
	DACB_CTRLA		= 0x05;				// CHO channel enable, DAC ON
	DACB_CTRLB		= 0x00;				// Single channel operation CH0 , No Event trigger used
	DACB_CTRLC		= 0x08;				// Reference as VCC
	DACB_EVCTRL		= 0x00;				// No trigger used
	DACB_CH0DATA	= DAC1_REF_DATA_CH0;// Put DAC data, (i.e) 2.5V output
/*-----------------------------------------------------------------------------------
							TIMER Initialization				
-----------------------------------------------------------------------------------*/	
	TCC0_CTRLA		= 0x06;				// Prescalar as 256
	TCC0_CTRLB		= 0x00;
	TCC0_INTCTRLA	= 0x03;				// Over or underflow interrupt level High priority and Disabled the Timer error interrupt
	TCC0_INTFLAGS	= 0x01;				// Clear the interrupt
	TCC0_PER		= 78;				// Clock tick 10ms (i.e)F=1/10ms=200Hz,
										// Time Count = (Fosc/(Prescale*Interrupt Frequency))-1 ==> (4000000/256*200)-1 = 77.125
/*-----------------------------------------------------------------------------------
		Global Interrupt and Programmable Multilevel Interrupt Controller(PMIC)
-----------------------------------------------------------------------------------*/
	PMIC_CTRL|=PMIC_HILVLEN_bm|PMIC_MEDLVLEN_bm|PMIC_LOLVLEN_bm;// Activating the High Medium Low level Interrupts in the Controller
	SREG|=0x80;							//Global interrupt enable register
}

/************************************************************************

							GET ADC DATA			                 
							   
/************************************************************************/
void Get_ADC()
{
	AvgVoltage = 0;
	for(i=0; i<500; i++)
	{
		ADCA_CTRLA		|=	0x08;			// Channel start the single conversion, after it will automatically reset
		ADCA_CH0_CTRL	 =	0x81;			// Start conversion and Single ended input
		while(!(ADCA_INTFLAGS & 0x01));		// Wait until conversion is complete
		AvgVoltage += ADCA_CH0_RES;			// Load the 12 bit value
	}
	_delay_ms(500);
	AvgVoltage = AvgVoltage/500;			// get Average of 500 Samples
	uart1_out(27); uart1_con_out("[4;15H"); u1htd4(AvgVoltage);
}

void VT100_Setting()
{
		uart1_out(27); uart1_con_out("[1;1H-------------------------------");	
		uart1_out(27); uart1_con_out("[2;10HMWM TESTING");
		uart1_out(27); uart1_con_out("[3;1H-------------------------------");	
		uart1_out(27); uart1_con_out("[4;1HADC COUNT   -");
		uart1_out(27); uart1_con_out("[5;1HTIMER COUNT -");
		
}
ISR(USARTD1_RXC_vect)					// USART D1 Receiver interrupt Routine
{
	rx_data = USARTD1_DATA;		
	temp++;
}

//ISR(TCC0_OVF_vect)						// Timer C0 Interrupt Routine
//{
	//tick++;
	//if(tick == 50){StatusLED_TOGL;}
//}