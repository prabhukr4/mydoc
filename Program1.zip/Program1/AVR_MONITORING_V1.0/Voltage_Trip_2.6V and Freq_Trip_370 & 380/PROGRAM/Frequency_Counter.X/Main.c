/*************************************************************************************************
*  PURPOSE      : Frequency Counter for AVR		 *
*  DEVELOPED BY : Prabhu R                                                                   *
*  STARTED ON   : 05-05-2017                                                                     *
*  VERSION      : V1.0                                                                           *
*  Language     : C Programming                                                                  *
*  Controller   : PIC12F683(8 Bit)                                                               *
*                                                                                                *                  
**************************************************************************************************

********************************************************************************
* HARDWARE *         * PORT ALLOCATION  *                                      *
********************************************************************************
------------------------------------|
PIN |GPIO  	 |Port Allocate         |
----|--------|----------------------|
1	|-		 | VDD (+5V)            |
2	|5		 | Voltage_Trip_Relay   |
3	|4		 | ADC Input            |
4	|3		 | MCLR                 |
5	|2   	 | Freq_Count           |
6	|1   	 | Freq_trip Relay      |
7	|0		 | Test LED             |
8	|-		 | VSS                  |
------------------------------------|
 */

/*******************************************************************************/
/*                                                                             */ 
/*                              Include Files                                  */
/*                                                                             */
/*******************************************************************************/

#include <xc.h>
#include <stdint.h>

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.

/*******************************************************************************/
/*                                                                             */ 
/*                              Configuration                                  */
/*                                                                             */
/*******************************************************************************/

#pragma config FOSC = INTOSCIO  // Oscillator Selection bits (INTOSCIO oscillator: I/O function on RA4/OSC2/CLKOUT pin, I/O function on RA5/OSC1/CLKIN)
#pragma config WDTE = ON        // Watchdog Timer Enable bit (WDT enabled)
#pragma config PWRTE = ON       // Power-up Timer Enable bit (PWRT enabled)
#pragma config MCLRE = ON       // MCLR Pin Function Select bit (MCLR pin function is MCLR)
#pragma config CP = OFF         // Code Protection bit (Program memory code protection is disabled)
#pragma config CPD = OFF        // Data Code Protection bit (Data memory code protection is disabled)
#pragma config BOREN = ON       // Brown Out Detect (BOR enabled)
#pragma config IESO = OFF       // Internal External Switchover bit (Internal External Switchover mode is disabled)
#pragma config FCMEN = OFF      // Fail-Safe Clock Monitor Enabled bit (Fail-Safe Clock Monitor is disabled)

/*******************************************************************************/
/*                                                                             */ 
/*                              Crystal Oscillator                             */
/*                                                                             */
/*******************************************************************************/

#define _XTAL_FREQ 4000000

/*******************************************************************************/
/*                                                                             */ 
/*                              Limit Values Definition                        */
/*                                                                             */
/*******************************************************************************/
#define UnderFreqLimit           370     // Over Frequency Limit
#define UnderFreqResetLimit      380     // Over Frequency Reset Limit


#define VoltageTripRelay          GPIObits.GP5    //  GPIO Pin GP4 is defined as Voltage Trip Relay Output
#define FreqTripRelay             GPIObits.GP1    //  GPIO Pin GP5 is defined as Frequency Trip Relay output
#define LED                       GPIObits.GP0    //  GPIO Pin GP5 is defined as Status LED output



/*******************************************************************************/
/*                                                                             */ 
/*                              Function Declaration                           */
/*                                                                             */
/*******************************************************************************/

//void interrupt isr(void);               //  Interrup function declaration
void System_Init(void);                 //  System Init function declaration
void Collect_ADC_Inputs(void);          //  ADC Signal samplinig function declaration
void Check_Voltage(void);               //  Voltage checking function declaration ( OV & UV Check )
void Check_Frequency(void);               //  Frequency checking function declaration (Lower Freq)
void Process_Control_Output(void);      //  Output processing function ( Relay & LED output )


/*******************************************************************************/
/*                                                                             */ 
/*                              Global Variables Definition                    */
/*                                                                             */
/*******************************************************************************/

unsigned int AvgVoltage,Capture1=0,Capture2=0,i=0,Freq=0;
float Period=0;
bit OverVoltageFlag;
bit UnderVoltageFlag;
bit UnderFreqFlag;
bit VoltageTripRelayFlag;
bit LEDFlag;
bit FreqTripRelayFlag;
bit PowerONFlag;



/*******************************************************************************/
/*                                                                             */ 
/*                              Main Function Start                            */
/*                                                                             */
/*******************************************************************************/

void main(void) 
{
    System_Init();   
    VoltageTripRelay = 0;
    VoltageTripRelayFlag = 0;
    FreqTripRelay = 0;
    FreqTripRelayFlag = 0;
    LED = 0;
    LEDFlag = 0;
    
    for( ; ; )
    {                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             
        Collect_ADC_Inputs();
        Check_Voltage();
        Check_Frequency();
        Process_Control_Output();
        if(LEDFlag){LED = 1;}
        CLRWDT();
    }
}
/****************************** Main Function END   ********************************/


/*******************************************************************************/
/*                              System Initialization                          */
/*******************************************************************************/

void System_Init(void)
{
/******************* Internal Oscillator Setting *******************************/  
    
    OSCCONbits.IRCF0 = 0;           //  
    OSCCONbits.IRCF1 = 1;           //  Internal Oscillator configured to 4 MHz
    OSCCONbits.IRCF2 = 1;           //
    OSCCONbits.SCS   = 1;
    //OSCTUNE = 0x00;
    
/*********************** GPIO Port Setting *************************************/
    
    TRISIObits.TRISIO0 = 0;         //  GPIO0 is set as Input (LED))
    TRISIObits.TRISIO1 = 0;         //  GPIO1 is set as Output (Frequency Trip Relay)
    TRISIObits.TRISIO2 = 1;         //  GPIO2 is set as Input (Frequency Read)
    TRISIObits.TRISIO4 = 1;         //  GPIO4 is set as Output (Voltage_ADC)
    TRISIObits.TRISIO5 = 0;         //  GPIO5 is set as Output (Trip relay for Voltage)
    
    ANSELbits.ANS0 = 0;             //  ADC Channel-1 is enabled
    ANSELbits.ANS1 = 0;             //  ADC Channel-2 is enabled
    ANSELbits.ANS2 = 0;             //  ADC Channel-3 is disabled
    ANSELbits.ANS3 = 1;             //  ADC Channel-4 is disabled

/*********************** Unused Peripheral Masking *****************************/
    
    WPU = 0x00;                     //  Internal Pull-ups disabled
    IOC = 0x00;                     //  Interrupt ON Change disabled
    CMCON0 = 0x07;                  //  Comparator disabled    
    CCP1CON = 0x05;                 //  CCP Module disabled
    PCONbits.ULPWUE = 0;            //  Ultra low power wakeup disabled

/*********************** Timer-0 Assigned as WDT   *****************************/   
    
    OPTION_REG = 0x8F;              //  Timer-0 assigned to WDT 
    
/*********************** Timer-1 Configuration for 10ms Tick ********************/    
    
    T1CONbits.TMR1CS = 0;           //  Timer-1 Clock source selection (FOSC)
    T1CONbits.nT1SYNC = 1;          //  Timer-1 Sync disabled
    T1CONbits.T1OSCEN = 0;          //  LP osc. Disabled
    T1CONbits.T1CKPS0 = 0;          //  1:2 Prescalar 
    T1CONbits.T1CKPS1 = 1;          //  131ms
    T1CONbits.TMR1GE = 0;           //
    T1CONbits.TMR1ON = 1;           //  Timer-1 ON
    TMR1H = 0;                    
    TMR1L = 0;
    
/*********************** Interrupt Configuration   *****************************/    
    
    INTCONbits.GIE = 1;             //  Global Interrupts enabled
    INTCONbits.PEIE = 1;            //  Peripheral interrupts enabled
    INTCONbits.T0IE = 0;            //  Timer-0 interrupt disabled
    INTCONbits.INTE = 0;            //  External Interrupt disabled
    INTCONbits.GPIE = 0;            //  GPIO Change Interrupt disabled
 //   PIE1bits.T1IE = 1;              //  Timer-1 Interrupt enabled
    PIE1bits.CCP1IE = 1;            //  Capture mode interrupt enabled
    CCP1IF = 0;
    
/*********************** ADC Configuration   *****************************/    
    
    ADCON0 = 0x8D;                  //  ADC Register configuration
    ADCON0bits.VCFG = 0;            //  ADC Reference is connected to VCC
    ANSELbits.ADCS0 = 1;
    ANSELbits.ADCS1 = 0;
    ANSELbits.ADCS2 = 1;
}

/*******************************************************************************/
/*                                                                             */ 
/*                       ADC Signal Sampling                                   */
/*                                                                             */
/*******************************************************************************/

void Collect_ADC_Inputs(void)
{
    long int TempVoltage = 0;
    unsigned char i;
    
    for(i = 0; i < 100; i++)
    {
        ADCON0 = 0x8D;                          //  ADC Channel-0 Selection     Voltage Input
        __delay_us(100);
        ADCON0bits.GO_DONE = 1;                 //  ADC Conversion ON set
        while(ADCON0bits.GO_DONE);              //  Waiting for ADC Conversion to complete
        TempVoltage += ADRESH*256+ADRESL;       //  Collecting the ADC values ( 0-1024)
    }
    AvgVoltage = TempVoltage/100;               //  Average Voltage calculation
}

/*******************************************************************************/
/*                                                                             */ 
/*                         Voltage Protection Function                         */
/*                                                                             */
/*******************************************************************************/

void Check_Voltage(void)
{
    if(AvgVoltage >= 532)           // 1023/5=204.6== 204.6*2.6= 531.92==532
    {
        OverVoltageFlag = 1;                    
    }
    else
    {
        OverVoltageFlag = 0;
        VoltageTripRelayFlag = 0;
    }
}

/*******************************************************************************/
/*                                                                             */ 
/*                              Interrupt Function                             */
/*                                                                             */
/*******************************************************************************/
void interrupt isr(void)
{
    if(CCP1IF)
    {
        CCP1IF = 0;
        if(i==1)
        {
            Capture1 = ((256 * CCPR1H) + CCPR1L );
            i++;
        }
        else if(i==2)
        {
            Capture2 = ((256 * CCPR1H) + CCPR1L );
            Period = Capture2 - Capture1;
            i=1;
        //    LED = ~LED;
            TMR1H = TMR1L = 0;
        }
        else { i++; }
    }

}
/*******************************************************************************/
/*                           Frequency Calculation and checking                */
/*******************************************************************************/
void Check_Frequency(void)
{
    Period = ((4000000)/(4*4*Period));
    Freq =(unsigned int) (Period);
    if(Freq < UnderFreqLimit)
    {
        UnderFreqFlag = 1;
    }
    if(Freq > UnderFreqResetLimit)
    {
        UnderFreqFlag = 0;
    }
    
}

/*******************************************************************************/
/*                                                                             */ 
/*                         Control Output Processing                           */
/*                                                                             */
/*******************************************************************************/

void Process_Control_Output(void)
{
    if(OverVoltageFlag) //  && !TripRelayFlag
    {
        VoltageTripRelayFlag = 1;
        VoltageTripRelay     = 1;
    }
 
    if(!VoltageTripRelayFlag)
    {
        VoltageTripRelayFlag = 0;
        VoltageTripRelay     = 0;
    }
    if(UnderFreqFlag)
    {
        FreqTripRelay = 1;
        FreqTripRelayFlag = 1;
    }
    if(!UnderFreqFlag)
    {
        FreqTripRelay = 0;
        FreqTripRelayFlag = 0;
    }
}

