#include<pic.h>
#include"lcd.h"
#define _XTAL_FREQ 4e6
__CONFIG(0x3F71);

void uart_init();
void gsm11();
void gsm12();
void gsm21();
void gsm22();
void time(int);
void uart_out(unsigned int);
void uart_con_out(unsigned char *, unsigned int);
void serial(char word);
unsigned char ser[10];
unsigned int x,i=0,a;


#define IR		RC0
#define lock	RC1
#define sw		RC2

void main()
{
	lcd_init();
	uart_init();
	TRISC = 0x81;
	x=0;
	i=0;
	sw = 1;
	command(0x80); lcd_dis("BARCODE SECURITY",16);
	command(0xC0); lcd_dis("  ALERT SYSTEM  ",16);
	time(25);
	command(0x80); lcd_dis("GNANAMANI COLLEG",16);
	command(0xC0); lcd_dis("  OF TECHNOLOGY ",16);
	
	uart_con_out("AT",2);
	uart_out(0x0A);
	uart_out(0x0D);
	delay(65000); 
	uart_con_out("AT+CMGF=1",9);
	uart_out(0x0A);
	uart_out(0x0D);
	delay(65000);
	command(0x01);
	command(0x80); lcd_dis("BARCODE ACCESS  ",16);
	while(1)
	{			
		if(i>=7)
		{	
			i = 0;
		}
		sw = 1;	
		if(IR)
		{
			sw = 0;	
			time(35);
			if(ser[0] == '1' && ser[1] == '2' && ser[2] == '3' && ser[3] == '4')
			{
				sw = 1;
				command(0xC0); lcd_dis("Authentication  ",16);
				gsm11();
				gsm21();
				
			}
			else
			{	
				sw = 1;
				command(0xC0); lcd_dis("FAIL            ",16);
				gsm12();
				gsm22();
			}
		}
		
			
	} 
			 
} 

void gsm11()
{

	uart_con_out("AT+CMGS=",8);
	uart_out('"');
	uart_con_out("9842921041",10);
	uart_out('"');
	uart_out(0x0A);
	uart_out(0x0D);
	delay(10000);
   	uart_con_out("Authendicated By Your Family Member",35);                  // Your Messgae
	time(2);
   	uart_out(0x1A);
   	time(20);
   	command(0xC0); lcd_dis("Message Sent    ",16);
   	uart_out(0x0A);
   	uart_out(0x0D);
   	delay(10000);
	 
}
void gsm12()
{
	
	uart_con_out("AT+CMGS=",8);
	uart_out('"');
	uart_con_out("9965695353",10);
	uart_out('"');
	uart_out(0x0A);
	uart_out(0x0D);
	delay(10000);
   	uart_con_out("Unknown Person Trying to Enter your Home",41);                  // Your Messgae
	time(2);
   	uart_out(0x1A);
   	time(20);
   	command(0xC0); lcd_dis("Message Sent    ",16);
   	uart_out(0x0A);
   	uart_out(0x0D);
   	delay(10000);
}
void gsm21()
{

	uart_con_out("AT+CMGS=",8);
	uart_out('"');
	uart_con_out("9965695353",10);
	uart_out('"');
	uart_out(0x0A);
	uart_out(0x0D);
	delay(10000);
   	uart_con_out("Authendicated By Your Family Member",35);                  // Your Messgae
	time(2);
   	uart_out(0x1A);
   	time(20);
   	command(0xC0); lcd_dis("Message Sent    ",16);
   	uart_out(0x0A);
   	uart_out(0x0D);
   	delay(10000);
	 
}
void gsm22()
{
	
	uart_con_out("AT+CMGS=",8);
	uart_out('"');
	uart_con_out("9842921041",10);
	uart_out('"');
	uart_out(0x0A);
	uart_out(0x0D);
	delay(10000);
   	uart_con_out("Unknown Person Trying to Enter your Home",41);                  // Your Messgae
	time(2);
   	uart_out(0x1A);
   	time(20);
   	command(0xC0); lcd_dis("Message Sent    ",16);
   	uart_out(0x0A);
   	uart_out(0x0D);
   	delay(10000);
}
	
	
void time(int z)
{
	while(z--){__delay_ms(100);}
}

void uart_init()
{
	 GIE=1;
	 PEIE=1;  
	 SPBRG = 25;         // for 9600 baud rate
	 BRGH = 1;		     // baud rate high
	 SYNC = 0;		     // asynchronous mode
	 SPEN = 1;		     // serial port enable
	 TXEN = 1;		     // tx enable
	 RCIE = 1;			 // interrupt set
	 CREN = 1;		     // rx enable
}


void interrupt rx(void)
{
 if(RCIF)
  {
	  RCIF=0;
	  x = 1;
	  a = RCREG;
	 serial(a);

  }
}
void serial (char word)
{
	ser[i]=a;
    i++;
}	

void uart_con_out(unsigned char *word, unsigned int n)
{
	int i;
	for(i=0; i<n; i++)
	{
		uart_out(word[i]);
	}
}

void uart_out(unsigned int x)
{
	TXREG = x;
	while(!TXIF);
	TXIF = 0;
	delay(2500);
}
