/*------------------------------------------
Project			:Power demand analysys
ORGANISATION	:Sirius Techno Solutions
MCU				:PIC16F877A
IDE				:MPLAB IDE v8.30
COMPILER		:Hi-Tech C-Compiler
PROGRAMMER		:NISHANTH
---------------------------------------------*/
#include<pic.h>							//Header File for PIC16F877A microcontroller
#include"lcd.h"							//User Defined Header file for 16x2 LCD
__CONFIG(0x3f71);
#define _XTAL_FREQ 4e6
#define Load1 RB0						//Define the Port pin RB0 as Load1
#define Load2 RB1						//Similarly
#define Load3 RB2
#define Battery RB3

#define SW1 RB5						//Define the Port pin RB0 as Load1
#define SW2 RB6						//Similarly
#define SW3 RB7

#define rtc_write 0xd0					//RTC DEVICE ADDRESS(1101000)-->last bit 0 for write
#define rtc_read 0xd1					//RTC DEVICE ADDRESS(1101000)-->last bit 1 for read

void send_i2c(unsigned char);				//Start Function and Variable Declaration
void write_i2c(unsigned char,unsigned char);
unsigned char read_i2c(unsigned char);
void wait_i2c();
void uart_init();
void delay_sec(int);
unsigned char BCD2BINARY(unsigned char);
bank1 unsigned char received_data=0;
unsigned char sec=0,min=58,hou=6,date,mon,year,day;
int count = 0, x = 0;								

void i2c_init(void)
{
	SSPCON = 0x38;
	SSPSTAT = 0x80;
	SSPADD = 49;
}					//End of Declaration											
void main()								//Start of Main Function								
{
	lcd_init();							//Init Function Call for LCD
//	i2c_init();							//Init Function Call for I2C
	uart_init();
							
	TRISB = 0xF0;						//Similarly PORTB
	RBPU = 1;	
	command(0x80);						//LCD Command for starting point i.e 1 row 1 column
	lcd_dis("  POWER DEMAND  ");
	command(0xC0);						//LCD Command for second line
	lcd_dis("   MANAGEMENT   ");
	delay(65000);
	command(0x01);			// LCD Clear
	command(0x80);
	lcd_dis("Time:");
	Load2 = Load2 = Load3 = Battery =  1;
	while(1)
	{
	
		command(0x85);
		htd2(hou);
		write(':');
		command(0x88);
		htd2(min);
		write(':');
		command(0x8B);
		htd2(sec);
		if(SW2 == 1 && SW3 == 1){x = 0;Load1 = 1;Load2 = 1;Load3 = 1;delay(1000);	Battery = 1;delay(1000);delay(1000);command(0xc0);lcd_dis("                ");}
		else if(SW2 == 0 && SW3 == 1){x = 0;Load1 = 1;Load2 = 0;Load3 = 1;delay(1000);Battery = 0;delay(1000);delay(1000);command(0xc0);lcd_dis("Valley Filling  ");}
		else if(SW2 == 1 && SW3 == 0){x = 0;Load1 = 1;Load2 = 1;Load3 = 0;delay(1000);Battery = 0;delay(1000);delay(1000);command(0xc0);lcd_dis("Valley Filling  ");}
		else if(SW2 == 0 && SW3 == 1){x = 0;Load1 = 1;Load2 = 0;Load3 = 1;delay(1000);Battery = 0;delay(1000);command(0xc0);lcd_dis("                ");}
		else if(SW2 == 1 && SW3 == 0){x = 0;Load1 = 1;Load3 = 0;Load2 = 1;delay(1000);Battery = 0;delay(1000);delay(1000);command(0xc0);lcd_dis("                ");}
		else if(SW2 == 0 && SW3 == 0){x = 0;Load3 = 0;Load2 = 0;Load1 = 1;delay(1000);Battery = 1;delay(1000);delay(1000);command(0xc0);lcd_dis("                ");}
		else if(SW2 == 1 && SW3 == 1){x = 0;Load3 = 1;Load2 = 1;Load1 = 1;delay(1000);Battery = 1;delay(1000);delay(1000);command(0xc0);lcd_dis("                ");}
		else if(SW2 == 0 && SW3 == 0)
		{
			Load1 = 0;Load2 = 0;
			if(x == 0 )
			{
			Load3 = 0;
			delay_sec(5);
			Load3 = 1;
			command(0xc0);
			lcd_dis("Peak Clipping   ");
			x = 1;	
			}
	}
			else{Load3 = 1;Load2 = 1;Load1 = 1;}
		
		while(hou>=7 && min<=2)
		{
		if(SW1 == 0 && SW2 == 1 && SW3 == 1){x = 0;Load1 = 0;Load2 = 1;Load3 = 1;delay(1000);	Battery = 1;delay(1000);delay(1000);command(0xc0);lcd_dis("Load Shifting   ");}
		else if(SW1 == 1 && SW2 == 0 && SW3 == 1){x = 0;Load1 = 1;Load2 = 0;Load3 = 1;delay(1000);Battery = 1;delay(1000);delay(1000);command(0xc0);lcd_dis("Load Shifting   ");}
		else if(SW1 == 1 && SW2 == 1 && SW3 == 0){x = 0;Load1 = 1;Load2 = 1;Load3 = 0;delay(1000);Battery = 1;delay(1000);delay(1000);command(0xc0);lcd_dis("Load Shifting   ");}
		else if(SW1 == 0 && SW2 == 0 && SW3 == 1){x = 0;Load1 = 0;Load2 = 0;Load3 = 1;delay(1000);Battery = 1;delay(1000);command(0xc0);lcd_dis("Load Shifting   ");}
		else if(SW1 == 0 && SW2 == 1 && SW3 == 0){x = 0;Load1 = 0;Load3 = 0;Load2 = 1;delay(1000);Battery = 1;delay(1000);delay(1000);command(0xc0);lcd_dis("Load Shifting   ");}
		else if(SW1 == 1 && SW2 == 0 && SW3 == 0){x = 0;Load3 = 0;Load2 = 0;Load1 = 1;delay(1000);Battery = 1;delay(1000);delay(1000);command(0xc0);lcd_dis("Load Shifting   ");}
		else if(SW1 == 1 && SW2 == 1 && SW3 == 1){x = 0;Load3 = 1;Load2 = 1;Load1 = 1;delay(1000);Battery = 1;delay(1000);delay(1000);command(0xc0);lcd_dis("Load Shifting   ");}
		else if(SW1 == 0 && SW2 == 0 && SW3 == 0)
		{
			Load1 = 0;Load2 = 0;
			if(x == 0 )
			{
			Load3 = 0;
			delay_sec(5);
			Load3 = 1;
			command(0xc0);
			lcd_dis("Peak Clipping   ");
			x = 1;	
			}
	}
			else{Load3 = 1;Load2 = 1;Load1 = 1;}
		command(0x85);
		htd2(hou);
		write(':');
		command(0x88);
		htd2(min);
		write(':');
		command(0x8B);
		htd2(sec);		
		}

		
			
}

}
void send_i2c(unsigned char hold)
{
	while(1)
		{
		SSPBUF=hold;
		wait_i2c();
		if(ACKSTAT!=1)
		break;
		}		


}
void write_i2c(unsigned char wr_add,unsigned char wr_data)
{
	SEN=1;  
	wait_i2c();
	send_i2c(rtc_write);
	send_i2c(wr_add);
	send_i2c(wr_data); 
	PEN=1;
	wait_i2c();
}
unsigned char read_i2c(unsigned char d1)
{
	
	SEN=1;
	wait_i2c();
	send_i2c(rtc_write);
	send_i2c(d1);
	PEN=1;
	
	
	
	wait_i2c();
	SEN=1;
	wait_i2c();
	send_i2c(rtc_read);
	RCEN=1;
	
	
	
	
	wait_i2c();
	ACKDT=1;
	ACKEN=1;
	wait_i2c();
	received_data=SSPBUF; 
	PEN=1;
	
	
	wait_i2c(); 
	delay(1000);
	return received_data;
}	
void wait_i2c()
{
	while(SSPIF==0);
	delay(1000);
	SSPIF=0;
}
unsigned char BCD2BINARY(unsigned char x)
{ 
	unsigned char binary;
//	binary=x-0x06;
	binary = ((x & 0xF0 )>>4 ) * 10 + (x & 0x0F);
	delay(1000);
	return (binary);
}
void uart_init()
{
	 GIE=1;
	 PEIE=1;
	 SPBRG = 25;         // for 9600 baud rate
	 BRGH = 1;		     // baud rate high
	 SYNC = 0;		     // asynchronous mode
	 SPEN = 1;		     // serial port enable
	 TXEN = 1;		     // tx enable
	 TMR0IE=1;			//ENABLE TIMER0 INTERRUPT
   	OPTION=0x07;			//PRESCALAR VALUE 256
    TMR0=0xD8;			//TIMER REGISTER SET FOR 10ms
}
void delay_sec(int y)
{
	y = y*10;
	while(y--){__delay_ms(100);}
}	
void interrupt message(void)
{
		if(TMR0IF==1)
	{
		TMR0IF=0;
		count++;
		if(count>=100)
		{
			count=0;sec++;
			if(sec>=59)
			{
			sec=0;
			min++;
			if(min>59)
			{
				min = 0; hou++;
				if(hou>=12){hou = 1;}
			}	
			}
		
		}
	TMR0 = 0xD8;     //setting timer_0 interrupt once again after the previous interrupt
	}
}