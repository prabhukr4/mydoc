/*
===============================================================
Copyright   : Sirius Techno Solution
Author      : R.Nishanth
Description : Vehicle Safety System
MCU         : PIC16F877A
===============================================================
*/
#include<pic.h>
#include"lcd.h"
#define _XTAL_FREQ 4e6

#define RF 	  RC0
#define Relay RB7
#define Vib   RB0

__CONFIG(0x3F71);


void uart_init();
void ser_out(unsigned int a);
void ser_con_out(const unsigned char *word,unsigned int n);
void gsm_rx(void);
void gsm_send(void);

void delay_sec(unsigned int);

unsigned char data[95], send[9]=0;
int i=0, j = 0,g,y = 0,x = 1,rxcount = 0,count=0, sec=0, h = 0;

void main()
{

	lcd_init();
	uart_init();
	command(0x80);
	lcd_dis(" VEHICLE SAFETY ");
	command(0xC0);
	lcd_dis("     SYSTEM     ");
	delay_sec(3);
	ser_con_out("AT",2);
	ser_out(0x0A);	ser_out(0x0D);
	delay_sec(2);
	ser_con_out("AT+CMGF=1",9);
	ser_out(0x0A);	ser_out(0x0D);
	delay_sec(1);
	ser_con_out("AT+CMGD=1",9);ser_out(0x0a);ser_out(0x0d);
	delay_sec(1);
	delay(3000);
	ser_con_out("AT+CREG=2",9);ser_out(0x0a);ser_out(0x0d);
	delay(65000);
	ser_con_out("AT+CREG?",8);ser_out(0x0a);ser_out(0x0d);
	delay(65000);
	delay(65000);
	command(0x01);
	while(1)
	{

		if(Vib==0)
		{
		ser_con_out("ATD9698050061;",14);
		ser_out(0x0a);ser_out(0x0d);
		delay(65000);
		gsm_send();
		
		}	
		if(RF == 1)
		{
			command(0x8A);
			lcd_dis("HELMET");
			command(0xCC);
			lcd_dis("ON ");
			if(x == 1){Relay = 1;}
		
		}
		else{Relay = 0;	command(0x8A);
			lcd_dis("HELMET");
			command(0xCC);
			lcd_dis("OFF");}
		
			if(sec>=15)
			{
			gsm_rx();
			sec=0;
			}
		for(g = 0; g < 95; g++)
		{		
			if(data[g] == 'O' && data[g + 1] == 'N')
			{
				Relay = 1;
				x = 1;
				command(0x01);
				delay(1000);
				command(0xC0);delay(100); lcd_dis("VEHICLE ON......");
				delay(65000);
			}
			if(data[g] == 'O' && data[g + 1] == 'F'&& data[g + 2] == 'F')
			{
				Relay = 0;
				x = 0;
				command(0x01);
				command(0xC0);delay(100); lcd_dis("VEHICLE OFF.....");
				delay(65000);
			}
		}	

	}	
	
}	
void uart_init()
{
	 SPBRG = 25;         // for 9600 baud rate
	 BRGH = 1;		     // baud rate high
	 SYNC = 0;		     // asynchronous mode
	 SPEN = 1;		     // serial port enable
	 TXEN = 1;		     // tx enable
	 RCIE = 1;			 // interrupt set
	 CREN = 1;		     // rx enable
	 GIE=1;
	 PEIE=1;
	 TMR0IE=1;			//ENABLE TIMER0 INTERRUPT
   	OPTION=0x07;			//PRESCALAR VALUE 256
   TMR0=0xD8;			//TIMER REGISTER SET FOR 10ms
}

 void ser_con_out(const unsigned char *word,unsigned int n)
{
	for(i=0;i<n;i++)
	{
		ser_out(word[i]); 
		delay(6000);
	}
}		


void ser_out(unsigned int a)
{

    TXREG=a;
    while(!TXIF);   //CONDITION TO CHECK IF THE BIT IS TRANSMITTED OR NOT
    TXIF = 0;
}  
void gsm_send(void)
{
		ser_con_out("AT+CMGS=",8);
		ser_out('"');
		ser_con_out("9698050061",10);
		ser_out('"');
		ser_out(0x0a);ser_out(0x0d);
		delay(65000);delay(65000);
		ser_con_out("LAC:",4);
		
		for(h=0;h<=3;h++)
		{	
			ser_out(send[h]);
		}
		ser_out(0x0a);ser_out(0x0d);
		delay(65000);
		
		ser_con_out("CID:",4);
		
		for(h=4;h<=7;h++)
		{
		ser_out(send[h]);
		}
		ser_out(0x0A);ser_out(0x0D);ser_out(0x1A);
		delay(65000);
	
}	
void gsm_rx(void)
{
	delay(65000);
	ser_con_out("AT+CREG=2",9);ser_out(0x0a);ser_out(0x0d);
	delay(65000);
	ser_con_out("AT+CREG?",8);ser_out(0x0a);ser_out(0x0d);
	delay(65000);delay(65000);		
	if(rxcount >= 80)
    {
		for(g = 0; g < 95; g++)
		{
			if(data[g]=='+' && data[g+1]=='C' && data[g+2]=='R')
			{
				
				
				command(0x80);
				lcd_dis("LAC:");
				for(h=(g+12);h<=(g+15);h++)
				{
					write(data[h]);
					send[j] = data[h];
					j++;
				}
				lcd_dis("  ");
				
				delay(65000);
				command(0xC0);
				lcd_dis("CID:");
				for(h=(g+19);h<=(g+22);h++)
				{
					write(data[h]);
					send[j] = data[h];
					j++;
				}
				lcd_dis("   ");
				j = 0;
				delay(65000);
			
		delay(65000);
		rxcount=0;
		ser_con_out("AT+CMGR=1",9);	
		ser_out(0x0a);ser_out(0x0d);
		delay(65000);	
			}
		}	
		for(g = 0; g < 95; g++)
		{
			if(data[g] == 'O' && data[g + 1] == 'F'&& data[g + 2] == 'F')
			{
				Relay = 0;
				x = 0;
				command(0x01);
				command(0xC0);delay(100); lcd_dis("VEHICLE OFF.....");
				delay(65000);
			}
			if(data[g] == 'O' && data[g + 1] == 'N')
			{
				Relay=1;
				command(0xC0); lcd_dis("VEHICLE ON......");
				rxcount = 0;
				delay(1000);
			}
		}
			
		
	rxcount = 0;
		ser_out(0x0a); ser_out(0x0d);
		delay_sec(1);
		ser_con_out("AT+CMGD=1",9);ser_out(0x0a);ser_out(0x0d);
	    delay(1000);
		ser_out(0x0a); ser_out(0x0d);	
	}


}
void delay_sec(unsigned int y)
{
	y = y*10;
	while(y--){__delay_ms(100);}
}	
void interrupt message(void)
{
		if(TMR0IF==1)
	{
		TMR0IF=0;
		count++;
		if(count>=100)
		{
			count=0;sec++;
		
		}
	TMR0 = 0xD8;     //setting timer_0 interrupt once again after the previous interrupt
	}

	if(RCIF==1)
  	{
	  RCIF=0;
	  data[rxcount]=RCREG; 
      rxcount++; 
      //if(data[rxcount] == 'K' && data[rxcount-1] == 'O'){rxcount=0;}
      
   }
}				   
  