/*
===============================================================
Copyright   : Sirius Techno Solution
Author      : R.PRABHU
Description : MOTION BASED CAMERA ROTATION
MCU         : PIC16F877A
===============================================================
*/

#include<pic.h>
#include "lcd.h"
#include "uart.h"
#define _XTAL_FREQ 4e6
__CONFIG(0x3f71);

#define pL RA3							//	PIR left sensor
#define pR RA4							//	PIR right sensor
#define sw RC1							//	Manual rotation for camera


void init();
void pir();
void left_rot();
void right_rot();
void stop();
void time(int);
void gsm();
void gsmx();
unsigned int i,y = 0,z=0, count = 80, count1 = 80; 
unsigned int x = 80;
unsigned char eeproml = 0, eepromr = 0, pl, data_rx[80];  

void main()
{
	init();
	uart_init();
	command(0x80); lcd_dis("    WELCOME     ",16);
	command(0xC0); lcd_dis("BATCH-1  Project",16);
	time(30);
	command(0x01);
	command(0xC0); lcd_dis("Set Direction",13);
	pl = EEPROM_READ(1);
	command(0xCF);	write(pl);
	time(30);
	command(0x80); lcd_dis("Camera Direction",16);
	
	while(sw == 1)
	{
		command(0x80); lcd_dis("Manual Direction",16);
		command(0xC0); lcd_dis("                ",16);
		PORTB = 0x09;
		delay(100);
		PORTB = 0x03;
		delay(100);
		PORTB = 0x06;
		delay(100);
		PORTB = 0x0C;
		delay(100); 
			
	}
	
	
	while(1)
	{
		command(0x80); lcd_dis("Camera Direction",16);
		pl = EEPROM_READ(1);
		if(pl == 'L')
		{
			while(x)
			{
				x--;
				PORTB = 0x09;
				delay(1000);
				PORTB = 0x03;
				delay(1000);
				PORTB = 0x06;
				delay(1000);
				PORTB = 0x0C;
				delay(1000); 
				EEPROM_WRITE(1, 'C') ; 
			}
			
		}
		
		if(pl == 'R')
		{
			while(x)
			{
				x--;
				PORTB = 0x0C;
				delay(1000);
				PORTB = 0x06;
				delay(1000);
				PORTB = 0x03;
				delay(1000);
				PORTB = 0x09;
				delay(1000); 
				EEPROM_WRITE(1, 'C') ;
			}
			
		} 
		pir();
		if(data_rx[0] == 'x')
		{
			data_rx[0] = 0;
			command(0xC0); lcd_dis("Motion Detected ",16);
			y = 0;
			gsm();
			delay(4000);
			gsmx();
		}
		if(data_rx[0] == 'U')
		{
			RB6 = 1;
		}
		else
		{
			RB6 = 0;
		}
	
			
	}	
}

/* ~~~~~~~~~~~~~~~ INITILIZATION ~~~~~~~~~~~~~~~ */

void init()
{
	lcd_init();
	TRISB = 0x00;
	TRISA = 0xff;
	ADCON1 = 0x06;
	RC2 = 0;
}

void gsm()
{
	time(20);
	delay(65000);
	uart_con_out("AT",2);
	uart_out(0x0A);
	uart_out(0x0D);
	delay(65000); time(20);
	uart_con_out("AT+CMGF=1",9);
	uart_out(0x0A);
	uart_out(0x0D);
	delay(65000);
	delay(65000);
	uart_con_out("AT+CMGS=",8);
	uart_out('"');
	uart_con_out("8754759224",10);
	uart_out('"');
	uart_out(0x0A);
	uart_out(0x0D);
	delay(10000);
	uart_con_out("Motion Detected ",16);						// Your Messgae
	time(2);
	uart_out(0x1A);
	uart_out(0x0A);
	uart_out(0x0D);
	command(0x80); lcd_dis("Message Sent    ",16);	
	time(20);
	y = 0;
	data_rx[0] = 0; 
}

void gsmx()
{
	time(20);
	delay(65000);
	uart_con_out("AT",2);
	uart_out(0x0A);
	uart_out(0x0D);
	delay(65000); time(20);
	uart_con_out("AT+CMGF=1",9);
	uart_out(0x0A);
	uart_out(0x0D);
	delay(65000);
	delay(65000);
	uart_con_out("AT+CMGS=",8);
	uart_out('"');
	uart_con_out("8940103156",10);
	uart_out('"');
	uart_out(0x0A);
	uart_out(0x0D);
	delay(10000);
	uart_con_out("Motion Detected ",16);						// Your Messgae
	time(2);
	uart_out(0x1A);
	uart_out(0x0A);
	uart_out(0x0D);
	command(0x80); lcd_dis("Message Sent    ",16);	
	time(20);
	y = 0;
	data_rx[0] = 0; 
}


/* ~~~~~~~~~~~~ GSM ~~~~~~~~~~~~~~~~~~~~~~~~ 
void gsm()
{
	time(20);
	uart_con_out("AT",2);
	uart_out(0x0a);	uart_out(0x0d);
	time(20);
	uart_con_out("AT+CMGF=1",9);
	uart_out(0x0a);	uart_out(0x0d);
	time(20);
	uart_con_out("AT+CMGS=",8);
	uart_out('"');
	uart_con_out("9842708621",10);							// Number
	uart_out('"');
	uart_out(0x0a);	uart_out(0x0d);
	time(20);
	uart_con_out("Motion Detected ",16);						// Your Messgae
	uart_out(0x0a);	uart_out(0x0d);
	uart_out(0x0a);	uart_out(0x0d);
	time(10);
	command(0x80); lcd_dis("Message Sent    ",16);	
	time(20);
}	*/

/* ~~~~~~~~	PIR condition Status ~~~~~~~~~~~~ */
void pir()
{
	while(1)
	{
		if(pL)
		{
			EEPROM_WRITE(1, 'L') ;
			command(0xc0); lcd_dis("LEFT MOTION    ",15);
			left_rot();
			
	
		}
		if(pR)
		{
			EEPROM_WRITE(1, 'R');
			command(0xc0); lcd_dis("RIGHT MOTION   ",15);
			right_rot();
		} 
	
		if(data_rx[0] == 'x')
		{
			RC2 = 1;
			command(0x80); lcd_dis("Motion Detected",15);
			y = 0;
			gsm();
		}
		else { RC2 = 0; }
	}	
	
} 

/* ~~~~~~~~~~~~~~~~ LEFT SIDE ROTATION COMMENT ~~~~~~~~~~~~~~~~~~~~ */

void left_rot()
{
	while(count)
	{
		count--;
		count1 = 160;
		PORTB = 0x0C;
		delay(1000);
		PORTB = 0x06;
		delay(1000);
		PORTB = 0x03;
		delay(1000);
		PORTB = 0x09;
		delay(1000); 
	}	
}

/* ~~~~~~~~~~~~~~~ RIGHT SIDE ROTATION COMMENT ~~~~~~~~~~~~~~~~~~~~ */

void right_rot()
{
	while(count1)
	{
		count = 160;
		count1--;
		PORTB = 0x09;
		delay(1000);
		PORTB = 0x03;
		delay(1000);
		PORTB = 0x06;
		delay(1000);
		PORTB = 0x0C;
		delay(1000); 
	}

}

/* ~~~~~~~~~~~~~~~~~~~ STOP ROTATION ~~~~~~~~~~~~~~~~~~~~~~~ */
void stop()
{
	PORTB = 0x00;
	time(1);
}

/* ~~~~~~~~~~~ TIME DELAY ~~~~~~~~~~~~~~ */

void time(int a)
{
	while(a--)
	{
		__delay_ms(100);
	}
}

/* ~~~~~~~~~~~~~~~~~~~~~~~~ RECEIVER ~~~~~~~~~~~~~~~~~~~~~~~~~~~ */
void interrupt rx()
{
	if(RCIF)
	{
		RCIF = 0;
		data_rx[y] = RCREG;
		
	}
}