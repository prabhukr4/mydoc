#include<pic.h>
#include"lcd.h"
__CONFIG(0x3F71);
#define _XTAL_FREQ 4e6

void ext_init(void);
void time(unsigned int);
void gsm(void);
void gsm1(void);
void uart_init(void);
void uart_out(unsigned char a);
void uart_con_out(unsigned char *word);
int count = 0, x = 0;
float Calc, Balance = 3000, ml = 0;;
void main()
{
	TRISB=0xFF;
	lcd_init();
	uart_init();
	command(0x80);
	lcd_dis("GAS LEVEL       ");
	ext_init();
	delay(65000);
	uart_con_out("AT");
	uart_out(0x0A);
	uart_out(0x0D);
	delay(65000); time(20);
	uart_con_out("AT+CMGF=1");
	uart_out(0x0A);
	uart_out(0x0D);
	delay(65000);
	delay(65000);
	time(20);
while(1)
{
		if(count>=150)
		{
			count = 0;
			ml = 100;
		}	
		Balance = Balance - ml;
		if(Balance<=0){Balance = 0;}
		ml = 0;
		command(0xc0); 
		htd4(Balance);
    	lcd_dis(" ml         ");  

    	if(Balance==2000)
    	{
	    	command(0x80);
	    	lcd_dis("LESS THAN HALF  ");
	    	if(x==0){x=1;gsm();}
	    }	 
	    if(Balance==1000)
    	{
	    	command(0x80);
	    	lcd_dis("GAS BOOKING.....");
	    	if(x==1){x=0;gsm1();}
	    }
}		
}
void ext_init(void)
{
	GIE = 1;
	PEIE = 1;
	INTE = 1;
	RBIE = 0;
	INTEDG = 1;	// PUT PULL UP	
	
}
void interrupt external(void)
{
	if(INTF)
	{
		INTF = 0;
		count++;
	}
}
void gsm(void)
{	
	uart_con_out("AT+CMGS=");
	uart_out('"');
	uart_con_out("9790411167");
	uart_out('"');
	uart_out(0x0A);
	uart_out(0x0D);
	delay(10000);
	uart_con_out("GAS REACHED INTERMEDIATE LEVEL");						// Your Messgae
	time(2);
	uart_out(0x1A);
	uart_out(0x0A);
	uart_out(0x0D);
	command(0x80); lcd_dis("Message Sent    ");	
	time(20);
	command(0x80);
	lcd_dis("LESS THAN HALF  ");
}
void gsm1(void)
{	
	uart_con_out("AT+CMGS=");
	uart_out('"');
	uart_con_out("9790411167");
	uart_out('"');
	uart_out(0x0A);
	uart_out(0x0D);
	delay(10000);
	uart_con_out("GAS BOOKED.......");						// Your Messgae
	time(2);
	uart_out(0x1A);
	uart_out(0x0A);
	uart_out(0x0D);
	
	uart_con_out("AT+CMGS=");
	uart_out('"');
	uart_con_out("9042961368");
	uart_out('"');
	uart_out(0x0A);
	uart_out(0x0D);
	delay(10000);
	uart_con_out("IOB 85968");						// Your Messgae
	time(2);
	uart_out(0x1A);
	uart_out(0x0A);
	uart_out(0x0D);
	command(0x80); lcd_dis("Message Sent    ");	
	time(20);
	command(0x80);
	lcd_dis("GAS BOOKED......");
}
void uart_init(void)
{
	 SPBRG = 25;         // for 9600 baud rate
	 BRGH = 1;		     // baud rate high
	 SYNC = 0;		     // asynchronous mode
	 SPEN = 1;		     // serial port enable
	 TXEN = 1;		     // tx enable
}


void uart_out(unsigned char a)
{
    TXREG=a;
    delay(1000);
    while(!TXIF);
    TXIF = 0;
}
void uart_con_out(unsigned char *word)
{
	while(*word)
	{
		uart_out(*(word)++);
	}	
		delay(6000);
	
}	
void time(unsigned int x)
{
	while(x--){__delay_ms(100);}
}	