/*
===============================================================
Copyright   : Sirius Techno Solution
Author      : R.Nishanth
Description : Cardiac Alerting System
MCU         : PIC16F877A
===============================================================
*/
#include<pic.h>
#include"lcd.h"

#define trig RB1	
#define echo RB2

#define _XTAL_FREQ 4e6
__CONFIG(0x3F71);

#define IN1  RB4
#define IN2  RB5
#define IN3  RB6
#define IN4  RB7


#define IR  RB3
#define Buzzer RB6

unsigned int count = 0,count1 = 0,dist = 0,sonar,  sec = 0, min = 0, x = 1;

void delay_sec(unsigned int);
void Forward(void);
void Reverse(void);
void Left(void);
void Right(void);

void main()
{
		TRISB = 0x0D;
		PORTB = 0x00;
		RBPU = 0;
		lcd_init();

		
		command(0x80);
		lcd_dis("HEARTBEAT BASED ");
		command(0xC0);
		lcd_dis("DRIVER ALERT SYS");
		delay_sec(2);
		command(0x01);

	while(1)
	{


		if(RC0==1)
			{
				while(1)
				{
				command(0x80);lcd_dis("Emergency.......");
				if(IR){Forward();}
				else
				{
				if(x==1)
				{
				Forward();
				delay_sec(2);
				Left();
				__delay_ms(100);__delay_ms(100);__delay_ms(100);__delay_ms(100);__delay_ms(100);
				Forward();delay_sec(5);Right();
				__delay_ms(100);__delay_ms(100);__delay_ms(100);
				Forward();
				delay_sec(2);
				IN1=IN2=IN3=IN4=0;
				x=0;
				}
				}
				}

			}
		else
			{
				if(RC1 == 1 && RC3 == 0&& RC2 == 0 ){Forward();command(0x80);lcd_dis("VEHICLE FORWARD ");}
				else if(RC3 == 0 && RC2 == 1 && RC1 == 0){Reverse();command(0x80);lcd_dis("VEHICLE REVERSE ");}
				else if(RC3 == 1 && RC1 == 1){Left();command(0x80);lcd_dis("VEHICLE LEFT    ");}
				else if(RC1 == 1 && RC2 == 1){Right();command(0x80);lcd_dis("VEHICLE RIGHT   ");}
				else if(RC1 == 0 && RC2 == 0 && RC2 == 0 && RC3 == 0){IN1=IN2=IN3=IN4=0;command(0x80);lcd_dis("VEHICLE STAND   ");}
			
			}

	}		
}

void Forward(void)
{
	IN1=IN3=1;
	IN2=IN4=0;
	command(0xCF);
	write('F');
}
void Right(void)
{
	IN1=0;IN3=1;
	IN2=1;IN4=0;
	command(0xCF);
	write('L');
}
void Left(void)
{
	IN1=1;IN3=0;
	IN2=0;IN4=1;
	command(0xCF);
	write('W');
}
void Reverse(void)
{
	IN1=0;IN3=0;
	IN2=1;IN4=1;
	command(0xCF);
	write('R');
}

	
void ultrasonic()
{
	trig = 0; delay(1000);
	trig = 1; delay(1000);
	trig = 0;
	while(!echo) sonar = 0;	
	while(echo) sonar++;
	dist = sonar / 5;
}	

void delay_sec(unsigned int y)	
{
	y = y * 10; 
	while(y--){__delay_ms(100);}
}	