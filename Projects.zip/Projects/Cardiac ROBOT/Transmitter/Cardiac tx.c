/*
===============================================================
Copyright   : Sirius Techno Solution
Author      : R.Nishanth
Description : Cardiac Transmitter
MCU         : PIC16F877A
===============================================================
*/
#include<pic.h>
#include"lcd.h"

#define Forward RB1
#define Backward RB2
#define Left RB3
#define Right RB4
#define Emg RB5


#define _XTAL_FREQ 4e6
__CONFIG(0x3F71);



unsigned int count = 0,count1 = 0,dist = 0,sonar,  sec = 0, min = 0, x, y,i;
void init_int(void);
void uart_init();
void ser_out(unsigned int a);
void ser_con_out(const unsigned char *word,unsigned int n);
void delay_sec(unsigned int);



void main()
{
		TRISB = 0xFF;
		PORTB = 0x00;
		RBPU = 1;
		lcd_init();

		
		command(0x80);
		lcd_dis("HEARTBEAT BASED ");
		command(0xC0);
		lcd_dis("DRIVER ALERT SYS");
		delay_sec(2);
		command(0x01);
		command(0x80);
		lcd_dis("HEARTBEAT ");
		command(0xc0);
		lcd_dis("000 BPM");
		command(0x8B);
		lcd_dis("SEC");
		init_int();
		uart_init();
		
		ser_con_out("AT",2);
		ser_out(0x0A);ser_out(0x0D);
		delay_sec(1);
		ser_con_out("AT+CMGF=1",9);
		ser_out(0x0A);ser_out(0x0D);
		delay_sec(1);

	while(1)
	{
		 
		 if(sec>=10)
		 {
		 command(0xC0);
		 htd3(count1);	 
		 sec = 0;
		 x = count1;
		 count1=0;
		 }

		if(x>=10 || Emg==0)
			{
			RC0 = 1;
			ser_con_out("AT+CMGS=",8);
			ser_out('"');ser_con_out("8760660129",10);ser_out('"');
			ser_out(0x0A);ser_out(0x0D);
			delay_sec(2);
			ser_con_out("Emergency",9);
			ser_out(0x0A);ser_out(0x0D);
			delay_sec(1);
			ser_con_out("HEARTBEAT:",10);
			ser_out(' ');
			ser_out(x/10 + '0');ser_out(x%10 + '0');
			ser_out(0x1A);ser_out(0x0A);ser_out(0x0D);
			
			}
		else
			{
			if(Forward==0){PORTC = 0x02;command(0xCF);write('F');}else{PORTC = 0x00;}
			if(Backward==0){PORTC = 0x04;command(0xCF);write('B');}else{PORTC = 0x00;}
			if(Left==0){PORTC = 0x0A;command(0xCF);write('L');}else{PORTC = 0x00;}
			if(Right==0){PORTC = 0x06;command(0xCF);write('R');}else{PORTC = 0x00;}
			}

	}		
}

	void init_int()
	{
	T0CS=0;
	GIE=1;         //ENABLE GLOBAL INTERRUPT
	INTEDG = 0;
	INTE = 1;
	PEIE=1;         //ENABLE PERIPHERAL INTERRUPT
	TMR0IE=1;      //ENABLE TIMER0 INTERRUPT
	OPTION=0x07;      //PRESCALAR VALUE 256
	TMR0 = 0xD8;;      //TIMER REGISTER SET FOR 10ms
   
	}
	void uart_init()
{
	 SPBRG = 25;         // for 9600 baud rate
	 BRGH = 1;		     // baud rate high
	 SYNC = 0;		     // asynchronous mode
	 SPEN = 1;		     // serial port enable
	 TXEN = 1;		     // tx enable
}

 void ser_con_out(const unsigned char *word,unsigned int n)
{
	for(i=0;i<n;i++)
	{
		ser_out(word[i]); 
		delay(6000);
	}
}		


void ser_out(unsigned int a)
{

    TXREG=a;
    while(!TXIF);   //CONDITION TO CHECK IF THE BIT IS TRANSMITTED OR NOT
    TXIF = 0;
}  
	
void interrupt heart(void)
{
	if(INTF)
	{
		INTF = 0;
		count1++;
	}	
 if(TMR0IF==1)
   {
      TMR0IF=0;
      count++;
      if(count>=100)
      {
         count=0;sec++;
         command(0xCB);
         write(sec/10 + '0');
         write(sec%10 + '0');
         write(' ');
   
      
      }
   TMR0 = 0xD8;     //setting timer_0 interrupt once again after the previous interrupt
   }
}   	
void delay_sec(unsigned int y)	
{
	y = y * 10; 
	while(y--){__delay_ms(100);}
}	