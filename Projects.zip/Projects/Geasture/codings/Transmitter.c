/*
===============================================================
Copyright   : Sirius Techno Solution
Author      : R.Nishanth
Description : Gesture Based Robot(Transmitter)
MCU         : PIC16F877A
===============================================================
*/
#include <pic.h>      				//PIC header File
#include "lcd.h"					//LCD header File
#define _XTAL_FREQ 4e6				//Oscilator Frequency For Time Delay
__CONFIG(0X3f71);					//Configuration Register

#define GON    RB0 
#define GOFF   RB1
#define UP     RB2
#define DOWN   RB3
#define LEFT   RC6
#define RIGHT  RC7
#define SWITCH RB6

void adc();							//Functions Declaration
void time(int);
void check();

unsigned int x,y,z;					//Accelerometer Variables 
void main()
{
	lcd_init();						//LCD Initialisation
	TRISA = 0xff;
	TRISB = 0xFF;
	RBPU = 1;

	command(0x80); lcd_dis("Acc",3);
	
	
	while(1)
	{
		adc();
		time(2);
		if(SWITCH==1){check();}	
		else
		{
		if(GON==0){command(0x80);lcd_dis("GON  ",5);PORTC = 0x0C;}
		else if(GOFF==0){command(0x80);lcd_dis("G0FF ",5);PORTC = 0x3;}
		else if(UP==0){command(0x80);lcd_dis("UP   ",5);PORTC = 0x06;}  
		else if(DOWN==0){command(0x80);lcd_dis("DOWN ",5);PORTC = 0x05;}
		else if(LEFT==0){command(0x80);lcd_dis("GLEFT",5);PORTC = 0x09;}
		else if(RIGHT==0){command(0x80);lcd_dis("GRIGH",5);PORTC = 0x0A;}
		else{PORTC = 0;command(0x80);lcd_dis("     ",5);}
		}
	}
}

void adc()
{
	ADCON0 = 0x0D;
	ADCON1 = 0xC0;
	//while(!ADGO);
	x = ((256 * ADRESH) + ADRESL);
	command(0xC0); lcd_dis("X:",2);
	command(0xC2); htd3(x);

	ADCON0 = 0x15;
	ADCON1 = 0xC0;
	//while(!ADGO);
	y = ((256 * ADRESH) + ADRESL);
	command(0xC5); lcd_dis("Y:",2);
	command(0xC7); htd3(y);

	ADCON0 = 0x1D;
	ADCON1 = 0xC0;
	//while(!ADGO);
	z = ((256 * ADRESH) + ADRESL);
	command(0xCA); lcd_dis("Z:",2);
	command(0xCC); htd3(z);
	
}

void check()
{
	if((x>=340 & x<=380) && (y>=330 & y<=410) && (z>=330 & z<=380) ){command(0x80);lcd_dis("FWD  ",5);PORTC = 0x08;}
	else if((x>=360 & x<=380) && (y>=340 & y<=390) && (z>=280 & z<=320) ){command(0x80);lcd_dis("REV  ",5);PORTC = 0x04;}
	else if((x>=380 & x<=410) && (y>=350 & y<=380) && (z>=330 & z<=380) ){command(0x80);lcd_dis("LEFT ",5);PORTC = 0x02;}
	else if((x>=280 & x<=310) && (y>=340 & y<=380) && (z>=300 & z<=350) ){command(0x80);lcd_dis("RIGHT",5);PORTC = 0x01;}
	else{command(0x80);lcd_dis("STAND",5);PORTC = 0x00;}
	
}
void time(int a)
{
	while(a--)
	{
		__delay_ms(100);
	}
}