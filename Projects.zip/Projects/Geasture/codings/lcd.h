/*
=================================================================
Description : Character LCD Driver
MCU		 	: PIC16F877A
=================================================================
*/

#define rs  RC4
#define en  RC5
/*---------------------------------------- ---------*/

void lcd_init(void);
void command(unsigned char);
void write(unsigned char);
void lcd_dis(const unsigned char *,unsigned int);
void delay(unsigned int);
void hdelay(void);
void htd2(unsigned int);
void htd3(unsigned int);
void htd4(unsigned int);
void float2String(float val);
/*-------------------------------------------------*/

void lcd_init()
{

	TRISD = 0;
	TRISC = 0xC0;
	
	command(0x38);		// to select function set
	command(0x06);		// entry mode set
	command(0x0c);		// display on
	command(0x01);		// clear display
}
/*-------------------------------------------------*/

void command(unsigned char com)
{
	PORTD = com;
	en = 1;
	rs = 0;
	delay(125);
	en = 0;
	delay(125);
}
/*-------------------------------------------------*/

void write(unsigned char lr)
{
	PORTD = lr;
	en = 1;
	rs = 1;
	delay(125);
	en = 0;
	delay(125);
}
/*-------------------------------------------------*/

void lcd_dis(const unsigned char *word, unsigned int n)
{
	unsigned char i;
	for(i = 0; i < n; i++)
	{ 
		write(word[i]);
  	}
}
/*-------------------------------------------------*/

void delay(unsigned int del)
{
	while(del--);
}
/*-------------------------------------------------*/

void hdelay()
{
	delay(65000);
	delay(65000);
}
/*-------------------------------------------------*/

void htd2(unsigned int val)
{
	write((val / 10) + '0');
	write((val % 10) + '0');
}
/*-------------------------------------------------*/

void htd3(unsigned int val)
{
	unsigned int a, b, c, d;

	a = val / 100;
	b = val % 100;
	c = b / 10;
	d = b % 10;

	write(a + '0');
	write(c + '0');
	write(d + '0');
}
/*-------------------------------------------------*/

void htd4(unsigned int val)
{
	unsigned int a, b, c, d, e, f;

	a = val / 1000;
	b = val % 1000;
	c = b / 100;
	d = b % 100;
	e = d / 10;
	f = d % 10;

	write(a + '0');
	write(c + '0');
	write(e + '0');
	write(f + '0');
}
/*-------------------------------------------------*/
void float2String(float val)
{
	unsigned int  b, c, d, e, f, g;
	float a;
	a = val * 100; 			// 5.00*100 500 

	b = (int)a / 100; 		//5	
	c = (int)a  % 100;		//00
	d = c / 10;			//5
	e = c % 10;			//00
	//f = e / 10;				//0
	//g = e % 10;				//0
	write(b + '0');
	//write(d + '0');
	write('.');
	write(d + '0');
	write(e + '0');
	
}