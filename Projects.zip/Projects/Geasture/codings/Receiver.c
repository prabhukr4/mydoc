/*
===============================================================
Copyright   : Sirius Techno Solution
Author      : R.Nishanth
Description : Gesture Based Robot(Receiver
MCU         : PIC16F877A
===============================================================
*/
#include <pic.h>      				//PIC header File
#include "lcd.h"					//LCD header File

#define IN0 RB0	//Forward Reverse
#define IN1 RB1
#define IN2 RB2
#define IN3 RB3


#define IN4 RB4		// GON and GOFF
#define IN5 RB5
#define IN6 RB6		//UP and DOWN
#define IN7 RB7

#define IN8 RC6		// LEFT and RIGHT
#define IN9 RC7

#define _XTAL_FREQ 4e6				//Oscilator Frequency For Time Delay
__CONFIG(0X3f71);					//Configuration Register

void time(int);
void PWM_init();

unsigned int x,y,z;					//Accelerometer Variables 
void main()
{
	lcd_init();						//LCD Initialisation
	//PWM_init();
	TRISA = 0x00;
	TRISB = 0x00;
	PORTB = 0x00;

	command(0x80); lcd_dis("Acc",3);
	IN0 = IN1 = IN2 = IN3 = IN4 = IN5 = IN6 = IN7 = IN8 = IN9 = 0;
	while(1)
	{
		

		if(RC3 == 1 && RC2==0 && RC1 == 0 && RC0==0){command(0x80);lcd_dis("FORWARD", 7);IN0=IN2=0;IN1=IN3=1;}
		else if(RC3 == 0 && RC2==1 && RC1 == 0 && RC0==0){command(0x80);lcd_dis("REVERSE", 7);IN0=IN2=1;IN1=IN3=0;}
		else if(RC3 == 0 && RC2==0 && RC1 == 1 && RC0==0){command(0x80);lcd_dis("LEFT   ", 7);IN0=1;IN2=0;IN1=0;IN3=1;}
		else if(RC3 == 0 && RC2==0 && RC1 == 0 && RC0==1){command(0x80);lcd_dis("RIGHT  ", 7);IN0=0;IN2=1;IN1=1;IN3=0;}
		else if(RC3 == 1 && RC2 == 1 && RC1 == 0 &&  RC0 == 0){command(0x80);lcd_dis("GON    ", 7);IN4=0;IN5=1;}
		else if(RC3 == 0 && RC2 == 0 && RC1 == 1 && RC0 == 1){command(0x80);lcd_dis("GOFF   ", 7);IN4=1;IN5=0;}
		else if(RC3 == 0 && RC2 == 1 && RC1 == 1 &&  RC0 == 0){command(0x80);lcd_dis("UP     ", 7);IN6=0;IN7=1;}
		else if(RC3 == 0 && RC2 == 1 && RC1 == 0 && RC0 == 1){command(0x80);lcd_dis("DOWN   ", 7);IN6=1;IN7=0;}
		else if(RC3 == 1 && RC2 == 0 && RC1 == 0 && RC0 == 1){command(0x80);lcd_dis("GLEFT  ", 7);IN8=0;IN9=1;}
		else if(RC3 == 1 && RC2 == 0 && RC1 == 1 && RC0 == 0){command(0x80);lcd_dis("GRIGHT ", 7);IN8=1;IN9=0;}
		else{command(0x80);lcd_dis("STAND  ", 7);IN0=0;IN2=0;IN1=0;IN3=0;IN4=0;IN5=0;IN6=0;IN7=0;IN8=0;IN9=0;}
		
	}
}


void time(int a)
{
	while(a--)
	{
		__delay_ms(100);
	}
}
void PWM_init()
{

	/*~~~~~~~ TIMER 2 and PWM ~~~~~~*/
	
	GIE = 1;
	PEIE = 1;
	T2CON = 0x05;
	TMR2IE = 1;
	PR2 = 0xF9;
	CCP1CON = 0x0c;
	CCPR1L = 0;
}
void interrupt tmr2(void)
{
	if(TMR2IF == 1)
	{
		TMR2IF = 0;
	}
}