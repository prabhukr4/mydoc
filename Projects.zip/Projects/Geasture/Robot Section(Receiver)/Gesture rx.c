/*
=======================================================================
Copyright   : Sirius Techno Solution

Author      : R.PRABHU

Description : GEASTURE BASED ROBOT CONTORL (RECEIVER-ROBOT SECTION)

MCU         : PIC16F877A

=======================================================================
*/

#include<pic.h>
#include "lcd.h"
#define _XTAL_FREQ 4e6
__CONFIG(0x3f71);

#define IN1 RB0
#define IN2 RB1
#define IN3 RB2
#define IN4 RB3
#define IN5 RB4
#define IN6 RB5
#define IN7 RB6
#define IN8 RB7
#define lift RC6

void init();
void receiver();
void fwd();
void rev();
void left();
void stop();
void right();
void gibberLEFT();
void gibberRIGHT();
void gibberRELESE();
void gibberLOCK();
void time(int);

/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ MAIN FUNCTION  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

void main()
{
	init();
//	command(0x80); lcd_dis("  GESTURE BASED ",16);
//	command(0xC0); lcd_dis(" ROBOT (RX SIDE)",16);
//	time(20);
	command(0x01);
	command(0xC0); lcd_dis("    CITY ROBO    ",16);
	while(1)
	{
		receiver();
	}
}

void init()
{
	TRISB = 0x00;
	PORTB = 0x00;
	lcd_init();
	RC6 = 0;
}

/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ RECEIVING FROM RF RECEIVER ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

void receiver()
{
	
	if(RC3 == 0 && RC2 == 0 && RC1 == 0 && RC0 == 0)		// 0001	 STOP
	{
		command(0x80); lcd_dis("STAND",5);
		stop();		
		while(RC3 == 0 && RC2 == 0 && RC1 == 0 && RC0 == 0); 
		PORTB = 0;
		command(0x80); lcd_dis("     ",5);
	}
	
	if(RC3 == 0 && RC2 == 0 && RC1 == 0 && RC0 == 1)		// 0001	FORWARD
	{
		command(0x80); lcd_dis("FWD  ",5);
		fwd();
		while(RC3 == 0 && RC2 == 0 && RC1 == 0 && RC0 == 1);
		PORTB = 0;
		command(0x80); lcd_dis("     ",5);
	}
	
	if(RC3 == 0 && RC2 == 0 && RC1 == 1 && RC0 == 0)		// 0010	REVERSE
	{
		command(0x80); lcd_dis("REV  ",5);
		rev();
		while(RC3 == 0 && RC2 == 0 && RC1 == 1 && RC0 == 0);
		PORTB = 0;
		command(0x80); lcd_dis("     ",5);
	}
	
	if(RC3 == 0 && RC2 == 0 && RC1 == 1 && RC0 == 1)		// 0011	LEFT
	{
		command(0x80); lcd_dis("LEFT ",5);
		left();
		while(RC3 == 0 && RC2 == 0 && RC1 == 1 && RC0 == 1);
		PORTB = 0;
		command(0x80); lcd_dis("     ",5);
	}
	
	if(RC3 == 0 && RC2 == 1 && RC1 == 0 && RC0 == 0)		// 0100	RIGHT
	{
		right();
		command(0x80); lcd_dis("RIGHT",5);
		while(RC3 == 0 && RC2 == 1 && RC1 == 0 && RC0 == 0);
		PORTB = 0;
		command(0x80); lcd_dis("     ",5);
	}
	
	if(RC3 == 0 && RC2 == 1 && RC1 == 0 && RC0 == 1)		// 0101	Gibber LEFT
	{
		gibberLEFT();
		command(0x86); lcd_dis("Gib.LEFT  ",10);
		while(RC3 == 0 && RC2 == 1 && RC1 == 0 && RC0 == 1);
		PORTB = 0;
		command(0x86); lcd_dis("          ",10);
	}
	
	if(RC3 == 0 && RC2 == 1 && RC1 == 1 && RC0 == 0)		// 0110	Gibber RIGHT
	{
		command(0x86); lcd_dis("Gib.RIGHT ",10);
		gibberRIGHT();
		while(RC3 == 0 && RC2 == 1 && RC1 == 1 && RC0 == 1);
		PORTB = 0;
		command(0x86); lcd_dis("          ",10);
	}
	
	if(RC3 == 0 && RC2 == 1 && RC1 == 1 && RC0 == 1)		// 0111	Gibber RELESE
	{
		command(0x86); lcd_dis("Gib.RELESE",10);
		gibberRELESE();
		while(RC3 == 0 && RC2 == 1 && RC1 == 1 && RC0 == 1);
		PORTB = 0;
		command(0x86); lcd_dis("          ",10);
	}
	
	if(RC3 == 1 && RC2 == 0 && RC1 == 0 && RC0 == 0)		// 1000	Gibber LOCK
	{
		command(0x86); lcd_dis("Gib.LOCK  ",10);
		gibberLOCK();
		while(RC3 == 1 && RC2 == 0 && RC1 == 0 && RC0 == 0);
		PORTB = 0;
		command(0x86); lcd_dis("          ",10);
	}
	
	if(RC3 == 1 && RC2 == 0 && RC1 == 0 && RC0 == 1)		// 1001	Gibber LIFT(Up/Down)
	{
		command(0x86); lcd_dis("Gib.LIFT  ",10);
		lift = 1;
		while(RC3 == 1 && RC2 == 0 && RC1 == 0 && RC0 == 1);
		lift = 0;
	}
	
}

/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ FUNCTION EXTRACTION ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

void fwd()
{
	IN1 = 0; IN2 = 1;
	IN3 = 0; IN4 = 1;
}

void rev()
{
	IN1 = 1; IN2 = 0;
	IN3 = 1; IN4 = 0;
}

void left()
{
	IN1 = 1; IN2 = 0;
	IN3 = 0; IN4 = 1;
}

void stop()
{
	IN1 = 0; IN2 = 0;
	IN3 = 0; IN4 = 0;
}

void right()
{
	IN1 = 0; IN2 = 1;
	IN3 = 1; IN4 = 0;
}

void gibberLEFT()
{
	IN5 = 0; IN6 = 1;
}

void gibberRIGHT()
{
	IN5 = 1; IN6 = 0;
}

void gibberRELESE()
{
	IN7 = 0; IN8 = 1;
}

void gibberLOCK()
{
	IN7 = 1; IN8 = 0;
}


/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ TIME DELAY ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

void time(int a)
{
	while(a--)
	{
		__delay_ms(100);
	}
}

/* ~~~~~~~~~~~~~~~~~~~~~~~~~~ END ~~~~~~~~~~~~~~ END ~~~~~~~~~~~~~~~~ END ~~~~~~~~~~~~~~~~~~~~~~~~ */