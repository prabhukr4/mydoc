 #include<REGx51.h>
#include"LCD1.h"
unsigned char RFID[10],gear[10], i=0;
void serial_init()
{
	IE = 0x90;
	TMOD = 0x20;
	TH1  = 0xFD;
	SCON = 0x50;
	TL1  = 0xFD;
	TR1  = 1;
}			
void uart_out(unsigned char dat)
{
	SBUF = dat;
	while(!TI);
	TI = 0;
	delay(100);
	
	
}
void serial_read() interrupt 4
{
   if(!RI)
   {
TI = 0;
    }
	else
	{
	RI = 0;
	RFID[i] = SBUF;
	SBUF = RFID[i]; 
	i++;
	//if(i==8){i=0;}
	}
	
 } 


void main()
{	
	char x, t;
	P2_0 = 0;
	lcd_init();
	serial_init();
	command(0x80);
	lcd_dis("Gear Locking SYS", 16);
	while(1)
	{
	if(i>=7)
	{
	for(t=0; t<8;t++)
	{
	gear[t] = RFID[t];
	}
	if(RFID[4]== '0' && RFID[5]== '3' && RFID[6]== '4' && RFID[7] == '6' )
	{
	P2_0 = 1;
	command(0xC0);
	lcd_dis("Authenticated", 13);
	}
	else
	{
	P2_0 = 0;
	command(0xC0);
	lcd_dis("NO ACCESS    ", 13);
	}
	delay(500);
	i = 0;
	}

	}
}