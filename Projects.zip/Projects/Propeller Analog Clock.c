#include <reg52.h>

  int i=0;
void delay_ms(unsigned int k) //delay in milliseconds for 11.0592MHz crystal
{                                            //E.g. delay_ms(100)

unsigned int i,j;
for(i=0;i<k;i++)
{
for(j=0;j<1275;j++); }
}
const unsigned char code flook [][5] =

{

{ 0x3E, 0x51, 0x49, 0x45, 0x3E }, // 0

{ 0x00, 0x42, 0x7F, 0x40, 0x00 }, // 1

{ 0x42, 0x61, 0x51, 0x49, 0x46 }, // 2

{ 0x21, 0x41, 0x45, 0x4B, 0x31 }, // 3      

{ 0x18, 0x14, 0x12, 0x7F, 0x10 }, // 4

{ 0x27, 0x45, 0x45, 0x45, 0x39 }, // 5

{ 0x3C, 0x4A, 0x49, 0x49, 0x30 }, // 6

{ 0x01, 0x71, 0x09, 0x05, 0x03 }, // 7

{ 0x36, 0x49, 0x49, 0x49, 0x36 }, // 8

{ 0x06, 0x49, 0x49, 0x29, 0x1E } // 9

};
/*------------------------------------------------
Timer 0 Interrupt Service Routine.

Set a breakpoint on 'overflow_count++' and run the
program in the debugger.  You will see this line
executes every 65536 clock cycles.
------------------------------------------------*/
static unsigned long overflow_count = 0, sec, min, hour;

void timer0_ISR (void) interrupt 1
{
overflow_count++;
	if(overflow_count>=13)
	{
	sec++;
	overflow_count = 0;
	}
}

/*------------------------------------------------
MAIN C function
------------------------------------------------*/
void main (void)
{

/*--------------------------------------
Set Timer0 for 16-bit timer mode.  The
timer counts to 65535, overflows, and
generates an interrupt.

Set the Timer0 Run control bit.
--------------------------------------*/
	TMOD = (TMOD & 0xF0) | 0x01;   /* Set T/C0 Mode */
	TL0 = 0;        // Clear
    TH0 = 0;        // Reg's.
    TR0 = 1;        // Set timer to run.
    ET0 = 1;        // Set interrupt.
    EA = 1;            // Set global interrupt.

    while (1)
        {
		P0 = flook [1][i];
		i++;
		if(i>=5){i = 0;}
        }
    }
 