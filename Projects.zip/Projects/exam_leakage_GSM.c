#include<pic.h>
#include"lcd.h"
#include "uart.h"
#define _XTAL_FREQ 4e6
__CONFIG(0x3F71);

#define vib RB0
#define lock RC1
#define Buzzer RC0

void time(int);
void serial(char word);
void gsm();
unsigned char data_rx[10];
unsigned int x=0,i=0,a;


void main()
{
	lcd_init();
	uart_init();
	PORTB = 0x01;
	lock = 1;
	command(0x80);lcd_dis("SECURITY SYSTEM ",16);
	command(0xC0);lcd_dis("   USING GSM    ",16);
	time(20);
	uart_con_out("AT",2);
	uart_out(0x0A);
	uart_out(0x0D);
	delay(65000); time(20);
	uart_con_out("AT+CMGF=1",9);
	uart_out(0x0A);
	uart_out(0x0D);
	delay(65000);
	delay(65000); 
	command(0x01);
	command(0x80); lcd_dis(" Secured System ",16);
	
	while(1)
	{
		loop:;
		if(x)
		{
		if((data_rx[2] == '1') && (data_rx[3] == '1') && (data_rx[4] == '8') && (data_rx[5] == '8'))
		{
			lock = 0;
			command(0xC0); lcd_dis("Authentication  ",16);
			goto loop;
		}
	
		else 
		{
			Buzzer = 0; 
			lock = 1;
			command(0xC0); lcd_dis("No Access       ",16);
		}
		x=0;i=0;
		}
		if(vib == 0)
		{
			Buzzer = 1;
			command(0xC0); lcd_dis("     Alert      ",16);
			gsm();
			time(10);
			command(0xC0); lcd_dis("Message Sent    ",16);
			time(20);
			
		}
		else 
		{
			Buzzer = 0; 
			command(0xC0); lcd_dis("No Access       ",16);
		}				 	
	}
	
}

void gsm()
{  
	
   uart_con_out("AT+CMGS=",8);
   uart_out('"');
   uart_con_out("7034734379",10);
   uart_out('"');
   uart_out(0x0A);
   uart_out(0x0D);
   delay(10000);
   uart_con_out("ALERT..!! ALERT..!! ALERT..!!",29);                  // Your Messgae
   time(2);
   uart_out(0x1A);
   time(20);
   uart_out(0x0A);
   uart_out(0x0D);
   delay(1000);
 
}


void interrupt rx(void)
{
 if(RCIF)
  {
	  RCIF=0;
	  a = RCREG;
	 serial(a);

  }
}
void serial (char word)
{
	data_rx[i]=a;
	if(i>=7){x=1;i = 0;}
	else{i++;}
	
    
}	
void time(int b)
{
	while(b--)
	{
		__delay_ms(100);
	}
}


