/*
===============================================================
Copyright   : Sirius Techno Solution
Author      : R.Nishanth
Description : ARm Based Attandance
MCU         : LPC2148
===============================================================
*/

#include<lpc214x.h>
#include"LCD(ARM).h"
#define PCLK 12000000

void uart1_init(unsigned int BAUDRATE);
void interrupt_init(void);
void interrupt_isr(void)__irq;		//INTERRUPT ROUTINE
void interrupt1_isr(void)__irq;		//INTERRUPT ROUTINE
void uart1_puts(char *p);
void uart1_putc(char a);

void uart0_init(unsigned int BAUDRATE);
void uart0_puts(char *p);
void uart0_putc(char a);
void init(void);
unsigned int x,i,y=1,j=0,g;
char ser[10],rfid[10]; 

int main()
{
	lcd_init();
	interrupt_init();
	init();
	command(0x80);lcd_dis("   ARM BASED    ",16);
	command(0xC0);lcd_dis(" ATTENDANCE SYS ",16);
	delay(1000000);	delay(1000000);
	uart1_init(9600);			//SETTING BAUD RATE
	uart0_init(9600);			//SETTING BAUD RATE
	i=0;
	uart1_puts("AT");
	uart1_putc(0x0A);uart1_putc(0x0D);
	delay(100000);
	uart1_puts("AT+CMGF=1");
	uart1_putc(0x0A);uart1_putc(0x0D);
	delay(100000);
	command(0x01);
	while(1)
	{
		command(0x80);lcd_dis("PLEASE SHOW CARD",16);
		IOPIN0 &=~(1<<15);
		
	  	while(i>=8)
		{
			command(0xC0);
			if(y==1)
			{
			y=0;
			for(i=0;i<=7;i++)
			{
				uart0_putc(rfid[i]);		//TRANSMITTING THE RECEIVED DATA
			//	write(rfid[i]);
			}
			uart0_putc(0x0A);uart0_putc(0x0D);
			}
		
			if(rfid[4]=='4' && rfid[5]=='3' && rfid[6]=='1' && rfid[7]=='6')
			{
			command(0x80);lcd_dis("Hi Sowmiya......",16);
			command(0xC0);lcd_dis("Verifying.......",16);
			}
			if(rfid[4]=='0' && rfid[5]=='4' && rfid[6]=='0' && rfid[7]=='0')
			{
			command(0x80);lcd_dis("Hi Hemalatha....",16);
			command(0xC0);lcd_dis("Verifying.......",16);
			}
			if(rfid[4]=='6' && rfid[5]=='0' && rfid[6]=='2' && rfid[7]=='3')
			{
			command(0x80);lcd_dis("Hi Nathiya......",16);
			command(0xC0);lcd_dis("Verifying.......",16);
			}
			if(rfid[4]=='8' && rfid[5]=='0' && rfid[6]=='0' && rfid[7]=='4')
			{
			command(0x80);lcd_dis("Hi Rajkumar.......",16);
			command(0xC0);lcd_dis("Verifying.......",16);
			}
			if(rfid[4]=='1' && rfid[5]=='7' && rfid[6]=='5' && rfid[7]=='3')
			{
			command(0x80);lcd_dis("Hi Jaffer.......",16);
			command(0xC0);lcd_dis("Verifying.......",16);
			}
			command(0x01);

		while(j>3)
		{
			command(0x80);lcd_dis(" ATTANDNCE DETAIL",17);

		for(g=0;g<=7;g++)
		{
		if(ser[g]=='P' && ser[g+1]=='A' && ser[g+2]=='I' && ser[g+3]=='D')	  //paid no book
		{
		command(0xC0);lcd_dis("PRESENT ", 7);
		}
		if(ser[g]=='N' && ser[g+1]=='O' && ser[g+2]=='T' && ser[g+3]=='P')	   //paid 
		{
		IOPIN0 |=(1<<15);
		command(0xC0);lcd_dis("ABSENT ", 7);
		uart1_puts("AT+CMGS=\"8682898934\"");
		uart1_putc(0x0A);uart1_putc(0x0D);
		uart1_puts("FEES NOT PAID");
		uart1_putc(0x1A);uart1_putc(0x0A);uart1_putc(0x0D);
		delay(100000);
		}

		}
			delay(1000000);	delay(1000000);	delay(1000000);	delay(1000000);
				delay(1000000);	delay(1000000);	delay(1000000);	delay(1000000);
					delay(1000000);	delay(1000000);	delay(1000000);	delay(1000000);
						command(0x01);
					
			i=0;
			j=0;
			x=0;
		}
		

	}
}
}

void uart1_init(unsigned int BAUDRATE)
{
	unsigned int U1DL;
	PCONP|=(1<<4);				//POWER CONTROL FOR UART1
	U1DL=PCLK/(16*BAUDRATE);	//U1DLL CALCULATION
	U1LCR=0x83;					//8 bit data,1 stop bit,no parity bit, DLAB=1   --Line control reg
	U1DLL=(U1DL & 0XFF);		//PLACING VALUES IN U0DLL
	U1DLM=(U1DL>>8);			//FOR HIGH BIT
	U1LCR=0x03;					// DLAB =0

}
void uart0_init(unsigned int BAUDRATE)
{
	unsigned int U0DL;
	PCONP|=(1<<3);				//POWER CONTROL FOR UART1
	U0DL=PCLK/(16*BAUDRATE);	//U1DLL CALCULATION
	U0LCR=0x83;					//8 bit data,1 stop bit,no parity bit, DLAB=1   --Line control reg
	U0DLL=(U0DL & 0XFF);		//PLACING VALUES IN U0DLL
	U0DLM=(U0DL>>8);			//FOR HIGH BIT
	U0LCR=0x03;					// DLAB =0

}
void interrupt_init(void)
{
	VICVectCntl0=0x20|6;						//6---->UART 0
	VICVectAddr0=(unsigned)interrupt_isr;		//ADDRESS OF THE INTERRUPT SLOT	
	VICIntEnable|=(1<<6);						//UART 0
	U0IER=0x01;									//UART 0 INTERRUPT ENABLE REGISTER


	VICVectCntl1=0x20|7;						//6---->UART 1
	VICVectAddr1=(unsigned)interrupt1_isr;		//ADDRESS OF THE INTERRUPT SLOT	
	VICIntEnable|=(1<<7);						//UART 1
	U1IER=0x01;									//UART 1 INTERRUPT ENABLE REGISTER
}
void interrupt_isr(void)__irq
{
	ser[j]=U0RBR;
	j++;
	U0IER=0x01;	
	VICVectAddr = 0x0; 							// Acknowledge that ISR has finished execution

}
void interrupt1_isr(void)__irq
{
	rfid[i]=U1RBR;
	i++;
	U1IER=0x01;	
	VICVectAddr = 0x0; 							// Acknowledge that ISR has finished execution
	

}	
void uart0_puts(char *p)		 				// Point to character
{
	while(*p)
	{
		uart0_putc(*p++);						// Send character then point to next character
	}
}
void uart1_puts(char *p)		 				// Point to character
{
	while(*p)
	{
		uart1_putc(*p++);						// Send character then point to next character
	}
}


void uart1_putc(char a)
{
	while(!(U1LSR & 0x20));						// Wait until Uart1 ready to send character  
	U1THR = a;									// Send character(TRANSMIT HOLD REGISTER)
	delay(50000);
}

void uart0_putc(char a)
{
	while(!(U0LSR & 0x20));						// Wait until Uart1 ready to send character  
	U0THR = a;									// Send character(TRANSMIT HOLD REGISTER)
	delay(50000);
}

void init(void) 
{
   PLL0CFG=0x00;     // MSEL = 1,PSEL = 1
   PLL0FEED=0xAA;    // Feed process   
   PLL0FEED=0x55;    
  
   PLL0CON=0x1;
   PLL0FEED=0xAA;    // Feed process
   PLL0FEED=0x55;

   while(!(PLL0STAT & 0x400));   // Wait until PLL Locked
  
   PLL0CON=0x3;      // Connect the PLL as the clock source
   PLL0FEED=0xAA;    // Feed process
   PLL0FEED=0x55;
  
   MAMCR=0x2;        // Enabling MAM and setting number of clocks used for Flash memory fetch (4 cclks in this case)
   MAMTIM=0x4;
  
   VPBDIV=0x01;     // PCLK = CCLK	 
}


	
	
	