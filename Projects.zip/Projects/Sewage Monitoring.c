/*
===============================================================
Copyright   : Sirius Techno Solution
Author      : R.Nishanth
Description : Sewage Monitoring System
MCU         : PIC 16F877A
===============================================================
*/

#include<pic.h>
#include "lcd.h"
#include "uart.h"
#define _XTAL_FREQ 4e6
__CONFIG(0x3F71);

unsigned int Temp, Temperature,gas;
#define Gas 	RB0
#define Buzzer 	RC0
#define	Relay	RC1

void temp_sensor_init(void);
void gas_sensor_init(void);
void delay_sec(int);

void main()
{
	TRISA = 0xFF;
	TRISB = 0x01;
	TRISC = 0x04;
	PORTB=0;
	ADCON0 = 0x05;
	ADCON1 = 0xC0;
	ADRESL = 0x00;
	ADRESH = 0x00;
	RBPU = 1;
	Relay=1;
	Buzzer = 0;
	
	lcd_init();
	uart_init();
	command(0x80);
	lcd_dis(" SEWAGE MONITOR ",16);
	command(0xC0);
	lcd_dis("     SYSTEM     ",16);
	delay_sec(1);
	uart_con_out("--------------------------------",32);	
	uart_out(0x0A);
	uart_out(0x0D);
	uart_con_out("  SEWAGE GAS MONITORING SYSTEM  ",32);
	uart_out(0x0A);
	uart_out(0x0D);
	uart_con_out("--------------------------------",32);
	uart_out(0x0A);
	uart_out(0x0D);
	uart_out(0x0A);
	uart_out(0x0D);
	command(0x01);
	command(0x80);
	lcd_dis("Temp = ",7);
	command(0xC0);
 lcd_dis("Gas  = ",7);
	while(1)
	{
	
		temp_sensor_init();


		if(Temperature>=50)
		{
			uart_con_out("Temperature Level Exceeds",25);
			uart_out(0x0A);
			uart_out(0x0D);
		//	Buzzer = 1;
		}
	
		if(!Gas)
		{
			command(0xC7);
			lcd_dis("DangerGas",9);
			Relay = 0;
			//delay_sec(1);
			Buzzer = 1;
			uart_con_out("Dangerous Gas Detected",22);
			uart_out(0x0A);
			uart_out(0x0D);
			uart_con_out("Temperature = ",14);
			uart_hex_dec3(Temperature);
			uart_out(' ');
			uart_out('C');
			uart_out(0x0A);
			uart_out(0x0D);
			uart_out(0x0A);
			uart_out(0x0D);
			
		}
		else
		{
			command(0xC7);
			lcd_dis("No Gas   ",9);
			Relay = 1;
			Buzzer =0;
		}

	}	
}	
	
	

void temp_sensor_init(void)
{
	ADCON0=0x05;
	while(ADGO);
	Temp = (256 * ADRESH) + ADRESL;
	Temperature = Temp*0.48875;
	command(0x87);
	hex_dec3(Temperature);
	write(223);
	write('C');

}
void gas_sensor_init(void)
{
	ADCON0=0x0D;
	while(ADGO);
	gas = (256 * ADRESH) + ADRESL;
	command(0xc7);
	hex_dec3(gas);
	 

}
void delay_sec(int sec)
{
	sec = sec * 10;
	while(sec--)
	{
		__delay_ms(100);
	}	
}		