/*
===============================================================
Copyright   : Sirius Techno Solution
Author      : R.Nishanth
Description : Train
MCU         : PIC16F877A
===============================================================
*/

#include<pic.h>
#include "lcd.h"
#define _XTAL_FREQ 4e6
__CONFIG(0x3f71);

#define IR1	RB6
#define IR2	RB7
#define IN 	RB4
#define OUT	RB5

#define IN1 RC0
#define IN2 RC1

void time(int);
void delay_sec(int);
void uart_init();
void ser_out(unsigned int a);
void ser_con_out(const unsigned char *word,unsigned int n);
void gsm();
void gsm_send(void);
void gsm_rx(void);

unsigned char data[95], send[9]=0;
int i=0, j = 0,g,y = 0,x = 1,rxcount = 0,count=0, sec=0, h = 0;

void main()
{
	lcd_init();
	uart_init();
	TRISB = 0xFF;
	IN1 = IN2 = 1;
	command(0x80); lcd_dis("WSN BASED TRACK ");
	command(0xC0); lcd_dis("MONITORING SYS  ");
	time(20);
	command(0x01);
	command(0x80); lcd_dis("MONITORING      ");
	
	ser_con_out("AT",2);
	ser_out(0x0A);ser_out(0x0D);
	delay(65000);delay(65000);
	ser_con_out("AT+CMGF=1",9);
	ser_out(0x0A);ser_out(0x0D);
	delay(65000);delay(65000);
	ser_con_out("AT+CREG=2",9);ser_out(0x0a);ser_out(0x0d);
	delay(65000);
	ser_con_out("AT+CREG?",8);ser_out(0x0a);ser_out(0x0d);
	delay(65000);
	delay(65000);
	while(1)
	{
		if(IN == 0)
		{
			command(0xC0); lcd_dis("TRAIN IN ");
			IN1 = 1; IN2 = 0;delay_sec(2);IN1 = 0; IN2 = 0;
			while(OUT == 1)
			{
				if(IR1 == 0 || IR2 == 0)
				{
					command(0xC0); lcd_dis("CRACK    ");
					gsm_rx();
					gsm_send();

				}
				else
				{
					command(0xC0); lcd_dis("NO CRACK ");
				}
			}
			
			command(0xC0); lcd_dis("TRAIN OUT");IN1 = 0; IN2 = 0;delay_sec(1);IN1 = 0; IN2 = 1;delay_sec(2);
		}
			IN1 = 0; IN2 = 0;
	}
}
void gsm_send(void)
{
		ser_con_out("AT+CMGS=",8);
		ser_out('"');
		ser_con_out("9633076528",10);
		ser_out('"');
		ser_out(0x0a);ser_out(0x0d);
		delay(65000);delay(65000);delay(65000);
		ser_con_out("CRACK",5);
		delay(65000);
		ser_out(0x0a);ser_out(0x0d);
		ser_con_out("LAC:",4);
		
		for(h=0;h<=3;h++)
		{	
			ser_out(send[h]);
		}
		ser_out(0x0a);ser_out(0x0d);
		delay(65000);
		
		ser_con_out("CID:",4);
		
		for(h=4;h<=7;h++)
		{
			ser_out(send[h]);
		}
		ser_out(0x0A);ser_out(0x0D);ser_out(0x1A);
		delay(65000);
	
}	
void gsm_rx(void)
{
	delay(65000);
	ser_con_out("AT+CREG=2",9);ser_out(0x0a);ser_out(0x0d);
	delay(65000);
	ser_con_out("AT+CREG?",8);ser_out(0x0a);ser_out(0x0d);
	delay(65000);delay(65000);		
	if(rxcount >= 80)
    {
		for(g = 0; g < 95; g++)
		{
			if(data[g]=='+' && data[g+1]=='C' && data[g+2]=='R')
			{
				
				
				command(0x80);
				lcd_dis("LAC:");
				for(h=(g+12);h<=(g+15);h++)
				{
					write(data[h]);
					send[j] = data[h];
					j++;
				}
				lcd_dis("  ");
				
				delay(65000);
				command(0xC0);
				lcd_dis("CID:");
				for(h=(g+19);h<=(g+22);h++)
				{
					write(data[h]);
					send[j] = data[h];
					j++;
				}
				lcd_dis("   ");
				j = 0;
				delay(65000);
			
		delay(65000);
		rxcount=0;
		delay(65000);	
			}
		}	
		rxcount = 0;
		ser_out(0x0a); ser_out(0x0d);
	
	}


}
void uart_init()
{
	 SPBRG = 25;         // for 9600 baud rate
	 BRGH = 1;		     // baud rate high
	 SYNC = 0;		     // asynchronous mode
	 SPEN = 1;		     // serial port enable
	 TXEN = 1;		     // tx enable
	 RCIE = 1;			 // interrupt set
	 CREN = 1;		     // rx enable
	 GIE=1;
	 PEIE=1;

}
 void ser_con_out(const unsigned char *word,unsigned int n)
{
	for(i=0;i<n;i++)
	{
		ser_out(word[i]); 
		//delay(6000);
	}
}		

void ser_out(unsigned int a)
{

    TXREG=a;
    while(!TXIF);   //CONDITION TO CHECK IF THE BIT IS TRANSMITTED OR NOT
    TXIF = 0;
}

void time(int a)
{
	while(a--)
	{
		__delay_ms(100);
	}
}
void delay_sec(int a)
{
	a = a*10;
	while(a--)
	{
		__delay_ms(100);
	}
}
void interrupt message(void)
{
		if(TMR0IF==1)
	{
		TMR0IF=0;
		count++;
		if(count>=100)
		{
			count=0;sec++;
		
		}
	TMR0 = 0xD8;     //setting timer_0 interrupt once again after the previous interrupt
	}

	if(RCIF==1)
  	{
	  RCIF=0;
	  data[rxcount]=RCREG; 
      rxcount++;     
    }
}		