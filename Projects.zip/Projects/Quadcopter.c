/*
===============================================================
Copyright   : Sirius Techno Solution
Author      : R.Nishanth
Description : Quadcopter
MCU         : PIC16F877A
===============================================================
*/
#include<pic.h>
#include"lcd.h"
#define _XTAL_FREQ 4e6


#define Humidity   RB0

__CONFIG(0x3F71);


void uart_init();
void adc_conv(void);
void ser_out(unsigned int a);
void ser_con_out(const unsigned char *word,unsigned int n);
void gsm_send(void);
void delay_sec(unsigned int);
void Thamarai(unsigned int val);

unsigned char data[95], send[9]=0;
int i=0, j = 0,g,y = 0,x = 0,rxcount = 0,count=0, sec=0, h = 0, a=0,b,c,d;

void main()
{

	TRISA = 0xff;
	ADCON1 = 0xC0;
	
	lcd_init();
	uart_init();
	command(0x80);
	lcd_dis("   QUADCOPTER   ");
	command(0xC0);
	lcd_dis("     SYSTEM     ");
	ser_con_out("---",3);ser_con_out("---",3);ser_con_out("---",3);ser_con_out("---",3);ser_con_out("---",3);ser_con_out("---",3);
	ser_out(0x0A);	ser_out(0x0D);
	ser_con_out("Quad",4);ser_con_out("copter",6);ser_con_out(" system",7);
	ser_out(0x0A);	ser_out(0x0D);
	ser_con_out("---",3);ser_con_out("---",3);ser_con_out("---",3);ser_con_out("---",3);ser_con_out("---",3);ser_con_out("---",3);
	ser_out(0x0A);	ser_out(0x0D);
	delay(65000);
	delay(65000);
	command(0x01);
	command(0x80);
	lcd_dis("Humidy");
	command(0x87);
	lcd_dis("Gas");
	command(0x8C);
	lcd_dis("Temp");
	while(1)
	{
		adc_conv();
		if(x<200){command(0xC7);lcd_dis("O2 ");}else{command(0xC7);lcd_dis("CO2");}
		if(sec>=2){gsm_send();sec=0;}
		

	}	
	
}	
void uart_init()
{
	 GIE=1;
	 PEIE=1;
	 SPBRG = 25;         // for 9600 baud rate
	 BRGH = 1;		     // baud rate high
	 SYNC = 0;		     // asynchronous mode
	 SPEN = 1;		     // serial port enable
	 TXEN = 1;		     // tx enable
	 //RCIE = 1;			 // interrupt set
	 //CREN = 1;		     // rx enable
	 TMR0IE=1;			//ENABLE TIMER0 INTERRUPT
   	OPTION=0x07;			//PRESCALAR VALUE 256
    TMR0=0xD8;			//TIMER REGISTER SET FOR 10ms
}

 void ser_con_out(const unsigned char *word,unsigned int n)
{
	for(i=0;i<n;i++)
	{
		ser_out(word[i]); 
		delay(6000);
	}
}		


void ser_out(unsigned int a)
{

    TXREG=a;
    while(!TXIF);   //CONDITION TO CHECK IF THE BIT IS TRANSMITTED OR NOT
    TXIF = 0;
}  
void gsm_send(void)
{

		ser_con_out("Humidity    :",13);
		Thamarai(a);
		ser_out(' ');ser_out('%');
		ser_out(0x0a);ser_out(0x0d);
		ser_con_out("Gas         :",13);
		Thamarai(x);
		if(x<200){ser_con_out("   O2",5);}else{ser_con_out("  CO2",5);}
		ser_out(0x0a);ser_out(0x0d);
		ser_con_out("Temperature :",13);
		Thamarai(y);
		ser_out(248);ser_out('C');
		ser_out(0x0a);ser_out(0x0d);
		ser_out(0x0a);ser_out(0x0d);
		ser_out(0x0a);ser_out(0x0d);
		delay(65000);
		delay(65000);
		
	
}	
void delay_sec(unsigned int y)
{
	y = y*10;
	while(y--){__delay_ms(100);}
}
void adc_conv(void)
{
	ADCON0 = 0x05;
	while(ADGO);
	a =(256*ADRESH)+ADRESL;
	a = 102300/a;
	a = a - 100;
	command(0xc0);
	htd3(a);
	write('%');
	
	ADCON0 = 0x0D;
	while(ADGO);
	x = ((256 * ADRESH) + ADRESL);
	
	ADCON0 = 0x15;
	ADCON1 = 0xC0;
	while(ADGO);
	y = ((256 * ADRESH) + ADRESL);
	y = y*0.48818;
	command(0xCC); htd3(y);
	write('C');

}
void interrupt message(void)
{
		if(TMR0IF==1)
	{
		TMR0IF=0;
		count++;
		if(count>=100)
		{
			count=0;sec++;
		
		}
	TMR0 = 0xD8;     //setting timer_0 interrupt once again after the previous interrupt
	}
}				   
  
  void Thamarai(unsigned int val)
{
	unsigned int a, b, c, d;

	a = val / 100;
	b = val % 100;
	c = b / 10;
	d = b % 10;

	ser_out(a + '0');
	ser_out(c + '0');
	ser_out(d + '0');
}	