#include<pic.h>
#include "lcd.h"
#include "uart.h"
#define _XTAL_FREQ 4e6
__CONFIG(0x3f71);

#define	 IR_1 	RB4
#define	 IR_2 	RB5
#define	 IR_3 	RB6
#define	 IR_4 	RB7
#define Buzzer 	RC0

void time(int);

void main()
{
	lcd_init();
	uart_init();
	TRISB = 0xFF;
	command(0x80); lcd_dis("Parking Ocupancy",16);
	command(0xC0); lcd_dis("    Detection   ",16);
	uart_con_out("----------------------------------",34); uart_out(0x0A); uart_out(0x0D);
	uart_con_out("PARKING OCCUPANCY DETECTION SYSTEM",34); uart_out(0x0A); uart_out(0x0D);
	uart_con_out("----------------------------------",34); uart_out(0x0A); uart_out(0x0D);
	time(30);
	command(0x01);
	command(0x80); lcd_dis("Occ. & Available",16);
	uart_con_out("The Parking occupancies and Available Informations(Zones) are....",66);
	uart_out(0x0A); uart_out(0x0D);
	uart_out(0x0A); uart_out(0x0D);
	
	while(1)
	{
		if(IR_1==0 && IR_2==0 && IR_3==0 && IR_4==0)			//0000
		{
			command(0xC0); lcd_dis("Spaces are Empty",16);
			uart_con_out("Spaces are Empty",16);
			uart_out(0x0A); uart_out(0x0D);
			
		}
		
		else if(IR_1==0 && IR_2==0 && IR_3==0 && IR_4==1)		//0001
		{
			command(0xC0); lcd_dis("1,2&3 Available ",16);
			uart_con_out("1,2&3 Available ",16);
			uart_out(0x0A); uart_out(0x0D);
		}
		
		else if(IR_1==0 && IR_2==0 && IR_3==1 && IR_4==0)		//0010
		{
			command(0xC0); lcd_dis("1,2&4 Available ",16);
			uart_con_out("1,2&4 Available ",16);
			uart_out(0x0A); uart_out(0x0D);
		}
		
		else if(IR_1==0 && IR_2==0 && IR_3==1 && IR_4==1)		//0011
		{
			command(0xC0); lcd_dis("1 & 2 Available ",16);
			uart_con_out("1 & 2 Available ",16);
			uart_out(0x0A); uart_out(0x0D);
		}
		
		else if(IR_1==0 && IR_2==1 && IR_3==0 && IR_4==0)		//0100
		{
			command(0xC0); lcd_dis("1,3&4 Available ",16);
			uart_con_out("1,3&4 Available ",16);
			uart_out(0x0A); uart_out(0x0D);
		}
		
		else if(IR_1==0 && IR_2==1 && IR_3==0 && IR_4==1)		//0101
		{
			command(0xC0); lcd_dis("1 & 3 Available ",16);
			uart_con_out("1 & 3 Available ",16);
			uart_out(0x0A); uart_out(0x0D);
		}
		
		else if(IR_1==0 && IR_2==1 && IR_3==1 && IR_4==0)		//0110
		{
			command(0xC0); lcd_dis("1 & 4 Available ",16);
			uart_con_out("1 & 4 Available ",16);
			uart_out(0x0A); uart_out(0x0D);
		}
		
		else if(IR_1==0 && IR_2==1 && IR_3==1 && IR_4==1)		//0111
		{
			command(0xC0); lcd_dis(" 1st Available  ",16);
			uart_con_out(" 1st Available  ",16);
			uart_out(0x0A); uart_out(0x0D);
		}
		
		else if(IR_1==1 && IR_2==0 && IR_3==0 && IR_4==0)		//1000
		{
			command(0xC0); lcd_dis("2,3&4 Available ",16);
			uart_con_out("2,3&4 Available ",16);
			uart_out(0x0A); uart_out(0x0D);
		}
		
		else if(IR_1==1 && IR_2==0 && IR_3==0 && IR_4==1)		//1001
		{
			command(0xC0); lcd_dis("2 & 3 Available ",16);
			uart_con_out("2 & 3 Available ",16);
			uart_out(0x0A); uart_out(0x0D);
		}
		
		else if(IR_1==1 && IR_2==0 && IR_3==1 && IR_4==0)		//1010
		{
			command(0xC0); lcd_dis("2 & $ Available ",16);
			uart_con_out("2 & $ Available ",16);
			uart_out(0x0A); uart_out(0x0D);
		}
		
		else if(IR_1==1 && IR_2==0 && IR_3==1 && IR_4==1)		//1011
		{
			command(0xC0); lcd_dis(" 2nd Available  ",16);
			uart_con_out(" 2nd Available  ",16);
			uart_out(0x0A); uart_out(0x0D);
		}
		
		else if(IR_1==1 && IR_2==1 && IR_3==0 && IR_4==0)		//1100
		{
			command(0xC0); lcd_dis("3 & 4 Available ",16);
			uart_con_out("3 & 4 Available ",16);
			uart_out(0x0A); uart_out(0x0D);
		}
		
		else if(IR_1==1 && IR_2==1 && IR_3==0 && IR_4==1)		//1101
		{
			command(0xC0); lcd_dis(" 3rd Available  ",16);
			uart_con_out(" 3rd Available  ",16);
			uart_out(0x0A); uart_out(0x0D);
		}
		
		else if(IR_1==1 && IR_2==1 && IR_3==1 && IR_4==0)		//1110
		{
			command(0xC0); lcd_dis(" 4th Available  ",16);
			uart_con_out(" 4th Available  ",16);
			uart_out(0x0A); uart_out(0x0D);
		}
		
		else													//1111
		{
			command(0xC0); lcd_dis(" Spaces Filled  ",16);
			uart_con_out(" Spaces Filled  ",16);
			uart_out(0x0A); uart_out(0x0D);
		}
		
		
	}
}

void time(int a)
{
	while(a--)
	{
		__delay_ms(100);
	}
}