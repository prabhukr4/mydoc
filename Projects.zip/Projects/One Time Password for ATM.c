
#include<lpc214x.h>
#include"LCD(ARM).h"
#define __XTAL_FREQ 12e6
#define PCLK 12000000

#define C1 (1 << 16)
#define C2 (1 << 17)
#define C3 (1 << 18)
#define C4 (1 << 19)

#define R1 (1 << 20)
#define R2 (1 << 21)
#define R3 (1 << 22)
#define R4 (1 << 23)

void out1(char, char);
char inp1(char);

void init(void);
void interrupt_init(void);
void isr_routine(void)__irq;
void keypad(void);
void Random(void);
void Check(void);


void uart0_init(unsigned int BAUDRATE);
void uart0_puts(char *p);
void uart0_putc(char a);

void uart1_init(unsigned int BAUDRATE);
void interrupt_isr(void)__irq;		//INTERRUPT ROUTINE
void uart1_puts(char *p);
void uart1_putc(char a);
void GSM_init(void);
void GSM_send1(void);
void GSM_send2(void);
void init(void);
unsigned int y = 0, z = 0,a,i,e = 0, val1 = 0, val2 = 0, ran = 1, ran1 = 5, ran2 = 2, ran3 = 4;
unsigned char value[10];
char check[5];


unsigned int sec, count, x = 0,t = 0, u = 1, j = 0;

/*******************Main Function**************************/
int main()
{
	lcd_init();
	init();
	uart1_init(9600);  uart0_init(9600);
	interrupt_init();
	command(0x80);
	lcd_dis("     Welcome    ", 16);
	delay(1000000);delay(1000000);
	delay(1000000);delay(1000000);
	delay(1000000);delay(1000000);

	command(0x80);
	lcd_dis("  OTP BASED ATM  ", 16);
	command(0xC0);
	lcd_dis("    USING GSM    ", 16);
	delay(1000000);delay(1000000);
	delay(1000000);delay(1000000);
	delay(1000000);delay(1000000);

	GSM_init();
	command(0x01);


/*****************INFINITE LOOP****************************/
	while(1)
	{
	if(j==0)
	{
	j = 1;
	delay(10000);
	command(0x80);
	lcd_dis("Please Show Card", 16);
	}  

	if(x>6)
	{

		if(value[1]=='5' && value[2] == '1' && value[3]=='0'&& value[4]=='0')
		{
		if(z==0)
		{
		z = 1;
		command(0x80);
		lcd_dis(" AOB BANK USER  ", 16);
		command(0xC0);
		lcd_dis("Sending OTP.....", 16);
		delay(1000000);
		delay(1000000);
		delay(1000000);
		GSM_send1();
		delay(1000000);
		command(0x01);
		command(0x80);
		lcd_dis(" OTP Sent2Regd no", 17);
		delay(1000000);
		delay(1000000);	
		delay(1000000);
		delay(1000000);
		delay(1000000);
		command(0x80);
		lcd_dis("Please Enter OTP", 16);
		} 
		delay(100000);
		keypad();
		Check(); 
		}
		
		else if(value[1]=='4' && value[2] == 'E' && value[3]=='0'&& value[4]=='0')
		{  
		if(z==0)
		{
		z = 1;
		command(0x80);
		lcd_dis(" ITITI BANK USER", 16);
		command(0xC0);
		lcd_dis("Sending OTP.....", 16);
		delay(1000000);
		delay(1000000);
		delay(1000000);
		GSM_send2();
		command(0x01);
		command(0x80);
		lcd_dis(" OTP Sent2Regd no", 17);
		delay(1000000);
		delay(1000000);
		delay(1000000);	
		delay(1000000);	
		command(0x80);
		lcd_dis("Please Enter OTP", 16);
		} 
		delay(100000);
		keypad();
		Check();
		}
		}
		else{Random();}	 	
	}

}


/*******************************INTERRUPT FUNCTIONS***************************/



void interrupt_init(void)
{
	VICVectAddr1	=(unsigned)isr_routine;		//FOR SETTING THE ADDRESS OF THE INTERRUPT ROUTINE--->TYPE CASTING
	VICIntEnable	=(1<<4);
	U0IER=0x01;	
	VICVectCntl1=0x20|4;
	
	VICVectAddr0=(unsigned)interrupt_isr;		//ADDRESS OF THE INTERRUPT SLOT	
	VICIntEnable=(1<<7);						//UART 1
	U1IER=0x01;						//FOR TIMER0 CONTROL
	VICVectCntl0=0x20|7;						//7---->UART 1

								//UART 1 INTERRUPT ENABLE REGISTER

					//FOR SETTING TIMER0 INTERRUPT
}

void isr_routine(void)__irq
{
	sec++;
	T0IR=0x01;								//TIMER0 INTERRUPT SET AGAIN
	VICVectAddr	=0;	
	command(0xC0);
	hex_dec(sec);
	if(sec == 10)
	{
	sec =  0;
	y++;
	}						//end of interrupt - dummy write
}


/****************************UART1 Functions***************************/

void uart1_init(unsigned int BAUDRATE)
{
	unsigned int U1DL;
	PCONP|=(1<<4);				//POWER CONTROL FOR UART1
	U1DL=PCLK/(16*BAUDRATE);	//U0DLL CALCULATION
	U1LCR=0x83;					//8 bit data,1 stop bit,no parity bit, DLAB=1   --Line control reg
	U1DLL=(U1DL & 0XFF);		//PLACING VALUES IN U0DLL
	U1DLM=(U1DL>>8);			//FOR HIGH BIT
	U1LCR=0x03;					// DLAB =0

}
void uart0_init(unsigned int BAUDRATE)
{
	unsigned int U0DL;
	PCONP|=(1<<3);				//POWER CONTROL FOR UART1
	U0DL=PCLK/(16*BAUDRATE);	//U0DLL CALCULATION
	U0LCR=0x83;					//8 bit data,1 stop bit,no parity bit, DLAB=1   --Line control reg
	U0DLL=(U0DL & 0XFF);		//PLACING VALUES IN U0DLL
	U0DLM=(U0DL>>8);			//FOR HIGH BIT
	U0LCR=0x03;					// DLAB =0

}
void interrupt_isr(void)__irq
{
						// Acknowledge that ISR has finished execution
	value[x]=U1RBR;								//GETTING DATAS FROM RECEIVE BUFFER REGISTER(RBR)
	delay(6000);
	x++;
	if(x>6){j=1;}
	U1IER=0x01;									//UART 1 INTERRUPT ENABLE REGISTER
	VICVectAddr = 0x0; 
	
}
void uart1_puts(char *p)		 				// Point to character
{
	while(*p)
	{
		uart1_putc(*p++);						// Send character then point to next character
	}
}
void uart1_putc(char a)
{
	while(!(U1LSR & 0x20));						// Wait until Uart0 ready to send character  
	U1THR = a;									// Send character(TRANSMIT HOLD REGISTER)
	delay(50000);
}

 void uart0_puts(char *p)		 				// Point to character
{
	while(*p)
	{
		uart0_putc(*p++);						// Send character then point to next character
	}
}
void uart0_putc(char a)
{
	while(!(U0LSR & 0x20));						// Wait until Uart0 ready to send character  
	U0THR = a;									// Send character(TRANSMIT HOLD REGISTER)
	delay(50000);
}


void out1(char _bit0, char _bit1)
{
	unsigned long c;    
	c = 1<<_bit0;    			// Calculate digit to configuration for input port
//	c = ~c;  					// Set input port from parameter _bit
	if (_bit1) IO1SET |= c;
	else IO1CLR |= c;
}
/*-----------------------------------*/

char inp1(char _bit)
{
	unsigned long c;    
	c = 1<<_bit;    			// Calculate digit to configuration for input port
//	IO1DIR &= ~c;  				// Set input port from parameter _bit
	return((IO1PIN & c)>>_bit);	// Read and return data bit
}
void keypad(void)
{
		
		out1(20,0); out1(21,1); out1(22,1); out1(23,1);

		if (inp1(16) == 0) { check[e] = 'C';e++;delay(1050000); }
		else if (inp1(17) == 0) {check[e] = 'D';e++; delay(1050000); }
		else if (inp1(18) == 0) { check[e] = 'E';e++;delay(1050000);}
		else if (inp1(19) == 0) { check[e] = 'F';e++;delay(1050000); }

		out1(20,1); out1(21,0); out1(22,1); out1(23,1);

		if (inp1(16) == 0) { check[e] = 'B';e++;delay(1050000); }
		else if (inp1(17) == 0) { check[e] = 'A';e++;delay(1050000);}
		else if (inp1(18) == 0) { check[e] = 9;e++;delay(1050000);}
		else if (inp1(19) == 0) { check[e] = 8;e++;delay(1050000);}

		out1(20,1); out1(21,1); out1(22,0); out1(23,1);

		if (inp1(16) == 0) { check[e] = 3;e++;delay(1050000); }
		else if (inp1(17) == 0) {check[e] = 2;e++;delay(1050000);}
		else if (inp1(18) == 0) {check[e] = 1;e++;delay(1050000); }
		else if (inp1(19) == 0) { check[e] = 0;e++;delay(1050000);}

		out1(20,1); out1(21,1); out1(22,1); out1(23,0);

		if (inp1(16) == 0) {  check[e] = 7;e++;delay(1050000);}
		else if (inp1(17) == 0) {check[e] = 6;e++;delay(1050000); }
		else if (inp1(18) == 0) { check[e] = 5;e++;delay(1050000); }
		else if (inp1(19) == 0) {  check[e] = 4;e++;delay(1050000); }
}
void Random(void)
{
	ran = ran + 1;
	ran1 = (ran1 * 2) + 1;
	ran2 = ran2 + 1;
	ran3 = ran3 + 1;
	if(ran >= 9){ran= 0;}
	else if (ran1 >= 9){ran1= 0;}
	else if (ran2 >= 9){ran2= 0;}
	else if (ran3 >= 9){ran3= 0;}

}

void Check(void)
{

		command(0xC0);
		write(check[0]+ '0');
		write(check[1] + '0');
		write(check[2]+ '0');
		write(check[3]+ '0');
	if(e>3)
	{
	if(ran  == check[0] && ran1 == check[1] && ran2 == check[2] && ran3  == check[3])
	{
	command(0x01);
	command(0x80);
	lcd_dis(" Enter the Amount", 17);
	keypad();
	command(0xC0);
	write(check[4]+ '0');
	write(check[5] + '0');
	write(check[6]+ '0');
	write(check[7]+ '0');
	write(check[8]+ '0');
	write(' ');
	write('R');
	write('s');

	t = 1;
	if(u == 1)
	{
	u = 0;
	uart0_puts("TRUE");
	uart0_putc(0x0D);
	}

	if(e>7)
	{
	uart0_putc(check[4]+ '0');
	uart0_putc(check[5] + '0');
	uart0_putc(check[6]+ '0');
	uart0_putc(check[7]+ '0');
	uart0_putc(check[8]+ '0');
	uart0_putc(' ');
	uart0_putc('R');
	uart0_putc('s');
	delay(1000000);
	delay(1000000);
	delay(1000000);
	command(0x01);
	command(0x80);
   	lcd_dis(" Processing......", 17);
	delay(1000000);delay(1000000);
	delay(1000000);delay(1000000);
	delay(1000000);delay(1000000);
	delay(1000000);delay(1000000);
	delay(1000000);	delay(1000000);
	delay(1000000);delay(1000000);
	command(0x80);
	lcd_dis("    Thank You    ", 16);
	command(0xC0);
	lcd_dis("   Come Again... ", 16);
	delay(1000000);
	delay(1000000);
	delay(1000000);
	delay(1000000);
	delay(1000000);
	delay(1000000);
	command(0x01);	
	for(i=0;i<=10;i++)
	 {
	 value[i] = 0;
	 check[i] = 0;
	 Random();
	 } 
	 e = 0; u = 1;j = 0;z = 0;x = 0;
	 }
	}
	else{command(0x80);lcd_dis("Wrong Password. ", 16);		
		delay(1000000);
		delay(1000000);
		delay(1000000);	
		delay(1000000);	uart0_puts("FALSE");uart0_putc(0x0D);e=0;j = 0;z = 0;x = 0;command(0x01);
		for(i=0;i<=10;i++)
	 	{
			 value[i] = 0;
			 check[i] = 0;
			 Random();
	 	}
		}
	}
	
	else
	{
	keypad();
	command(0xC0);
	write(check[0]+ '0');
	write(check[1] + '0');
	write(check[2]+ '0');
	write(check[3]+ '0');
	}
}
 void GSM_init(void)
 {
 		uart1_puts("AT");
		uart1_putc(0x0D);
		delay(1000000);delay(1000000);
		delay(1000000);delay(1000000);
		delay(1000000);delay(1000000);
		uart1_puts("AT+CMGF=1");
		uart1_putc(0x0D);
		delay(1000000);delay(1000000);
		delay(1000000);delay(1000000);
		delay(1000000);delay(1000000);
		delay(100000);

 }
 void GSM_send1(void)
 {
  		uart1_puts("AT+CMGS=");
		uart1_putc('"');
		uart1_puts("9751301205"); //9791422267
		uart1_putc('"');
		uart1_putc(0x0D);
		delay(1000000);
		delay(1000000);delay(1000000);
		delay(1000000);delay(1000000);
		delay(1000000);delay(1000000);
		uart1_puts("OTP is ");
		uart1_putc(ran  + '0');uart1_putc(ran1 +  '0');uart1_putc(ran2  + '0');uart1_putc(ran3 + '0');
		uart1_putc(0x1A);
		uart1_putc(0x0D);
		delay(100000);
 }
   void GSM_send2(void)
 {
  		uart1_puts("AT+CMGS=");
		uart1_putc('"');
		uart1_puts("9524049703");
		uart1_putc('"');
		uart1_putc(0x0D);
		delay(1000000);
		delay(100000);delay(100000);
		delay(1000000);delay(1000000);
		delay(1000000);delay(1000000);
		uart1_puts("OTP is ");
		uart1_putc(ran  + '0');uart1_putc(ran1 +  '0');uart1_putc(ran2  + '0');uart1_putc(ran3 + '0');
		uart1_putc(0x1A);
		uart1_putc(0x0D);
		delay(100000);
 }
/***************************PLL Initialisation**************************/

void init(void) 
{
   PLL0CFG=0x00;    // MSEL = 1,PSEL = 1
   PLL0FEED=0xAA;    // Feed process   
   PLL0FEED=0x55;    
  
   PLL0CON=0x01;
   PLL0FEED=0xAA;   // Feed process
   PLL0FEED=0x55;

   while(!(PLL0STAT & 0x400)) ;   // Wait until PLL Locked
  
   PLL0CON=0x3;    // Connect the PLL as the clock source
   PLL0FEED=0xAA;    // Feed process
   PLL0FEED=0x55;
  
   MAMCR=0x2;     // Enabling MAM and setting number of clocks used for Flash memory fetch (4 cclks in this case)
   MAMTIM=0x4;
  
   VPBDIV=0x01;    // PCLK = CCLK
}
/***************************END OF PROGRAM*********************************/
