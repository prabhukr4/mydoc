/*
===============================================================
Copyright   : Sirius Techno Solution
Author      : R.Prabhu
Description : Head Movement based Wheel chair Control(Head Side)
MCU         : PIC16F877A
===============================================================
*/
#include <pic.h>      				//PIC header File
#include "lcd.h"					//LCD header File
#define _XTAL_FREQ 4e6				//Oscilator Frequency For Time Delay
__CONFIG(0X3f71);					//Configuration Register

void adc();							//Functions Declaration
void time(int);
void check();

unsigned int x,y,z;					//Accelerometer Variables 
void main()
{
	lcd_init();						//LCD Initialisation
	TRISA = 0xff;
	TRISB = 0x00;
	PORTB = 0xFF;
	command(0x80); lcd_dis("Acc",3);
	command(0x86); lcd_dis("Waiting",7);
	time(20);
	
	while(1)
	{
		adc();
		if((x>=280 & x<=295) && (y>=320 & y<=330) && (z>=285 & z<=300)) 
		{
			PORTB = 0xFE; 	// Forward
			command(0x86); lcd_dis("Forward",7);
		}
		else if((x>=270 & x<=280) && (y>=300 & y<=310) && (z>=305 & z<=325)) 
		{
			PORTB = 0xFD; 	// Left
			command(0x86); lcd_dis("Left   ",7);
		}
		else if((x>=280 & x<=290) && (y>=345 & y<=360) && (z>=300 & z<=315)) 
		{
			PORTB = 0xFB; 	// Right
			command(0x86); lcd_dis("Right  ",7);
		}
		else
		{
			PORTB = 0x00; 	// Stop
			command(0x86); lcd_dis("Stop   ",7);
		}
	}
}

void adc()
{
	ADCON0 = 0x05;
	ADCON1 = 0xC0;
	//while(!ADGO);
	x = ((256 * ADRESH) + ADRESL);
	command(0xC0); lcd_dis("X:",2);
	command(0xC2); htd3(x);

	ADCON0 = 0x0D;
	ADCON1 = 0xC0;
	//while(!ADGO);
	y = ((256 * ADRESH) + ADRESL);
	command(0xC5); lcd_dis("Y:",2);
	command(0xC7); htd3(y);

	ADCON0 = 0x15;
	ADCON1 = 0xC0;
	//while(!ADGO);
	z = ((256 * ADRESH) + ADRESL);
	command(0xCA); lcd_dis("Z:",2);
	command(0xCC); htd3(z);
	
}

void time(int a)
{
	while(a--)
	{
		__delay_ms(100);
	}
}