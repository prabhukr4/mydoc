#include<pic.h>
#include"lcd.h"
#include "uart.h"
__CONFIG(0x3F71);
#define _XTAL_FREQ 4e6

#define trig 	RC0
#define echo 	RC1
#define IR_LEFT	RC2
#define IR_RIGHT RC3
#define IN1		RB4
#define IN2		RB5
#define IN3		RB6
#define IN4		RB7

void time(int t)
{
	while(t--){__delay_ms(100);}
}

void ultra();
void check();
void MOTOR_FWD();
void MOTOR_LEFT();
void MOTOR_RIGHT();
void MOTOR_STOP();
void GSM_send();
unsigned int sonar=0,dist=0;

void main()
{
	lcd_init();
	uart_init();
	TRISB = 0x0F;
	TRISC = 0x8E;
	PORTB = 0xFF;
	command(0x80); lcd_dis("Robot Side",10);
	/*~~~~~~~~~ GSM ~~~~~~~~~~~~~~ */
	delay(6500);
	uart_con_out("AT");
	uart_out(0x0A);
	uart_out(0x0D);
	time(20);
	uart_con_out("AT+CMGF=1");
	uart_out(0x0A);
	uart_out(0x0D);
	delay(2000);
	command(0x01);
	while(1)
	{
		ultra();
		if((!RB0) && (RB1) && (RB2) && (RB3))
		{
			MOTOR_FWD();
			check();
		}
		else if((RB0) && (!RB1) && (RB2) && (RB3))
		{
			MOTOR_LEFT();
		}
		else if((RB0) && (RB1) && (!RB2) && (RB3))
		{
			MOTOR_RIGHT();
		}
		else
		{
			MOTOR_STOP();
		}
	}
}
void ultra()
{
	trig = 0; delay(1000);
	trig = 1; delay(1000);
	trig = 0;
	while(!echo) sonar = 0;	
	while(echo) sonar++;
	dist = sonar/5;
	command(0x80); lcd_dis("Dist:",5);
	command(0x85); htd3(dist);
	delay(3000);
}
void MOTOR_FWD()
{
	command(0x8B); lcd_dis("  FWD",5);
	IN1 = 0;
	IN2 = 1;
	IN3 = 0;
	IN4 = 1;
}
void MOTOR_LEFT()
{
	command(0x8B); lcd_dis(" LEFT",5);
	IN1 = 0;
	IN2 = 1;
	IN3 = 1;
	IN4 = 0;
}
void MOTOR_RIGHT()
{
	command(0x8B); lcd_dis("RIGHT",5);
	IN1 = 1;
	IN2 = 0;
	IN3 = 0;
	IN4 = 1;
}
void MOTOR_STOP()
{
	command(0x8B); lcd_dis(" STOP",5);
	IN1 = 1;
	IN2 = 1;
	IN3 = 1;
	IN4 = 1;
}

void GSM_send()
{
	command(0xC0); lcd_dis("Msg Sending.....",16);
	delay(5000);
	uart_con_out("AT+CMGS=");
	uart_out('"'); 
	uart_con_out("9865998789"); 
	uart_out('"');
	uart_out(0x0A);
	uart_out(0x0D);
	time(20);
	uart_con_out("OBSTACLES!!");
	time(10);
	uart_out(0x1A);
	command(0xC0); lcd_dis("Msg Sent..!!!!!!",16);
	time(20);
	uart_out(0x0A);
	uart_out(0x0D);
	command(0xC0);lcd_dis("                ",16);
}

void check()
{
	while(dist<=20)
		{
			ultra();
			if((IR_LEFT) && (!IR_RIGHT))
			{
				MOTOR_RIGHT();
			}
			else if ((!IR_LEFT) && (IR_RIGHT))
			{
				MOTOR_LEFT();
			}
			
			else if ((IR_LEFT) && (IR_RIGHT)) 
			{
				MOTOR_STOP();
				GSM_send();
				while(1)
				{
					ultra();
					if((!RB0) && (RB1) && (RB2) && (RB3)){break;}
				}
			}
			else
			{
				MOTOR_LEFT();
			}
		}
}