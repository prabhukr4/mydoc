/*
=================================================================
Description : Robotic Fish
MCU		 	: PIC16F877A
Program IDE	: MPLAB v8.30
=================================================================
*/

#include<pic.h>
#include"LCD1.h"
#include "uart.h"
__CONFIG(0x3F71);
#define _XTAL_FREQ 4e6

#define trig 	RB0
#define echo 	RB1
#define gas  	RB2
#define sw 		RB3
#define IN1		RC0
#define IN2		RC1
#define IN3		RC2
#define IN4		RC3

void time(unsigned int);
void ultrasonic();
void adc_pH();
void adc_temp();
void init();
void gps_dis();
void MOTOR_FWD();
void MOTOR_TURN();
void MOTOR_STOP();
unsigned char gps_data[52],l, da;
unsigned int sonar=0, dist, temp = 0, temp1 = 0, x=0,pH=0,i=0, inc=0,val=0,set=25,sec=60,count=0;

void main()
{
	init();	
	command(0x80); lcd_dis("      Smart     ",16);
	command(0xC0); lcd_dis("--Robotic Fish--",16);
	uart_con_out("----------------------------",28);uart_out(0x0a);uart_out(0x0d);
	uart_con_out("|-   Smart Robotic Fish   -|",28);uart_out(0x0a);uart_out(0x0d);	
	uart_con_out("----------------------------",28);uart_out(0x0a);uart_out(0x0d);
	time(20);
	command(0x01);
	MOTOR_FWD();
	while(1)
	{
		adc_temp();
		ultrasonic();
		adc_pH();
		if(dist<20)
		{
			while(dist<20)
			{
				ultrasonic();
				command(0xC0); lcd_dis("OBSTACLE..!!!   ",16);
				MOTOR_TURN();
				uart_con_out("Obstacle --> TURN LEFT ", 24); uart_out(0x0a);uart_out(0x0d);	
			}
		}
		else
		{
			MOTOR_FWD();
			command(0xC0); lcd_dis("Monitoring......",16);
		}
		if(pH>60)
		{
			command(0x80); lcd_dis("    pH Alert    ",16);
			command(0xC0); lcd_dis("     Temp-      ",16);
			command(0xCA); htd2(temp1); write(0xDF); write('C');
			uart_con_out("pH Alert", 8); uart_out(0x0a);uart_out(0x0d);
			uart_con_out("Temperature - ",14); uart_hex_dec2(temp1); uart_out(0xDF); uart_out('C');uart_out(0x0a);uart_out(0x0d);
			time(20);
			gps_dis();
			time(20);
		}
		else
		{
			command(0x80); lcd_dis("Dist:",5); command(0x88); lcd_dis("cm pH:",6);
			command(0x85); htd3(dist); command(0x8E); htd2(pH);
			command(0xC0); lcd_dis("Monitoring......",16);
		}
		
		if(!gas)
		{
			command(0x80); lcd_dis(" Gas Pollution  ",16);
			command(0xC0); lcd_dis("Alert & T-      ",16); 
			command(0xCA); htd2(temp1); write(0xDF); write('C');
			uart_con_out("Hazardous GAS detected ", 24); uart_out(0x0a);uart_out(0x0d);
			uart_con_out("Temperature - ",14); uart_hex_dec2(temp1); uart_out(0xDF); uart_out('C');uart_out(0x0a);uart_out(0x0d);
			time(20);
			gps_dis();
			time(20);
			
		}
		else
		{
			command(0x80); lcd_dis("Dist:",5); command(0x88); lcd_dis("cm pH:",6);
			command(0x85); htd3(dist); command(0x8E); htd2(pH);
			command(0xC0); lcd_dis("Monitoring......",16);
		}
		
	}
}

void init()
{
	TRISB = 0xFE;	// 1 1 1 1 1 1 1 0
	TRISA = 0xFF;
	PORTB = 0;
	lcd_init();	
	uart_init();
	
}

void time(unsigned int as)
{
	while(as--){__delay_ms(100);}
}

void ultrasonic()
{
	trig = 0; delay(1000);
	trig = 1; delay(1000);
	trig = 0;
	while(!echo) sonar = 0;	
	while(echo) sonar++;
	dist = sonar/5;
	command(0x85); htd3(dist);
	delay(3000);
}

void adc_pH()
{
	ADCON0 = 0x15;
	ADCON1 = 0xC0;
	delay(2000);
	while(ADGO);
	temp = (256*ADRESH)+ADRESL;
	__delay_ms(100);
	ADCON0 = 0x15;
	ADCON1 = 0xC0;
	delay(2000);
	while(ADGO);
	temp = (256*ADRESH)+ADRESL;
	pH = temp;
	command(0x8E); htd2(pH);
	time(1);
}

void adc_temp()
{
	ADCON0 = 0x0D;
	ADCON1 = 0xC0;
	delay(2000);
	while(ADGO);
	temp1 = (256*ADRESH)+ADRESL;
	__delay_ms(100);
	ADCON0 = 0x0D;
	ADCON1 = 0xC0;
	delay(2000);
	while(ADGO);
	temp1 = (256*ADRESH)+ADRESL;
 	temp1 = (0.48818 * temp1);
	time(1);
}

void gps_dis()
{
	command(0x01);
	command(0x80); lcd_dis("LAT:",4);
	command(0xC0); lcd_dis("LON:",4);
	time(2);
	command(0x84);
	uart_con_out("LAT   ",6);
	for(i = 18; i <= 29; i++)
	{
		write(gps_data[i]);
		uart_out(gps_data[i]);
	}
	uart_out(0x0a);	uart_out(0x0d);
	
	command(0xC4);
	uart_con_out("LON   ",6);
	for(i=32; i<=43; i++)
	{
		 write(gps_data[i]);
		 uart_out(gps_data[i]);
	}
	uart_out(0x0a);	uart_out(0x0d);
	uart_out(0x0a);	uart_out(0x0d);
}

void MOTOR_FWD()
{
	IN1 = IN3 = 1;
	IN2 = IN4 = 0;
}

void MOTOR_TURN()
{
	IN1 = IN4 = 1;
	IN2 = IN3 = 0;
}

void MOTOR_STOP()
{
	IN1 = IN4 = 0;
	IN2 = IN3 = 0;
}

void interrupt rx(void)
{
	if(RCIF == 1)
	{
		RCIF = 0;
		gps_data[x] = RCREG;

		
		if(gps_data[0] != 'G')	{ x=0; goto last; }
		else if(gps_data[0] == 'G'	&&	gps_data[1] != 'P')	{ x=1; goto last; }
		else if(gps_data[0] == 'G'	&&	gps_data[1] == 'P'	&& gps_data[2] != 'R')	{ x=2; goto last; }
		else if(gps_data[0] == 'G'	&&	gps_data[1] == 'P'	&& gps_data[2] == 'R'	&&	gps_data[3] != 'M')	{ x=3; goto last; }
		else if(gps_data[0] == 'G'	&&	gps_data[1] == 'P'	&& gps_data[2] == 'R'	&&	gps_data[3] == 'M'	&&	gps_data[4] != 'C')	{ x=4; goto last; }
		if(x<=50)	{ x++; }
		if(x>50)
		{
			x=0;
		}
		last:; 
	}
	
}

/*
R1=-GPRMC,050650.00,A,1101.14865,N,07658.04268,E,0.729,,081216,,,A*7D
*/