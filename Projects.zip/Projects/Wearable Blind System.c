/*
===============================================================
Copyright   : Sirius Techno Solution
Author      : R.Nishanth
Description : Wearable Blind System
MCU         : PIC16F877A
===============================================================
*/
#include<pic.h>
#include"lcd.h"
#define _XTAL_FREQ 4e6

#define trig RB0	//trigger pin
#define echo RB1	//echo pin(interrupt)

#define trig1 RB2	//trigger pin
#define echo1 RB3	//echo pin(interrupt)

__CONFIG(0x3F71);

unsigned int count = 0;

unsigned int dis = 0,sonar = 0,sonar1 = 0;

unsigned char data[95], send[9]=0;
int  i, j = 0,g,y = 0,x = 1,rxcount = 0,sec=0, h = 0,dist,dist1;

void uart_init();
void ser_out(unsigned int a);
void ser_con_out(const unsigned char *word,unsigned int n);
void delay_sec(unsigned int);
void ultrasonic(void);
void ultrasonic1(void);
void htd_send(unsigned int val);

void main()
{
	
	
	lcd_init();
	uart_init();
	command(0x80);
	lcd_dis(" WEARABLE BLIND ");
	command(0xC0);
	lcd_dis("     SYSTEM     ");
	delay_sec(2);
	command(0x01);
	command(0x80);
	lcd_dis("D1:    cm");
	command(0xC0);
	lcd_dis("D2:    cm");
	while(1)
	{
		ultrasonic();
		ultrasonic1();
		command(0x83);
		htd3(dist); //Normal :
		command(0xC3);
		htd3(dist1);


			
			
			if(dist1>=10 && dist1<=60)
			{
			command(0xcA);
			lcd_dis("OBSTAC");
			ser_con_out("OBSTACLE",8);
			ser_out(0x0A);ser_out(0x0D);
			htd_send(dist);ser_con_out("centi meter",11);
			ser_out(0x0A);ser_out(0x0D);
			
			}
			else{command(0xcA);
			lcd_dis("      ");}
			
			if(dist>=140)
			{
			command(0x8A);
			lcd_dis("PIT      ");
			ser_con_out("PIT",3);
			ser_out(0x0A);ser_out(0x0D);
			htd_send(dist);ser_con_out("centi meter",11);
			ser_out(0x0A);ser_out(0x0D);
			}
			else{command(0xcA);
			lcd_dis("      ");}
	}
}			
	
void uart_init()
{
	 SPBRG = 25;         // for 9600 baud rate
	 BRGH = 1;		     // baud rate high
	 SYNC = 0;		     // asynchronous mode
	 SPEN = 1;		     // serial port enable
	 TXEN = 1;		     // tx enable
	 GIE=1;
	 PEIE=1;
}

 void ser_con_out(const unsigned char *word,unsigned int n)
{
	for(i=0;i<n;i++)
	{
		ser_out(word[i]); 
		delay(6000); 
	}
}		


void ser_out(unsigned int a)
{

    TXREG=a;
    while(!TXIF);   //CONDITION TO CHECK IF THE BIT IS TRANSMITTED OR NOT
    TXIF = 0;
}  
void ultrasonic()
{
	trig = 0; delay(1000);
	trig = 1; delay(1000);
	trig = 0;
	while(!echo) sonar = 0;	
	while(echo) sonar++;
	/*cm = (duration/2) / 29.1;
  inches = (duration/2) / 74; */
	dist = sonar / 5;
	if(dist>2500){dist = 0;}
}	
void ultrasonic1()
{
	trig1 = 0; delay(1000);
	trig1= 1; delay(1000);
	trig1 = 0;
	while(!echo1) sonar1 = 0;	
	while(echo1) sonar1++;
	/*cm = (duration/2) / 29.1;
  inches = (duration/2) / 74; */
	dist1 = sonar1 / 5;
	if(dist1>2500){dist1 = 0;}
}

void delay_sec(unsigned int y)
{
	y = y*10;
	while(y--){__delay_ms(100);}
}
void htd_send(unsigned int val)
{
	unsigned int a, b, c, d;

	a = val / 100;
	b = val % 100;
	c = b / 10;
	d = b % 10;

	ser_out(a + '0');
	delay_sec(1);
	ser_out(c + '0');
	delay_sec(1);
	ser_out(d + '0');
	delay_sec(2);
	ser_out(0x0A);ser_out(0x0D);
}					   
  