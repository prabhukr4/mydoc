/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~/
	PROJECT		:	Water Fountain	
	COLLEGE		:	CIT-EEE
	PROGRAMMER	:	Prabhu R		
/~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/


#include<pic.h>
#include "lcd.h"
#define _XTAL_FREQ 4e6
__CONFIG(0x3f71);

void time(int);
signed int temp;
void main()
{
	TRISA = 0xff;
	TRISB = 0x00;
	ADCON1 = 0xC0;
	lcd_init();
	command(0x80); lcd_dis("Audio Data is",13);
	while(1)
	{
		ADCON0 = 0x05;
		temp = (256 * ADRESH)+ ADRESL;
		command(0xC0);
		hex_dec(temp);
		temp = (16 / 15 ) * temp ;
		if(temp == 1)
		{
			temp = 0; 
		}	
		command(0xC6);
		hex_dec(temp);
		PORTB = temp;
	//	delay(1000);
		
	}
}

void time(int a)
{
	while(a--)
	{
		__delay_ms(100);
	}
}