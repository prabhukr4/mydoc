/*
===============================================================
Copyright   : Sirius Techno Solution
Author      : R.Nishanth
Description : DTMF Robot
MCU         : PIC16F877A
===============================================================
*/
#include<pic.h>
#include"lcd.h"

#define echo   RB3
#define trig   RB2

#define _XTAL_FREQ 4e6
__CONFIG(0x3F71);

#define IN1  RB4
#define IN2  RB5
#define IN3  RB6
#define IN4  RB7


unsigned int count = 0,count1 = 0,dist = 0,sonar,  sec = 0, min = 0, x;
void init_int(void);
void delay_sec(unsigned int);
void ultrasonic(void);
void Forward(void);
void Reverse(void);
void Left(void);
void Right(void);

void main()
{
		TRISB = 0x08;
		PORTB = 0x00;
		lcd_init();

		
		command(0x80);
		lcd_dis("   DTMF BASED   ");
		command(0xC0); 
		lcd_dis(" ROBOTIC VEHICLE");
		delay_sec(2);
		command(0x01);
		command(0x80);
		lcd_dis("   DTMF ROBOT   ");
		delay(5000);
		

	while(1)
	{
		if(RC0 == 1 && RC1 == 1 && RC3 == 1 && RC2 == 0 )
		{
					command(0x01);
					command(0x80);	lcd_dis("  MANUAL MODE   ");
					command(0xC0);	lcd_dis("Stop   ");
					IN1=IN2=IN3=IN4=0;
					
					while(1)
					{					 

						if(RC1 == 1 && RC2 == 0 && RC3 == 0 && RC0 == 0){Forward();}
						if(RC3 == 1 && RC0 == 0 && RC1 == 0 && RC2 == 0){Reverse();}
						if(RC2 == 1 && RC1 ==0 && RC3 == 0 && RC0 == 0){Left();}
						if(RC1 == 1 && RC2 == 1 && RC3 == 0 && RC0 == 0){Right();}
						if(RC0 == 1 && RC3 == 0 && RC1 == 0 && RC2 == 1)
						{
							command(0xC0);
							lcd_dis("Stop   ");
							IN1=IN2=IN3=IN4=0;
						}
						if(RC0 == 0 && RC1 == 0 && RC3 == 1 && RC2 == 1){command(0x01);break;}
					}
		}
		if(RC0 == 0 && RC1 == 0 && RC3 == 1 && RC2 == 1)
		{
			command(0x80);
			lcd_dis(" AUTOMATIC MODE "); 
			ultrasonic();
			command(0xCA); htd3(dist);lcd_dis(" cm");
		if(dist>30){Forward();}else{Left();}
		}	
				


	}		
}


void Forward(void)
{
	IN1=IN3=1;
	IN2=IN4=0;
	command(0xC0);
	lcd_dis("Forward");
}
void Left(void)
{
	IN1=0;IN3=1;
	IN2=1;IN4=0;
	command(0xC0);
	lcd_dis("Left   ");
}
void Right(void)
{
	IN1=1;IN3=0;
	IN2=0;IN4=1;
	command(0xC0);
	lcd_dis("Right  ");
}
void Reverse(void)
{
	IN1=0;IN3=0;
	IN2=1;IN4=1;	
	command(0xC0);
	lcd_dis("Reverse");
}

	
void ultrasonic()
{
	trig = 0; delay(1000);
	trig = 1; delay(1000);
	trig = 0;
	while(!echo) sonar = 0;	
	while(echo) sonar++;
	dist = sonar / 5;
}	

void delay_sec(unsigned int y)	
{
	y = y * 10; 
	while(y--){__delay_ms(100);}
}	