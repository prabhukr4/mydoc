#include<pic.h>
#include "lcd.h"
#include "uart.h"
#define _XTAL_FREQ 4e6
__CONFIG(0x3f71);


void time(int);
unsigned char data_rx[10];
unsigned int x = 0;

void main()
{
	lcd_init();
	uart_init();
	TRISB = 0x00;
	TRISC = 0x80;
	RBPU = 1;
	command(0x80); lcd_dis("FACE RECOGNITION",16);
	command(0xC0); lcd_dis("  USING VOICE   ",16);
	time(30);
	command(0x01);
	command(0x80); lcd_dis("Persons Are.....",16);
	
	while(1)
	{
		if(data_rx[0] == 'A')
		{
			command(0xC0); lcd_dis("Elakkiya        ",16);
			RB0 = 0; delay(10000); RB0 = 1; data_rx[0] = 0;
		}
		
		if(data_rx[0] == 'B')
		{
			command(0xC0); lcd_dis("Shobana         ",16);
			RB1 = 0; delay(10000); RB1 = 1; data_rx[0] = 0;
		}
		
		if(data_rx[0] == 'C')
		{
			command(0xC0); lcd_dis("Abinaya         ",16);
			RB2 = 0; delay(10000); RB2 = 1; data_rx[0] = 0;
		}
		
		if(data_rx[0] == 'D')
		{
			command(0xC0); lcd_dis("Dhivya          ",16);
			RB3 = 0; delay(10000); RB3 = 1; data_rx[0] = 0;
		}
		
		if(data_rx[0] == 'E')
		{
			command(0xC0); lcd_dis("Nathika         ",16);
			RB4 = 0; delay(10000); RB4 = 1; data_rx[0] = 0;
		}
		
		if(data_rx[0] == 'X')
		{
			command(0xC0); lcd_dis("Unknown Person  ",16);
			RB5= 0; delay(10000); RB5= 1; data_rx[0] = 0;
		}	
	}
}

void time(int a)
{
	while(a--)
	{
		__delay_ms(100);
	}
}

void interrupt rx(void)
{
	if(RCIF == 1)
	{
		RCIF = 0;
		data_rx[0] = RCREG;
	}
}