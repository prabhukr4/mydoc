/*
===============================================================
Copyright   : Sirius Techno Solution
Author      : R.Nishanth
Description : Robotic Arm
MCU         : PIC16F877A
===============================================================
*/
#include<pic.h>
#include"lcd.h"
#define _XTAL_FREQ 4e6
__CONFIG(0x3F71);





#define f1 RB2
#define f2 RB3
#define f3 RB4
#define f4 RB5
#define f5 RB6
#define fall RB7

#define M1PWM RA0
#define M2PWM RC0
#define M3PWM RC1
#define M4PWM RC2
#define M5PWM RC3

unsigned int i;

void MOTOR1_PWM();
void MOTOR2_PWM();
void MOTOR3_PWM();
void MOTOR4_PWM();
void MOTOR5_PWM();




void main()
{
	lcd_init();
	TRISB = 0xFC;
	TRISA = 0x00;

	command(0x80); lcd_dis("  ROBOTIC ARM   ");
	while(1)
	{
		if(f1==0)	
		{

			MOTOR1_PWM();
			command(0xC0); lcd_dis("Finger 1  ");			
		}
		
		else if(f2==0)	
		{
			MOTOR2_PWM();
			command(0xC0); lcd_dis("Finger 2  ");			
		}
		
		else if(f3==0)	
		{
			MOTOR3_PWM();
			command(0xC0); lcd_dis("Finger 3  ");			
		}
		
		else if(f4==0)	
		{
			MOTOR4_PWM();
			command(0xC0); lcd_dis("Finger 4  ");			
		}
		
		else if(f5==0)	
		{
			MOTOR5_PWM();
			command(0xC0); lcd_dis("Finger 5  ");			
		}
		
		else if(fall==0)	
		{
			command(0xC0); lcd_dis("Finger 1  ");
			MOTOR1_PWM();
			command(0xC0); lcd_dis("Finger 2  ");
			MOTOR2_PWM();
			command(0xC0); lcd_dis("Finger 3  ");
			MOTOR3_PWM();
			command(0xC0); lcd_dis("Finger 4  ");
			MOTOR4_PWM();
			command(0xC0); lcd_dis("Finger 5  ");
			MOTOR5_PWM();
			
		}
		
		else 
		{
			command(0xC0); lcd_dis("WAITING   ");
		}
}	
}
void MOTOR1_PWM()
{
	for(i=0;i<10;i++){M1PWM = 1;__delay_ms(1);M1PWM = 0;__delay_ms(20);}
	
	for(i=0;i<10;i++){M1PWM = 1;__delay_ms(1.5);M1PWM = 0;__delay_ms(20);}
	
	for(i=0;i<10;i++){M1PWM = 1;__delay_ms(2);M1PWM = 0;__delay_ms(20);}
	
	for(i=0;i<10;i++) {M1PWM = 1;__delay_ms(1.5);M1PWM = 0;__delay_ms(20);}
	
	for(i=0;i<10;i++){	M1PWM = 1;__delay_ms(1);M1PWM = 0;__delay_ms(20);}
}
void MOTOR2_PWM()
{
	for(i=0;i<10;i++){M2PWM = 1;__delay_ms(1);M2PWM = 0;__delay_ms(19);}
	
	for(i=0;i<10;i++){M2PWM = 1;__delay_ms(1.5);M2PWM = 0;__delay_ms(18.5);}
	
	for(i=0;i<10;i++){M2PWM = 1;__delay_ms(2);M2PWM = 0;__delay_ms(18);}
	
	for(i=0;i<10;i++) {M2PWM = 1;__delay_ms(1.5);M2PWM = 0;__delay_ms(18.5);}
	
	for(i=0;i<10;i++){	M2PWM = 1;__delay_ms(1);M2PWM = 0;__delay_ms(19);}
}
void MOTOR3_PWM()
{
	for(i=0;i<10;i++){M3PWM = 1;__delay_ms(1);M3PWM = 0;__delay_ms(19);}
	
	for(i=0;i<10;i++){M3PWM = 1;__delay_ms(1.5);M3PWM = 0;__delay_ms(18.5);}
	
	for(i=0;i<10;i++){M3PWM = 1;__delay_ms(2);M3PWM = 0;__delay_ms(18);}
	
	for(i=0;i<10;i++) {M3PWM = 1;__delay_ms(1.5);M3PWM = 0;__delay_ms(18.5);}
	
	for(i=0;i<10;i++){	M3PWM = 1;__delay_ms(1);M3PWM = 0;__delay_ms(19);}
}
void MOTOR4_PWM()
{
	for(i=0;i<10;i++){M4PWM = 1;__delay_ms(1);M4PWM = 0;__delay_ms(19);}
	
	for(i=0;i<10;i++){M4PWM = 1;__delay_ms(1.5);M4PWM = 0;__delay_ms(18.5);}
	
	for(i=0;i<10;i++){M4PWM = 1;__delay_ms(2);M4PWM = 0;__delay_ms(18);}
	
	for(i=0;i<10;i++) {M4PWM = 1;__delay_ms(1.5);M4PWM = 0;__delay_ms(18.5);}
	
	for(i=0;i<10;i++){	M4PWM = 1;__delay_ms(1);M4PWM = 0;__delay_ms(19);}
}
void MOTOR5_PWM()
{
	for(i=0;i<10;i++){M5PWM = 1;__delay_ms(1);M5PWM = 0;__delay_ms(19);}
	
	for(i=0;i<10;i++){M5PWM = 1;__delay_ms(1.5);M5PWM = 0;__delay_ms(18.5);}
	
	for(i=0;i<10;i++){M5PWM = 1;__delay_ms(2);M5PWM = 0;__delay_ms(18);}
	
	for(i=0;i<10;i++) {M5PWM = 1;__delay_ms(1.5);M5PWM = 0;__delay_ms(18.5);}
	
	for(i=0;i<10;i++){	M5PWM = 1;__delay_ms(1);M5PWM = 0;__delay_ms(19);}
}



