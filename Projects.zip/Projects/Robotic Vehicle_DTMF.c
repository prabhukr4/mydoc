/*
===============================================================
Copyright   : Sirius Techno Solution
Author      : R.Nishanth
Description : Robotic Vehicle Selem
MCU         : PIC16F877A
===============================================================
*/
#include<pic.h>
#include"lcd.h"

#define trig RB1	
#define echo RB2

#define _XTAL_FREQ 4e6
__CONFIG(0x3F71);

#define IN1  RB4
#define IN2  RB5
#define IN3  RB6
#define IN4  RB7

#define SWITCH RB0

unsigned int count = 0,count1 = 0,dist = 0,sonar,  sec = 0, min = 0, x;
void init_int(void);
void delay_sec(unsigned int);
void ultrasonic(void);
void Forward(void);
void Reverse(void);
void Left(void);
void Right(void);

void main()
{
		TRISB = 0x05;
		PORTB = 0x00;
		RBPU = 0;
		lcd_init();

		
		command(0x80);
		lcd_dis("ROBOTIC VEHICLE ");
		command(0xC0);
		lcd_dis("DRIVER ALERT SYS");
		delay_sec(2);
		command(0x01);
		command(0x8C);
		lcd_dis("dist");
		init_int();

	while(1)
	{


		if(SWITCH==0)
			{
				if(RC0 == 1){Forward();}
				else if(RC1 == 1){Reverse();}
				else if(RC2 == 1){Left();}
				else if(RC3 == 1){Right();}
				else if(RC0 == 0 && RC1 == 0 && RC2== 0 && RC3==0){IN1=IN2=IN3=IN4=0;}
			
			}
			else
			{
						//ultrasonic();
		command(0xCC); htd3(dist);
		if(dist<=30){Left();}
		else{Forward();}
			}

	}		
}

	void init_int()
	{
	T0CS=0;
	GIE=1;         //ENABLE GLOBAL INTERRUPT
	PEIE=1;         //ENABLE PERIPHERAL INTERRUPT
	TMR0IE=1;      //ENABLE TIMER0 INTERRUPT
	OPTION=0x07;      //PRESCALAR VALUE 256
	TMR0 = 0xD8;;      //TIMER REGISTER SET FOR 10ms
   
	}
void Forward(void)
{
	IN1=IN3=1;
	IN2=IN4=0;
	command(0xCF);
	write('F');
}
void Left(void)
{
	IN1=0;IN3=1;
	IN2=1;IN4=0;
	command(0xCF);
	write('L');
}
void Right(void)
{
	IN1=1;IN3=0;
	IN2=0;IN4=1;
	command(0xCF);
	write('L');
}
void Reverse(void)
{
	IN1=0;IN3=0;
	IN2=1;IN4=1;
	command(0xCF);
	write('R');
}

	
void ultrasonic()
{
	trig = 0; delay(1000);
	trig = 1; delay(1000);
	trig = 0;
	while(!echo) sonar = 0;	
	while(echo) sonar++;
	dist = sonar / 5;
}	
void interrupt heart(void)
{
	
 if(TMR0IF==1)
   {
      TMR0IF=0;
      count++;
      if(count>=100)
      {
         count=0;sec++;    
      }
   TMR0 = 0xD8;     //setting timer_0 interrupt once again after the previous interrupt
   }	
}
void delay_sec(unsigned int y)	
{
	y = y * 10; 
	while(y--){__delay_ms(100);}
}	