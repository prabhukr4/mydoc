#include<pic.h>
#include"lcd.h"
#define _XTAL_FREQ 4e6
__CONFIG(0x3F71);

#define Buzzer RC2


unsigned int count = 0,count1 = 0, sec = 0, min = 0, temp = 0,temp1 = 0,x,y,z,a = 1;
void init_int(void);
void delay_sec(int);
unsigned int temp_sensor(void);
unsigned int Accelerometer(void);

void uart_init(void);
void ser_out(unsigned char a);
void ser_con_out(const unsigned char *data, unsigned char n);

void main()
{
	lcd_init();
	uart_init();
	TRISB = 0xFF;
	TRISA = 0xFF;
	ADCON1=0xC0;
	
	command(0x80);
	lcd_dis(" Health Monitor ");
	command(0xC0);
	lcd_dis(" Physically clg ");
	delay_sec(2);
	command(0x01);
	command(0x80);
	lcd_dis("T:000");
	command(0x8A);
	lcd_dis("Sec:");
	command(0xC0);
	lcd_dis("P:00");
	command(0xC2);
	lcd_dis("000 bpm   ");

	Buzzer = 1;	delay_sec(1);
	Buzzer = 0;
	delay_sec(3);
	init_int();

	while(1)
	{
		temp_sensor();
		Accelerometer();
			
	
		if(min >= 1)
		{
			min = 0;
			Buzzer = 1;	delay_sec(1);
			Buzzer = 0;
			count1 = count1 * 3;
			command(0xC2);
			htd3(count1);
			GIE=0;
			sec = 0;
			delay_sec(3);
			init_int();
			
			
			ser_con_out("Temperature = ",14);
			ser_out(temp1/10 + '0');
			ser_out(temp1%10 + '0');
			ser_out(248);
			ser_out('C');
			ser_out(0x0A);ser_out(0x0D);
			ser_con_out("Heart Beat  = ", 14);
			ser_out(count1/10 + '0');
			ser_out(count1%10 + '0');
			ser_out(' ');
			ser_con_out("bpm",3);
			ser_out(0x0A);ser_out(0x0D);
			ser_out(0x0A);ser_out(0x0D);
			count1 = 0;		
		}
		if((z<295)){command(0xCA);	lcd_dis("Front ");if(a == 1){ser_con_out("Person Fallen Front", 19);ser_out(0x0A);ser_out(0x0D);a =0;}}	
		else if((z>350)){command(0xCA);	lcd_dis("Back  ");if(a == 1){ser_con_out("Person Fallen Back", 19);ser_out(0x0A);ser_out(0x0D);a =0;}}
		else if(y>370){command(0xCA);	lcd_dis("Left  ");if(a == 1){ser_con_out("Person Fallen Left", 19);ser_out(0x0A);ser_out(0x0D);a =0;}}
		else if((y<295)){command(0xCA);	lcd_dis("Right ");if(a == 1){ser_con_out("Person Fallen Right", 19);ser_out(0x0A);ser_out(0x0D);a =0;}}
		else {command(0xCA);	lcd_dis("Normal");a=1;}
	}	
}
void init_int()
{
	   T0CS=0;
	   GIE=1;         //ENABLE GLOBAL INTERRUPT
	   INTEDG = 1;
	   INTE = 0;
	   PEIE=1;         //ENABLE PERIPHERAL INTERRUPT
	   TMR0IE=1;      //ENABLE TIMER0 INTERRUPT
	   OPTION=0x07;      //PRESCALAR VALUE 256
	   TMR0 = 0xD8;;      //TIMER REGISTER SET FOR 10ms
	   
}
void delay_sec(int x)
{
	x = x*10;
	while(x--)
	{
		__delay_ms(100);
	}	
	
}	
void interrupt heart(void)
{
	if(INTF)
	{
		INTF = 0;
		count1++;
	}
if(TMR0IF==1)
   {
      TMR0IF=0;
      count++;
      if(count>=100)
      {
         count=0; 
         command(0x8E);
        write(sec/10 + '0');
        write(sec%10 + '0');
        sec++;
        
        if(sec >= 20)
		{
			min++;
			sec = 0;
		}  
      }
   TMR0 = 0xD8;     //setting timer_0 interrupt once again after the previous interrupt
   }	
}
unsigned temp_sensor(void)
{
	ADCON0=0x05;
	while(ADGO);
	temp = (256 * ADRESH) + ADRESL;
	temp1 = (temp*0.48818)-86;
	command(0x82);
	htd3(temp1);
	write(223);
	write('C');
}
unsigned int Accelerometer(void)
{
	ADCON0=0x0D;
	while(ADGO);
	temp = (256 * ADRESH) + ADRESL;
	x = temp; 
	command(0x80);
	write('x');
	write(':');
	htd3(x);
	
	ADCON0=0x15;
	while(ADGO);
	temp = (256 * ADRESH) + ADRESL;
	y=temp;
	command(0x86);
	write('y');
	write(':');
	htd3(y);

	ADCON0=0x1D;
	while(ADGO);
	temp = (256 * ADRESH) + ADRESL;
	z=temp;
	command(0xc0);
	write('z');
	write(':');
	htd3(z);
}
void uart_init()
{
	 SPBRG = 25;         // for 9600 baud rate
	 BRGH = 1;		     // baud rate high
	 SYNC = 0;		     // asynchronous mode
	 SPEN = 1;		     // serial port enable
	 TXEN = 1;		     // tx enable
}


void ser_out(unsigned char a)
{
    TXREG=a;
    while(!TXIF);
    TXIF = 0;
}
void ser_con_out(const unsigned char *data, unsigned char n)
{
	unsigned char j;
	for(j = 0; j < n; j++)
	{
		ser_out(data[j]);
		delay(6000);
	} 
}			
