/*
=================================================================
Copyright   : Sirius Techno Solution
Author      : R.PRABHU
Description : BIRDS SCARER,ANIMEL ENTRY PRVENTER and IRRIGATION
MCU         : AT89S52
=================================================================
*/


#include<REGx51.h>
#include"LCD1.h"

#define bird		P1_0
#define animel		P1_1
#define soil		P1_2
#define buz_bird	P3_0
#define buz_animel	P3_1
#define pump		P3_2

void time(unsigned int);
void main()
{
	lcd_init();
	P1 = 0xFF;
	P3 = 0x00;
	P1 = P3 = 0;

	command(0x80);  lcd_dis("WELCOMES YOU TO ",16);
	command(0xC0);  lcd_dis(" FARMERS WORLD  ",16);
	time(75);
	command(0x01);
	command(0x80); lcd_dis("WATER PUMP -    ",16);
	while(1)
	{
		if(soil){	pump = 0; command(0x8C); lcd_dis("ON ",3);	}
		else 	{	pump = 1; command(0x8C); lcd_dis("OFF",3);	}

		if(bird){	buz_bird = 1; command(0xC0); lcd_dis("Birds!!",7);}
		else 	{	buz_bird = 0; command(0xC0); lcd_dis("       ",7);}

		if(animel)  {	buz_animel = 1; command(0xC7); lcd_dis("ANIMELS!!",9);}
		else		{	buz_animel = 0;	command(0xC7); lcd_dis("         ",9);}
		
	}
}

void time(unsigned int a)
{
	while(a--)
	{
		TMOD = 0x01;
		TL0 = 0x00;
		TH0 = 0x35;
		TR0 = 1;
		while(TF0==0);
		TR0 = 0;
		TF0 = 0;
	}
}