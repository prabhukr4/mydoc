/* ========================================================================= 
NOTE:	First #define the PWM total time period and choose corresponding channal
	then put durycycle.
    ========================================================================= */

#include<pic.h>
#define period 0.001				// PWM total period
void pwm_init();
void PWMDuty(unsigned int, unsigned int);
void pwm_init()
{
	CCP1CON = 0x0C;
	CCP2CON = 0x0C;
	PR2 = ((period*1000000)/4)-1;		// PWM total period calculations check it out fromdata sheet
	T2CON = 0x05;
	PWMDuty(1,0);
	PWMDuty(2,0);	
}
void PWMDuty(unsigned int channal, unsigned int DutyCycle)
{
	switch(channal)
	{
		case 1:
			CCPR1L   = DutyCycle>>2;       		 	// Put MSB 8 bits in CCPR1L
			CCP1CON &= 0xCF;                	// Make bit4 and 5 zero
			CCP1CON |= (0x30&(DutyCycle<<4));   // Assign Last 2 LSBs to CCP1CON
			break;
		case 2:
			CCPR2L   = DutyCycle>>2;      		  	// Put MSB 8 bits in CCPR1L
			CCP2CON &= 0xCF;                	// Make bit4 and 5 zero
			CCP2CON |= (0x30&(DutyCycle<<4));   // Assign Last 2 LSBs to CCP1CON
			break;
	}
}