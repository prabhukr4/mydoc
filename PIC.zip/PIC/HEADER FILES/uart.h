#include<pic.h>

void uart_init();

void uart_out(unsigned int);

void uart_con_out(unsigned char *, unsigned int);

void uart_hexdata( int );

unsigned char data;

void uart_init()
{
	SPBRG = 25;
	BRGH  = 1;
	SYNC  = 0;
	SPEN  = 1;
	TXEN  = 1;
//	GIE   = 1;			// for uart RX
//	PEIE  = 1;
//	RCIE  = 1;
//	CREN  = 1;
}

void uart_con_out(unsigned char *word, unsigned int n)
{
	int i;
	for(i=0; i<n; i++)
	{
		uart_out(word[i]);
	}
}


void uart_hex_dec4( int xyz)
{
	int e,f,g,h;
	e = xyz/1000;
	xyz = xyz%1000;
	
	f = xyz/100;
	xyz = xyz%100;
	
	g = xyz/10;
	xyz = xyz%10;
	
	h=xyz;
	uart_out(e + '0');
	uart_out(f + '0');
	uart_out(g + '0');
	uart_out(h + '0');
	
}

void uart_hex_dec3( int xyz)
{
	int f,g,h;
	f = xyz/100;
	xyz = xyz%100;
	
	g = xyz/10;
	xyz = xyz%10;
	
	h=xyz;
	uart_out(f + '0');
	uart_out(g + '0');
	uart_out(h + '0');
	
}

void uart_hex_dec4( int xyz)
{
	int g,h;
	e = xyz/1000;
	xyz = xyz%1000;
	
	f = xyz/100;
	xyz = xyz%100;
	
	g = xyz/10;
	xyz = xyz%10;
	
	h=xyz;
	uart_out(g + '0');
	uart_out(h + '0');
	
}

void uart_out(unsigned int x)
{
	TXREG = x;
	while(!TXIF);
	delay(1000);
	TXIF = 0;
}

/*void interrupt rx(void)
{
	if(RCIF == 1)
	{
		RCIF = 0;
		data = RCREG;
	}
}
	*/	