#include<pic.h>


void scan();
void main()
{
   TRISB=0xff;
   TRISC=0x00;
   TRISD=0x00;
   while(1)
   {
   		scan();
   	}
   
}
void scan()
{
	if(PORTB != 0x00)
	{
		RC0=1; RC1=0;
		if(RB0==1) { RD0=1;}
		else { RD2=1;}
		RC0=0; RC1=1;
		if(RB0==1) { RD1=1;}
		else {RD3=1;}
	}
	else
	{
		while(PORTB != 0x00);
	}
}