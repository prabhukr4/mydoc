/*~~~~~~~~~~~~~~~~~~~~~~WELCOME~~~~~~~~~~~~~~~~~~~~~~*/
/*~~~~~~~~~~~~~~~~~~PRABHU's ROBOT~~~~~~~~~~~~~~~~~~~*/

#include<pic.h>
#include "lcd.h"
#include "uart.h"
#define _XTAL_FREQ 4e6
__CONFIG(0x3f71);


	/*~~~~~~~~ FUNCTION DECLARATION ~~~~~~~~~~~*/
void all_init();
void time(int);



	/*~~~~~~~~ VARIABLE DECLARATION ~~~~~~~~~~~~*/
unsigned char gps_data[61];
unsigned int x=0,y=0,i;



	/*~~~~~~~~~~ MAIN FUNCTION ~~~~~~~~~~~~~~~~*/
void main()
{
	all_init();
	command(0x01);
	command(0x80);	lcd_dis("LAT-",4);
	command(0xC0);	lcd_dis("LON-",4);
	while(1)
	{
	
			command(0x84);
			uart_con_out("Your Location information is",28);
			uart_out(0x0a);
			uart_out(0x0d);
			
			uart_con_out("LAT   ",6);
			for(i = 19; i <= 30; i++)
			{
				write(gps_data[i]);
				uart_out(gps_data[i]);
			}
			uart_out(0x0a);
			uart_out(0x0d);
			
			uart_con_out("LON   ",6);
			command(0xC4);
			for(i=33; i<=44; i++)
			{
				 write(gps_data[i]);
				 uart_out(gps_data[i]);
			}
			uart_out(0x0a);
			uart_out(0x0d);
			uart_out(0x0a);
			uart_out(0x0d);
			time(20);
			
	
		
	}
}



	/* ~~~~~~~~~~~	DELAY	~~~~~~~~~~~~~*/
void time(int a)
{
	while(a--)
	{
		__delay_ms(100);
	}
}


	/*~~~~~~~~~~~~	 INITILIZATION	~~~~~~~~~~~~~*/	
void all_init()
{
	uart_init();
	lcd_init();
	
}

	/*~~~~~~~~~~~~	GPS RECEIVER VIA INTERRUPT	~~~~~~~~~~~~~~*/

void interrupt gps_rx(void)
{
	if(RCIF == 1)
	{
		RCIF = 0;
		gps_data[x] = RCREG;

		
		if(gps_data[0] != '$')	{ x=0; goto last; }
		else if(gps_data[0] == '$'	&&	gps_data[1] != 'G')	{ x=1; goto last; }
		else if(gps_data[0] == '$'	&&	gps_data[1] == 'G'	&& gps_data[2] != 'P')	{ x=2; goto last; }
		else if(gps_data[0] == '$'	&&	gps_data[1] == 'G'	&& gps_data[2] == 'P'	&&	gps_data[3] != 'R')	{ x=3; goto last; }
		else if(gps_data[0] == '$'	&&	gps_data[1] == 'G'	&& gps_data[2] == 'P'	&&	gps_data[3] == 'R'	&&	gps_data[4] != 'M')	{ x=4; goto last; }
		else if(gps_data[0] == '$'	&&	gps_data[1] == 'G'	&& gps_data[2] == 'P'	&&	gps_data[3] == 'R'	&&	gps_data[4] == 'M'	&&	gps_data[5] != 'C')	{ x=5; goto last; }
		if(x<=50)	{ x++; }
		if(x>50)
		{
			x=0;
		
		}
		last:;
	}
}