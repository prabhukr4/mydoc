/*
For Receiving add 
void Mobile_Init()
{
		Delay(50000);Delay(50000);
  		Serial_Conout("AT",2);
		Serial_Out(0x0d); Serial_Out(0x0a);
		Delay(65000); Delay(65000);
		Serial_Conout("AT+CMGF=1",9);
		Serial_Out(0x0d); Serial_Out(0x0a);
		Delay(65000);Delay(65000);
		Serial_Conout("AT+CNMI=2,2,0,0,0",17);
		Serial_Out(0x0d); Serial_Out(0x0a);
		Delay(65000); Delay(65000);
}
*/


#include<pic.h>
#include "lcd.h"
#include "uart.h"
#define _XTAL_FREQ 4e6

void time(int);
void main()
{
	lcd_init();
	uart_init();
	time(30);
	while(1)
	{
		command(0x80); lcd_dis("GSM",3);
		command(0xc0); lcd_dis("      ",6);
		time(10);
		uart_con_out("AT",2);
		uart_out(0x0a);	uart_out(0x0d);
		time(20);
		
		uart_con_out("AT+CMGF=1",9);
		uart_out(0x0a);	uart_out(0x0d);
		time(20);
		
		uart_con_out("AT+CMGS=",8);
		uart_out('"');
		uart_con_out("9842708631",10);
		uart_out('"');
		uart_out(0x0a);	uart_out(0x0d);
		time(20);
		
		uart_con_out("Hi How are you",14);
		command(0x80); lcd_dis("Hi How are you  ",16);
		command(0xC0); lcd_dis("Msg Sent",8);
		uart_out(0x0a);	uart_out(0x0d);
		uart_out(0x0a);	uart_out(0x0d);
		time(1000);
	}
}

void time(int a)
{
	while(a--)
	{
		__delay_ms(100);
	}
}