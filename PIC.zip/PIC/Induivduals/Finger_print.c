/*
===============================================================================
Description 	: Finger Print
MCU		 		: PIC16F877A
===============================================================================
*/

#include<pic.h>
#include"lcd.h"
#include"serial.h"

/*#define enter RB1
#define exit RB2
#define incr RB3
#define decr RB4*/

#define decr RB2
#define incr RB3
#define exit RB4
#define enter RB5


void enter_ID();
void enroll_finger_print();
void search_finger_print();
void match_finger_print();
void delete_finger_print();
void delete_finger_print1();
void enroll_ack();
void search_ack();
void match_ack();
void delete_ack();
void delete_ack1();
/*-------------------------------------------------*/

unsigned int var=0, count=0, data_count=0, check_sum=0, finger_print_ID=0;
unsigned char finger_print_data[80];
/*-------------------------------------------------*/

void main()
{
	TRISB = 0xFF;
	
	lcd_init();
	ser_init();
	TRISC=0x80;
	command(0x80);
	lcd_dis("       POLICE       ",20);
	command(0xC0);
	lcd_dis("    VERIFICATION    ",20);
	command(0x94);
	lcd_dis("      BASED ON      ",20);
	command(0xD4);
	lcd_dis("    FINGER PRINT    ",20);


	while(1)
	{
		if(!enter)
		{
			command(0x01);
			command(0x80);
			lcd_dis("  Select Operation  ",20);
			delay(20000);
			var = 0;

			while(exit)
			{
				if(!incr){delay(20000); var++;}
				if(!decr){delay(20000); var--;if(var<=0){var = 0;}}

				if(var == 1){command(0xC0); lcd_dis("  -- Enroll --  ",16); count = 1;}
				if(var == 2){command(0xC0); lcd_dis("  -- Search --  ",16); count = 2;}
				if(var == 3){command(0xC0); lcd_dis("  -- Match  --  ",16); count = 3;}
				if(var == 4){command(0xC0); lcd_dis("  -- Delete --  ",16); count = 4;}
				if(var == 5){command(0xC0); lcd_dis("--Delete Singl--",16); count = 5;}
			}
		}

		if(!exit)
		{
			if(count == 1){delay(20000); enroll_finger_print(); enroll_ack();}
			if(count == 2){delay(20000); search_finger_print(); search_ack();}
			if(count == 3){delay(20000); match_finger_print(); match_ack();}
			if(count == 4){delay(20000); delete_finger_print(); delete_ack();}
			if(count == 5){delay(20000); delete_finger_print1(); delete_ack1();}
		}
	}
}
/*-------------------------------------------------*/

void interrupt rx(void)
{
	if(RCIF == 1)
	{
		RCIF = 0;
		finger_print_data[data_count] = RCREG;
		data_count++;
		
		if(data_count > 79)
			data_count = 0;
	}
}
/*-------------------------------------------------*/

void enter_ID()
{
	finger_print_ID = 0;
	command(0x01);
	command(0x80);
	lcd_dis("      Enter ID      ",20);

	while(exit)
	{
		if(!incr){delay(20000); if(finger_print_ID<=0){finger_print_ID=0;}finger_print_ID++; command(0xC0); lcd_dis("  ID No :       ",16); command(0xCA); hex_dec(finger_print_ID);}
		if(!decr){delay(20000); finger_print_ID--; if(finger_print_ID<=0){finger_print_ID=0;}command(0xC0); lcd_dis("  ID No :       ",16); command(0xCA); hex_dec(finger_print_ID);}
	}
}
/*-------------------------------------------------*/

void enroll_finger_print()
{
	enter_ID();
	command(0x01);
	command(0x80);
	lcd_dis("  Enrolling...  ",16);
	ser_con_out("\xEF\x01\xFF\xFF\xFF\xFF\x01\x00\x03\x01\x00\x05", 12);		// Generate Image
	delay(65000);

	ser_con_out("\xEF\x01\xFF\xFF\xFF\xFF\x01\x00\x04\x02\x01\x00\x08", 13);	// Image to Charbuffer1
	delay(65000);
	
	ser_con_out("\xEF\x01\xFF\xFF\xFF\xFF\x01\x00\x03\x01\x00\x05", 12);		// Generate Image again
	delay(65000);

	ser_con_out("\xEF\x01\xFF\xFF\xFF\xFF\x01\x00\x04\x02\x02\x00\x09", 13);	// Image to Charbuffer2
	delay(65000);

	ser_con_out("\xEF\x01\xFF\xFF\xFF\xFF\x01\x00\x03\x05\x00\x09", 12);		// Generate Template
	delay(65000);

	ser_con_out("\xEF\x01\xFF\xFF\xFF\xFF\x01\x00\x06\x06\x02\x00", 12);		// Store Image either in Charbuf1 or Charbuf2
	ser_out(finger_print_ID);
	check_sum = finger_print_ID + 15;
	ser_out('\x00');
	ser_out(check_sum);
	delay(65000);
}
/*-------------------------------------------------*/

void enroll_ack()
{
	command(0x80);
	lcd_dis("     Enroll     ",16);

	if((finger_print_data[11] == 0x0A) && (finger_print_data[35] == 0x0A) && (finger_print_data[59] == 0x0A))
	{
		command(0xC0);
		lcd_dis("   Success!!!       ",20);
	}
	if((finger_print_data[11] == 0x0B) && (finger_print_data[35] == 0x0B))
	{
		command(0xC0);
		lcd_dis("      Error     ",16);
	}
	if((finger_print_data[11] == 0x0C) && (finger_print_data[35] == 0x0C))
	{
		command(0xC0);
		lcd_dis("    No finger   ",16);
	}
	if((finger_print_data[11] == 0x0D) && (finger_print_data[35] == 0x0D))
	{
		command(0xC0);
		lcd_dis("    Failure     ",16);
	}
	data_count = 0;
}
/*-------------------------------------------------*/

void search_finger_print()
{
	command(0x01);
	command(0x80);
	lcd_dis("  Searching...  ",16);
	delay(35000);

	ser_con_out("\xEF\x01\xFF\xFF\xFF\xFF\x01\x00\x03\x01\x00\x05", 12);			// Generate Image
	delay(35000);
	
	ser_con_out("\xEF\x01\xFF\xFF\xFF\xFF\x01\x00\x04\x02\x01\x00\x08", 13);		// Image to Charbuffer1
	delay(35000);
	
	ser_con_out("\xEF\x01\xFF\xFF\xFF\xFF\x01\x00\x08\x1B\x01\x00\x00\x01\x01\x00\x27", 17);	// Search the Image
	delay(35000);
}
/*-------------------------------------------------*/

void search_ack()
{
	command(0x80);
	lcd_dis("     Search     ",16);
	
	if((finger_print_data[9] == 0x00) && (finger_print_data[33] == 0x00))
	{
		command(0xC0);
		lcd_dis("   Match Found  ",16);
		delay(65000); delay(20000);
		command(0x01);
		command(0x80);
		lcd_dis("No:",3);
		
		command(0x83);
		hex_dec(finger_print_data[35]);		// gives the Page ID
		
		if(finger_print_data[35]==1)
		{ 
			command(0x87); lcd_dis(" M.BALA ",8); 
			command(0xC0);lcd_dis("10/01/1997RCBOOK:CLR",20);
		    command(0x94);lcd_dis("L.NO:TN3820080018222",20);
		    command(0xD4);lcd_dis("DOI:20/10/2008",14);
		}  
		if(finger_print_data[35]==2)
		{ 
			command(0x87); lcd_dis(" N.PAVITHRA ",12); 
			command(0xC0);lcd_dis("05/03/1997RCBOOK:CLR",20);
		    command(0x94);lcd_dis("L.NO:TN3820080018222",20);
		    command(0xD4);lcd_dis("DOI:20/10/2008",14);
		}  
		if(finger_print_data[35]==3)
		{ 
			command(0x87); lcd_dis(" M.RAMYA ",9); 
			command(0xC0);lcd_dis("20/08/1996RCBOOK:CLR",20);
		    command(0x94);lcd_dis("L.NO:TN3820080018222",20);
		    command(0xD4);lcd_dis("DOI:20/10/2008",14);
		}  
		if(finger_print_data[35]==4)
		{ 
			command(0x87); lcd_dis(" S.SANTHOSH ",12); 
			command(0xC0);lcd_dis("01/06/1995RCBOOK:CLR",20);
		    command(0x94);lcd_dis("L.NO:TN3820080018222",20);
		    command(0xD4);lcd_dis("DOI:20/10/2008",14);
		}  
		if(finger_print_data[35]==5)
		{ 
			command(0x87); lcd_dis(" V.SANTHOSH ",12); 
			command(0xC0);lcd_dis("20/02/1996RCBOOK:CLR",20);
		    command(0x94);lcd_dis("L.NO:TN3820080018222",20);
		    command(0xD4);lcd_dis("DOI:20/10/2008",14);
		} 
		if(finger_print_data[35]==6)
		{ 
			command(0x87); lcd_dis(" K.SARANYA ",11); 
			command(0xC0);lcd_dis("17/09/1995 RCBOOK:CLR",20);
		    command(0x94);lcd_dis("L.NO:TN3820080018222",20);
		    command(0xD4);lcd_dis("DOI:20/10/2008",14);
		}   
	}
	
	else
	{
		command(0xC0);
		lcd_dis("Match Not Found ",16);
	}
	data_count = 0;
}
/*-------------------------------------------------*/

void match_finger_print()
{
	enter_ID();
	command(0x01);
	command(0x80);
	lcd_dis("  Matching...   ",16);
	delay(35000);

	ser_out('\xEF'); ser_out('\x01'); ser_out('\xFF'); ser_out('\xFF'); ser_out('\xFF'); ser_out('\xFF'); ser_out('\x01'); ser_out('\x00'); ser_out('\x06'); ser_out('\x07'); ser_out('\x02'); //-------LOADING THE FP ID IN CHAR BUFFER 2
	ser_out('\x00');
	ser_out(finger_print_ID);
	check_sum=(finger_print_ID+16);
	ser_out('\x00');
	ser_out(check_sum);
	delay(35000);
	ser_out('\xEF'); ser_out('\x01');ser_out('\xFF');ser_out('\xFF');ser_out('\xFF');ser_out('\xFF');ser_out('\x01');ser_out('\x00');ser_out('\x03');ser_out('\x01');ser_out('\x00');ser_out('\x05');//-------GenImg
	delay(35000);
	ser_out('\xEF'); ser_out('\x01');ser_out('\xFF');ser_out('\xFF');ser_out('\xFF');ser_out('\xFF');ser_out('\x01');ser_out('\x00');ser_out('\x04');ser_out('\x02');ser_out('\x01');ser_out('\x00');ser_out('\x08');//-------Img2Tz
	delay(35000);
	ser_out('\xEF'); ser_out('\x01');ser_out('\xFF');ser_out('\xFF');ser_out('\xFF');ser_out('\xFF');ser_out('\x01');ser_out('\x00');ser_out('\x03');ser_out('\x03');ser_out('\x00');ser_out('\x07');//-------MATCH
	delay(35000);
	
	/*
	ser_con_out("\xEF\x01\xFF\xFF\xFF\xFF\x01\x00\x03\x01\x00\x05", 12);		// Generate Image
	delay(35000);
	ser_con_out("\xEF\x01\xFF\xFF\xFF\xFF\x01\x00\x04\x02\x01\x00\x08", 13);	// Image to Charbuffer1
	delay(35000);
	ser_con_out("\xEF\x01\xFF\xFF\xFF\xFF\x01\x00\x03\x03\x00\x07", 12);		// Matching of two finger templates
	delay(35000);
	*/
}
/*-------------------------------------------------*/

void match_ack()
{
	command(0x01);
	command(0x80);
	lcd_dis(" Match ",7);
	
	if(finger_print_data[45] == 0x00)
	{
		command(0x87);
		lcd_dis("Success",7);
		delay(100);
		if(finger_print_ID == 1)
		{ 
			command(0x87); lcd_dis(" M.BALA ",8); 
			command(0xC0);lcd_dis("10/01/1997RCBOOK:CLR",20);
		    command(0x94);lcd_dis("L.NO:TN3820080018222",20);
		    command(0xD4);lcd_dis("DOI:20/10/2008",14);
		}  
		if(finger_print_ID == 2)
		{ 
			command(0x87); lcd_dis(" N.PAVITHRA ",12); 
			command(0xC0);lcd_dis("05/03/1997RCBOOK:CLR",20);
		    command(0x94);lcd_dis("L.NO:TN3820080018222",20);
		    command(0xD4);lcd_dis("DOI:20/10/2008",14);
		}  
		if(finger_print_ID == 3)
		{ 
			command(0x87); lcd_dis(" M.RAMYA ",9); 
			command(0xC0);lcd_dis("20/08/1996RCBOOK:CLR",20);
		    command(0x94);lcd_dis("L.NO:TN3820080018222",20);
		    command(0xD4);lcd_dis("DOI:20/10/2008",14);
		}  
		if(finger_print_ID == 4)
		{ 
			command(0x87); lcd_dis(" S.SANTHOSH ",12); 
			command(0xC0);lcd_dis("01/06/1995RCBOOK:CLR",20);
		    command(0x94);lcd_dis("L.NO:TN3820080018222",20);
		    command(0xD4);lcd_dis("DOI:20/10/2008",14);
		}  
		if(finger_print_ID == 5)
		{ 
			command(0x87); lcd_dis(" V.SANTHOSH ",12); 
			command(0xC0);lcd_dis("20/02/1996RCBOOK:CLR",20);
		    command(0x94);lcd_dis("L.NO:TN3820080018222",20);
		    command(0xD4);lcd_dis("DOI:20/10/2008",14);
		}  
		if(finger_print_ID == 6)
		{ 
			command(0x87); lcd_dis(" K.SARANYA ",11); 
			command(0xC0);lcd_dis("17/09/1995 RCBOOK:CLR",20);
		    command(0x94);lcd_dis("L.NO:TN3820080018222",20);
		    command(0xD4);lcd_dis("DOI:20/10/2008",14);
		}  
	}
	else if(finger_print_data[45] == 0x08)
	{
		command(0xc0);
		lcd_dis("    Failure     ",16);
	}
	else if(finger_print_data[45] == 0x01)
	{
		command(0xc0);
		lcd_dis("     Error      ",16);
	}
	data_count = 0;
}
/*-------------------------------------------------*/

void delete_finger_print()
{
	command(0x01);
	command(0x80);
	lcd_dis("   Deleting...  ",16);
	delay(65000); delay(65000);
	
	ser_con_out("\xEF\x01\xFF\xFF\xFF\xFF\x01\x00\x03\x0D\x00\x11", 12);
	delay(65000); delay(65000);
}
/*-------------------------------------------------*/

void delete_ack()
{
	command(0x80);
	lcd_dis("     Delete     ",16);
	
	if(finger_print_data[9] == 0x00)
	{
		command(0xC0);
		lcd_dis("    Success     ",16);
	}	
	if(finger_print_data[9] == 0x01)
	{
		command(0xC0);
		lcd_dis("     Error      ",16);
	}
	if(finger_print_data[9] == 0x11)
	{
		command(0xC0);
		lcd_dis("    Failure     ",16);
	}
	data_count = 0;
}
/*-------------------------------------------------*/

void delete_finger_print1()
{
	enter_ID();
	command(0x01);
	command(0x80);
	lcd_dis("   Deleting...  ",16);
	
	ser_con_out("\xEF\x01\xFF\xFF\xFF\xFF\x01\x00\x07\x0C\x00", 11);
	ser_out(finger_print_ID);
	ser_out('\x00');
	ser_out('\x01');			// No of Templates
	check_sum = finger_print_ID + 21;
	ser_out('\x00');
	ser_out(check_sum);
	delay(65000);
}
/*-------------------------------------------------*/

void delete_ack1()
{
	command(0x80);
	lcd_dis("Delete Template ",16);
	
	if(finger_print_data[9] == 0x00)
	{
		command(0xC0);
		lcd_dis("    Success     ",16);
	}	
	if(finger_print_data[9] == 0x01)
	{
		command(0xC0);
		lcd_dis("     Error      ",16);
	}
	if(finger_print_data[9] == 0x10)
	{
		command(0xC0);
		lcd_dis("    Failure     ",16);
	}
	data_count = 0;
}
/*-------------------------------------------------*/
