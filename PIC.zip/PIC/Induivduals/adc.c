#include<pic.h>
#include "lcd.h"
__CONFIG(0x3f71);
unsigned int temp;
void main()
{
	TRISA = 0xff;
	lcd_init();
	command(0x80); lcd_dis("Audio Data is",13);
	while(1)
	{
		ADCON0 = 0x05;
		ADCON1 = 0xC0;
		temp = (256 * ADRESH)+ ADRESL;
		command(0x80); lcd_dis("Audio Data is",13);
		command(0xC0);
		hex_dec(temp);
	}
}

