#include<pic.h>
#include "lcd.h"
#define RTC_WRITE	0xD0
#define RTC_READ	0xD1

void i2c_init();
void i2c_wait();

void i2c_write(unsigned char,unsigned char);

unsigned char i2c_read(unsigned char);

void i2c_send(unsigned char);

unsigned char BCD_BINARY(unsigned char);

unsigned char RX_slave;
unsigned char sec, min, hr, day, date, month, year;

void main()
{
	lcd_init();
	i2c_init();

	command(0x80); lcd_dis("Real Time clock",15);
	i2c_write(0x00,0x10);	// Seconds
//	i2c_write(0x01,0x00);	// Minutes
//	i2c_write(0x02,0x00);	// Hour
//	i2c_write(0x03,0x00);	// Day
//	i2c_write(0x04,0x00);	// Date
//	i2c_write(0x05,0x00);	// Month
//	i2c_write(0x06,0x00);	// Year
	
	
	while(1)
	{
		delay(1000);
		sec 	= i2c_read(0x00);	//
		min 	= i2c_read(0x01);	//
		hr 		= i2c_read(0x02);	//
		day		= i2c_read(0x03);	//
		date 	= i2c_read(0x04);	//
		month 	= i2c_read(0x05);	//
		year 	= i2c_read(0x06);	//
		
// Here BCD to Binary Conversion, bcz of fro, RTC values are BCD 
		sec 	= BCD_BINARY(sec);
		min		= BCD_BINARY(min);
		hr 		= BCD_BINARY(hr);
		day		= BCD_BINARY(day);
		date	= BCD_BINARY(date);
		month	= BCD_BINARY(month);
		year	= BCD_BINARY(year); 
		
		command(0xD4);
	hex_dec2(hr); write(':'); hex_dec2(min); write(':'); hex_dec2(sec);
		hex_dec2(sec);
		
	} 
/*	while(1)
	{
		i2c_write(0x00,0x05);	// Seconds
		sec 	= i2c_read(0x00);
		BCD_BINARY(sec);
		command(0xD4); hex_dec2(sec);
	}*/
}

void i2c_wait()
{
	while(SSPIF == 0);
	SSPIF = 0;
	delay(1000);
}

void i2c_init()
{
	TRISC = 0x98;
	SSPSTAT = 0xC0;
	SSPCON=0X28;			// 0b00101000 	
	SSPADD=9;				//BASED ON BAUD RATE GENERATOR(4MHZ)
	//ACKSTAT = 1;
}


void i2c_write(unsigned char addr1,unsigned char data1)
{
	SEN = 1;						//	Start bit
	command(0xC0); write('S');
	i2c_wait();						//	Wait for ACK=1(if above task is finished)
	i2c_send(RTC_WRITE);			//	Address with WRITE of the slave module
	i2c_send(addr1);				//	Address or location, where u want right
	write('A');
	i2c_send(data1);				//	Mention the location u have to put the data
	write('D');
	PEN = 1;						//	Stop Bit
	write('T');
	i2c_wait();						//	Wait for ACK=1(if above task is finished)
}


unsigned char i2c_read(unsigned char location)
{

	SEN = 1;						//	Start bit
	command(0x94); write('S');
	i2c_wait();						//	Wait for ACK=1(if above task is finished)
	i2c_send(RTC_WRITE);			//	Address with WRITE of the slave module
	write('W');
	i2c_send(location);				//	Address or location, where u want right
	write('L');
	RSEN = 1;						//	Stop and Restart
	i2c_wait();						//	Wait for ACK=1(if above task is finished)
	i2c_send(RTC_READ);				//	Address with READ the slave location
	write('R');
	RCEN = 1;						//	Receive Enable bit from slave
	i2c_wait();						//	Wait for ACK=1(if above task is finished)
	ACKDT = 1;
	ACKEN = 1;
	RX_slave = SSPBUF;
	write('D');
	PEN = 1;						//	Stop Bit
	i2c_wait();						//	Wait for ACK=1(if above task is finished)
	write('T');
	return(RX_slave);
}


void i2c_send(unsigned char data2)
{
/*	while(ACKSTAT == 1)
	{
		SSPBUF = data2;
		i2c_wait();
	}
	ACKSTAT = 1;	*/
	while(1)	
	{
		SSPBUF=data2;					//FOR TRANSFERRING DATAS(ADRESS,DATAS) BY MEANS OF SSPBUF
		delay(1000);
		i2c_wait();
		if(ACKSTAT!=1)					//ACKNOWLEDGE=0 FOR CONFIRMATION
		break;
	}
}



unsigned char BCD_BINARY(unsigned char val)
{
	unsigned char binary;
	binary = ((val & 0xF0 )>>4 ) * 10 + (val & 0x0F);
	delay(1000);
	return (binary);
}