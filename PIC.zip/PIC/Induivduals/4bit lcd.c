#include<pic.h>

#define rs RC4
#define en RC5

#define d4 RD4
#define d5 RD5
#define d6 RD6
#define d7 RD7
/*
#define d4 RD7
#define d5 RD6
#define d6 RD5
#define d7 RD4

*/

void delay(unsigned int);
void command(unsigned char);
void lcd_init();
void write(unsigned char);
void lcd_dis(const unsigned char*, unsigned int);
void lcd_send(unsigned char);
unsigned int i1, j, k, a, b, c, d;

void main()
{
	lcd_init();
	while(1)
	{
		command(0x80);
		write('a');
		delay(5000);
		write('b');
		delay(5000);
		
	}
}

void delay(unsigned int j)
{
   while(j--);
}
void lcd_init()
{
   TRISC = 0x80;
   TRISD = 0;
   command(0x38);
   command(0x06);
   command(0x0C);
   command(0x01);
}

void command(unsigned char addr)		// 0x85
{
	char LSB,MSB;
	LSB = (addr & 0x0F);
	MSB = (addr & 0xF0);
	en = 1;
   	rs = 0;
   	lcd_send(MSB>>4);
   	delay(500);
   	en = 0;
   	delay(500);
   	en = 1;
   	lcd_send(LSB);
   	delay(500);
   	en = 0;
}

void write(unsigned char data)
{
	char LSB1, MSB1;
	LSB1 = (data & 0x0F);
	MSB1 = (data & 0xF0);
   	en = 1;
   	rs = 1;
   	lcd_send(MSB1>>4);
   	delay(500);
   	en = 0;
   	delay(1000);
   	en = 1;
   	lcd_send(LSB1);
   	delay(500);
   	en = 0;
}

void lcd_dis(const unsigned char* word, unsigned int k)
{
   for(i1 = 0; i1 < k; i1++)
   {
      write(word[i1]);
   }   
}

void lcd_send(unsigned char info)
{
	if(info & 1) { d4 = 1; } else { d4 = 0; }
	if(info & 2) { d5 = 1; } else { d5 = 0; }
	if(info & 4) { d6 = 1; } else { d6 = 0; }
	if(info & 8) { d7 = 1; } else { d7 = 0; }
	
}
/*
void hex_dec4(unsigned int x)
{
   a = x/1000;
   x = x%1000;
   b = x/100;
   x = x%100;
   c = x/10;
   x = x%10;
   d = x;
   write(a + 0x30);   
   write(b + 0x30);
   write(c + 0x30);
   write(d + 0x30);
}

void hex_dec3(unsigned int x)
{
   a = x/100;
   x = x%100;
   b = x/10;
   x = x%10;
   d = x;
   write(a + 0x30);   
   write(b + 0x30);
   write(d + 0x30);
}

void hex_dec2(unsigned int x)
{
   c = x/10;
   x = x%10;
   d = x;
   write(c + 0x30);
   write(d + 0x30);
}
*/