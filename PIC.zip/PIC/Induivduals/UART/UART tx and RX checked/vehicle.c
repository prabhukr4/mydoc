/*~~~~~~~~~~~~~~~~~~~~~~WELCOME~~~~~~~~~~~~~~~~~~~~~~*/
/*~~~~~~~~~~~~~~~~~~PRABHU's ROBOT~~~~~~~~~~~~~~~~~~~*/

#include<pic.h>
#include "lcd.h"
#include "uart.h"
#define _XTAL_FREQ 4e6
__CONFIG(0x3f71);


	/*~~~~~~~~ FUNCTION DECLARATION ~~~~~~~~~~~*/
void all_init();
void time(int);



	/*~~~~~~~~ VARIABLE DECLARATION ~~~~~~~~~~~~*/
unsigned char gps_data[6];
unsigned int x=0,i;



	/*~~~~~~~~~~ MAIN FUNCTION ~~~~~~~~~~~~~~~~*/
void main()
{
	all_init();
	command(0x80);	lcd_dis("  W E L C O M E ",16);
	while(1)
	{
		if(x==5)
		{
		x = 0;
		for(i=0; i<=5; i++)
		{
		uart_out(gps_data[i]);
		command((0xc0) + i);
		write(gps_data[i]);
		}
		uart_out(0x0d);		/* FOR NEXT LINE */
		time(10);
		}
	}

}


	/* ~~~~~~~~~~~	DELAY	~~~~~~~~~~~~~*/
void time(int a)
{
	while(a--)
	{
		__delay_ms(100);
	}
}


	/*~~~~~~~~~~~~	 INITILIZATION	~~~~~~~~~~~~~*/	
void all_init()
{
	uart_init();
	lcd_init();
	
}

	/*~~~~~~~~~~~~	GPS RECEIVER VIA INTERRUPT	~~~~~~~~~~~~~~*/

void interrupt gps_rx(void)
{
	if(RCIF == 1)
	{
		RCIF = 0;
		gps_data[x] = RCREG;
		x++;

	}
}