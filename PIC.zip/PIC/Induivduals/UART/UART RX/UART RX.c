#include<pic.h>
#include "lcd.h"
#define _XTAL_FREQ 4e6

void total_init();
void uart_out(unsigned int);
void uart_con_out(unsigned char *, unsigned int);
unsigned char data;
void main()
{
	lcd_init();
	total_init();
//	while(1)
//	{
		uart_out(data);
//	}
}

void total_init()
{
	SPBRG = 25;
	BRGH  = 1;
	SYNC  = 0;
	SPEN  = 1;
	TXEN  = 1;
	GIE   = 1;
	PEIE  = 1;
	RCIE  = 1;
	CREN  = 1;
}

void uart_con_out(unsigned char *word, unsigned int n)
{
	int i;
	for(i=0; i<n; i++)
	{
		uart_out(word[i]);
	}
}

void uart_out(unsigned int x)
{
	TXREG = x;
	while(!TXIF);
	TXIF = 0;
}

void interrupt rx(void)
{
	if(RCIF == 1)
	{
		RCIF = 0;
		data = RCREG;
	}
}
		