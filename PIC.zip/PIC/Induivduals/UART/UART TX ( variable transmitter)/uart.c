#include<pic.h>
#include "lcd.h"
#define _XTAL_FREQ 4e6

void time(unsigned int );
void uart_init();
void uart_out(unsigned int);
void uart_con_out(const unsigned char *, unsigned int);
void uart_tx();

unsigned char s[20] = "Prabhu and Nishanth";
void main()
{
	TRISC = 0x00;
	lcd_init();
	uart_init();
	while(1)
	{
		uart_tx();
		command(0x80);	lcd_dis("Information Sent",16);
		command(0xc0);	lcd_dis("  Sucessfully  ",15);
	
	}
}

void uart_tx()
{
	int i;
	for(i=0; i<=18; i++)
	{
		uart_out(s[i]);
	}
}

void uart_init()
{
	SPBRG = 25;			// Baud rate = 9600
	 BRGH = 1;			// Baud rate in High speed
	 SYNC = 0;			// Choosing ASYNC communication
	 SPEN = 1;			// Serial Port enable
	 TXEN = 1;			// Transmit enable
}

void uart_con_out(const unsigned char *word, unsigned int n)
{
	int i;
	for(i=0; i<n; i++)
	{
		uart_out(word[i]);
		//time(20);
	}
}

void uart_out(unsigned int a)
{
	TXREG = a;			// Transmitting data register
	while(! TXIF );		// when the TXIF is set the data is transmitted
	delay(6000);
	TXIF = 0;
}

void time(unsigned int x )
{
	while(x--)
	{
		__delay_ms(100);
	}
}       