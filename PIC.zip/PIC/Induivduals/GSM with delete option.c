#include<pic.h>
#include<string.h>
#include "lcd.h"
#include "uart.h"
#define _XTAL_FREQ 4e6

#define row1 RB0
#define row2 RB1
#define row3 RB2
#define row4 RB3
#define col1 RB4
#define col2 RB5
#define col3 RB6
#define hum RC0
#define vib RC1

void init();
void keypad();
void sensor();
void time(int);
void move(int);
 void gsm( unsigned char*,unsigned int );
//void gsm();
unsigned int i,j,m,x=0,y=0;
unsigned char num[11];
unsigned char msg[10] = "Vibration";
unsigned char msg1[10] = "Humidity ";

void main()
{
	init();
	
	while(1)
	{
		keypad();
		sensor();
				
	}
}

void init()
{
	lcd_init();
	uart_init();
	TRISB = 0x0F;
}


void keypad()
{
	command(0x80);
	col1 = 1; col2 = col3 = 0;
	if(row1) { command((0x80) + y); write('1'); i=1; move(i); time(2);}
	if(row2) { command((0x80) + y);  write('4'); i=4; move(i); time(2);}
	if(row3) { command((0x80) + y);  write('7'); i=7; move(i); time(2);}
	// if(row4) { write('*'); i=0; move(i); time(1);}
	
	col2 = 1; col1 = col3 = 0;
	if(row1) { command((0x80) + y);write('2'); i=2; move(i); time(2);}
	if(row2) {command((0x80) + y); write('5'); i=5; move(i); time(2);}
	if(row3) { command((0x80) + y);write('8'); i=8; move(i); time(2);}
	if(row4) { command((0x80) + y);write('0'); i=0; move(i); time(2);}
	
	col3 = 1; col2 = col1 = 0;
	if(row1) {command((0x80) + y); write('3'); i=3; move(i); time(2);}
	if(row2) { command((0x80) + y);write('6'); i=6; move(i); time(2);}
	if(row3) { command((0x80) + y);write('9'); i=9; move(i); time(2);}
	
	if(row4) 
	{ 
		y = y-1;
		time(2);
		command((0x80) + y);
		write(' ');
	}
	
}

void move ( int i )
{
	num[y] = i;
	y++;
		
		if(y>9)
		{
			y = 0;
			command(0xC0);
			for(j=0; j<=9; j++)
			{
				write(num[j] + '0');
				uart_out(num[j] + '0');
				
			}
		}
}


void sensor()
{

	if(hum)
	{
`		lcd_dis(msg1,9);
		gsm(msg1,9);
	}
	if(vib == 0)
	{
		lcd_dis(msg,9);
		gsm(msg,9);
		time(5);
	}	

}

void gsm( unsigned char * ms1 ,unsigned int k )
{
		uart_out(0x0a);	uart_out(0x0d);
		uart_out(0x0a);	uart_out(0x0d);
		time(10);
		uart_con_out("AT",2);
		uart_out(0x0a);	uart_out(0x0d);
		time(20);
		
		uart_con_out("AT+CMGF=1",9);
		uart_out(0x0a);	uart_out(0x0d);
		time(20);
	
		uart_con_out("AT+CMGS=",8);
		
		uart_out('"');
		for(j=0; j<=9; j++)
		{
			uart_out(num[j] +'0');

		}
	
		uart_out('"');
		
		uart_out(0x0a);	uart_out(0x0d);
		time(20);
		
		uart_out('"');
		uart_con_out(ms1,9);
		uart_out('"');
		command(0xc0);lcd_dis("                ",16);
		command(0xc0); lcd_dis("....Msg Sent....",16); 
		time(20);
		command(0x01);		
		uart_out(0x0a);	uart_out(0x0d);
		uart_out(0x0a);	uart_out(0x0d);
}

void time(int a)
{
	while(a--)
	{
		__delay_ms(100);
	}
}	