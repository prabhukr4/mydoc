#include<pic.h>
#define _XTAL_FREQ 4e6

void init();
void uart_out(unsigned char);
unsigned char RX_SLAVE[50],temp;
unsigned int a=0,i=0,j=0,x=0;
void main()
{
	init();
	while(1)
	{
		if(i>=7)
		{
			for(a=1; a<=7;a++)
			{
				uart_out(RX_SLAVE[a]);
			}
			i=0;
			uart_out(0x0A);
			uart_out(0x0D);
		}
	}
}

void init()
{
	TRISC = 0xFF;
	TRISB = 0x00;
	PORTB = 0;
	SSPSTAT = 0x00;
	SSPCON = 0x36;
	SSPCON2 = 0x00;
	SSPADD = 0xD0;
	
	 GIE=1;
	 PEIE=1; 
	 SPBRG = 25;         // for 9600 baud rate
	 BRGH = 1;		     // baud rate high
	 SYNC = 0;		     // asynchronous mode
	 SPEN = 1;		     // serial port enable
	 TXEN = 1;		     // tx enable
	 RCIE = 1;			 // interrupt set
	 CREN = 1;		     // rx enable
	 SSPIE = 1;
}

void uart_out(unsigned char data)
{
	TXREG = data;
	__delay_ms(1);
	while(!TXIF);
	TXIF = 0;
	__delay_ms(1);
}

void interrupt slave(void)
{
	if(SSPIF)
	{
		CKP =0;
		if(!(SSPSTAT & 0x20) && !(SSPSTAT & 0x04))		// Address + Write
		{
			RB0 = 1;
		}
		if(SSPSTAT && 0x20)								// Data
		{
			RB1 = 1;
			RX_SLAVE[i] = SSPBUF;
			SSPIF = 0;
			i++;
		}
		CKP =1;
		
		
	}
}