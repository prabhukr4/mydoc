#include<pic.h>
#define _XTAL_FREQ 4e6

void init();
void i2c_write();
//void i2c_read();
void i2c_send(unsigned char *);
void i2c_wait();
unsigned int i=0, j=0, x=0;
unsigned char RX_DATA[]= "Prabhu";

void main()
{
	init();
	while(1)
	{
		if(RB0)
		{
			i2c_write();
			i=0;
			__delay_ms(100);__delay_ms(100);__delay_ms(100);__delay_ms(100);
		}
	/*	if(RB1)
		{
			i2c_read();
		}*/
	}
}

void init()
{
	TRISB = TRISB = 0xFF;
	SSPSTAT = 0x00;
	SSPCON = 0x28;
	SSPCON2 = 0x00;
	SSPADD = 9;
	
	GIE=1;
	PEIE=1; 
	SPBRG = 25;         // for 9600 baud rate
	BRGH = 1;		     // baud rate high
	SYNC = 0;		     // asynchronous mode
	SPEN = 1;		     // serial port enable
	TXEN = 1;		     // tx enable
	RCIE = 1;			 // interrupt set
	CREN = 1;	
}

void i2c_write()
{
	SEN = 1;
	i2c_wait();
	SSPBUF = 0xD0;
	i2c_wait();
	while(ACKSTAT); ACKSTAT=0;
	i2c_send(RX_DATA);
	__delay_ms(1);
	PEN=1;
	i2c_wait();
}

void i2c_wait()
{
	while(SSPIF ==0);
	SSPIF = 0;
	__delay_ms(1);
}

void i2c_send(unsigned char *info)
{
	while(*info)
	{
		SSPBUF = (*info);
		*info++;
		i2c_wait();
		while(ACKSTAT); ACKSTAT = 0;
	}
}
/*
void interrupt receive(void)
{
	if(RCIF)
	{
		RCIF = 0;
		RX_DATA[i] = SSPBUF;
		i++;
	}
}*/