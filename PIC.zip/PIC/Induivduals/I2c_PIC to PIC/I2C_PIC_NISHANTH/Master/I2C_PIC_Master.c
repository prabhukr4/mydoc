#include<pic.h>
#include"lcd.h"
__CONFIG(0x3F71);
#define XTAL_FREQ 4e6

unsigned char data[10],i=0;
void I2CMaster_init();
void uart_init();
void I2Cwrite(char *word);
void I2Cwait();
void ser_out(unsigned char val);
void ser_con_out(const unsigned char *string, unsigned char n);

void main()
{
	TRISC = 0x98;
	PORTC = 0x00;
	lcd_init();
	uart_init();
	I2CMaster_init();


	while(1)
	{
		/*	SEN = 1;
			I2Cwait();
			SSPBUF = 0xD0;
			I2Cwait();
			//while(!ACKSTAT);
			SSPBUF = 'A';
			//while(!ACKSTAT);
			PEN = 1;
			I2Cwait();
			i=0;*/

		if(i>=7)
		{
			SEN = 1;
			I2Cwait();
			SSPBUF = 0xD0;
			I2Cwait();
			while(ACKSTAT)ACKSTAT=0;
			I2Cwrite(data);
			delay(1000);
			while(ACKSTAT)ACKSTAT=0;
			PEN = 1;
			I2Cwait();
			i=0;		
		}
		
	}	

}	
void I2CMaster_init(void)
{
	SSPSTAT = 0x00;
	SSPCON	= 0x28;
	SSPCON2	= 0x00;
	SSPADD = 49;
}
void uart_init(void)
{
	 GIE=1;
	 PEIE=1; 
	 SPBRG = 25;         // for 9600 baud rate
	 BRGH = 1;		     // baud rate high
	 SYNC = 0;		     // asynchronous mode
	 SPEN = 1;		     // serial port enable
	 TXEN = 1;		     // tx enable
	 RCIE = 1;			 // interrupt set
	 CREN = 1;		     // rx enable

}	
void I2Cwrite(char *word)
{
	while(*word)
	{
		SSPBUF = (*word++);
		I2Cwait();
		while(ACKSTAT)ACKSTAT=0;
	}	
}
void I2Cwait()
{
	while(SSPIF==0);SSPIF=0;
	delay(1000);
}	
void ser_out(unsigned char val)
{
	TXREG = val; delay(1500);
	while(!TXIF); delay(1500);
	TXIF = 0;
}

void ser_con_out(const unsigned char *string, unsigned char n)
{
	unsigned char i;
	for(i = 0; i < n; i++)
	{
		ser_out(string[i]);
		delay(2000);
	}
}
void interrupt serial(void)
{
	if(RCIF==1)
	{
		RCIF = 0;
		data[i] = RCREG;
		i++;
	}	
}			