#include<pic.h>
#include "lcd.h"
#define _XTAL_FREQ 4e6
__CONFIG(0x3f71);

void time(int);
void main()
{
	TRISB = 0x00;
	lcd_init();
	command(0x80); lcd_dis("  WELCOME TO RF ",16);
	command(0xc0); lcd_dis("    Tx and RX   ",16);
	time(20); command(0x01);
	while(1)
	{
		PORTB = 0x00;
		command(0x80); lcd_dis("Got Ground ???  ",16);
		command(0xc0); lcd_dis("  :-)  or  :-(  ",16);
		time(50);
		PORTB = 0xff;
		command(0x80); lcd_dis("   Got VCC ???  ",16);
		command(0xc0); lcd_dis("  :-)  or  :-(  ",16);
		time(50);
	/*	PORTB = 0x05;
		command(0x80); lcd_dis("FORWARD",7);
		command(0xC0); lcd_dis("wait for 5 Sec..",16);
		time(50);
		PORTB = 0x00;
		command(0x80); lcd_dis("STOP   ",7);
		command(0xC0); lcd_dis("wait for 5 Sec..",16);
		time(50);
		PORTB = 0x0A;
		command(0x80); lcd_dis("REVERSE",7);
		command(0xC0); lcd_dis("wait for 5 Sec..",16);
		time(50);
	*/
	}
}

void time( int a )
{
	while(a--)
	{
		__delay_ms(100);
	}
}