#include<pic.h>

#define rs RC0
#define en RC5

unsigned int i1, j, k, a, b, c, d;

void delay(unsigned int j)
{
   while(j--);
}

void command(unsigned char addr)
{
   en = 1;
   rs = 0;
   PORTD = addr;
   delay(1000);
   en = 0;
}

void lcd_init()
{
   TRISC = 0x80;
   TRISD = 0;
   command(0x38);
   command(0x06);
   command(0x0C);
   command(0x01);
}

void write(unsigned char data)
{
   en = 1;
   rs = 1;
   PORTD = data;
   delay(1000);
   en = 0;
}

void lcd_dis(const unsigned char* word)
{
	while(*word)
	{
		write(*word);
		*word++;
	}
   /*for(i1 = 0; i1 < k; i1++)
   {
      write(word[i1]);
   } */  
}

void hex_dec4(unsigned int x)
{
   a = x/1000;
   x = x%1000;
   b = x/100;
   x = x%100;
   c = x/10;
   x = x%10;
   d = x;
   write(a + 0x30);   
   write(b + 0x30);
   write(c + 0x30);
   write(d + 0x30);
}

void hex_dec3(unsigned int x)
{
   a = x/100;
   x = x%100;
   b = x/10;
   x = x%10;
   d = x;
   write(a + 0x30);   
   write(b + 0x30);
   write(d + 0x30);
}

void hex_dec2(unsigned int x)
{
   c = x/10;
   x = x%10;
   d = x;
   write(c + 0x30);
   write(d + 0x30);
}
