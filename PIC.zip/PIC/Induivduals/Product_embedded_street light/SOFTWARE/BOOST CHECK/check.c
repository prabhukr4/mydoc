#include<pic.h>
#include "lcd.h"
#define _XTAL_FREQ 4e6
__CONFIG(0x3f71);

#define RELAY 	RB0
#define BUZ		RB1
#define sw		RB2

void adc();
unsigned int temp,set=20;
void main()
{
	lcd_init();
	TRISA = 0xFF;
	TRISB = 0x04;
	PORTB = 0;
	RB0 = 1;
	
	command(0x80); lcd_dis("Temp ");
	command(0xC0); lcd_dis("Set  ");
	while(1)
	{
		adc();
		command(0xC5); hex_dec2(set); write(0xDF); write('c');	
		if(!sw)
		{
			set++; delay(500);
			if(set>50){set = 20;}
		}
		if(temp >= set)
		{
			RELAY = 1;
			BUZ = 1;
			command(0x8A); lcd_dis("Light");
			command(0xCA); lcd_dis(" OFF ");
		}
		else
		{
			RELAY = 0;
			BUZ = 0;
			command(0x8A); lcd_dis("Light");
			command(0xCA); lcd_dis(" ON  ");
		}
	}
}
void adc()
{
	ADCON0 = 0x05;
	ADCON1 = 0xC0;
	while(ADGO);
	temp = (256 * ADRESH) + ADRESL;
	temp = temp * 0.48876;
	command(0x85); hex_dec2(temp);write(0xDF); write('c');
}