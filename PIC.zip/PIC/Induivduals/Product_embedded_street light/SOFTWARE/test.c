
#include<pic.h>
#include "lcd.h"
__CONFIG(0x3f71);
#define _XTAL_FREQ 4e6

#define ON		RB0
#define OFF		RB1
#define AUTO	RB2
#define CHARGER	RB3
#define LOAD	RB4

void time(int);
void adc();
void init();
void pwm();
void float_dis(float);
float temp2 = 0, solar=0,battery=0;
unsigned int temp=0,test=0, val=0,dai=255,DutyCycle=70,DutyCycle1=70;
void main()
{
	init();
	command(0x80); lcd_dis("S-",2);	
	command(0x8A); lcd_dis("B-",2);
	pwm();
	time(10);
	
	
	
	while(1);
	
	
	
	while(1)
	{ 
		adc();	
		if(ON)
		{
			command(0xC7); lcd_dis("LON-MANL ",9);
			command(0x87); lcd_dis("(P)",3);
			LOAD = 1;
		}
		if(OFF)
		{
			command(0xC7); lcd_dis("LOFF-MANL",9);
			command(0x87); lcd_dis("   ",3);
			LOAD = 0;
		}
		if(AUTO)
		{
			while(1)
			{
				adc();
				if(solar<=0.5)
				{
					command(0xC7); lcd_dis("LON-AUTO ",9);
					command(0x87); lcd_dis("(P)",3);
					LOAD = 1;
				}
				else
				{
					command(0xC7); lcd_dis("LOFF-AUTO",9);
					command(0x87); lcd_dis("   ",3);
					LOAD = 0;
				}
				if(ON)
				{
					command(0xC7); lcd_dis("LON-MANL ",9);
					command(0x87); lcd_dis("   ",3);
					LOAD = 1;
					break;
				}
				if(OFF)
				{
					command(0xC7); lcd_dis("LOFF-MANL",9);
					command(0x87); lcd_dis("   ",3);
					LOAD = 0;
					break;
				}
			}	
			
		}
		
		
	} 
}

void init()
{
	lcd_init();
	TRISA = 0xFF;
	TRISB = 0x07;		//0b00000111
	PORTB = 0;
}

void pwm()
{
	CCP1CON = 0x0C;
	CCP2CON = 0x0C;
	PR2 = 0x24;
	T2CON = 0x05;

	CCPR1L   = DutyCycle>>2;        	// Put MSB 8 bits in CCPR1L
	CCP1CON &= 0xCF;                	// Make bit4 and 5 zero
	CCP1CON |= (0x30&(DutyCycle<<4));   // Assign Last 2 LSBs to CCP1CON
	
	CCPR2L   = DutyCycle1>>2;        	// Put MSB 8 bits in CCPR1L
	CCP2CON &= 0xCF;                	// Make bit4 and 5 zero
	CCP2CON |= (0x30&(DutyCycle1<<4));   // Assign Last 2 LSBs to CCP1CON
	
}
void adc()
{
		ADCON0 = 0x15;
		ADCON1 = 0xC0;
		__delay_ms(100);
		while(ADGO);
		temp = (256*ADRESH)+ADRESL;					// SOLAR
		delay(1000);
		ADCON0 = 0x15;
		ADCON1 = 0xC0;
		__delay_ms(100);
		while(ADGO);
		temp = (256*ADRESH)+ADRESL;					
		temp2 = (float)temp;
		temp2 = (temp2/204.6) * 4.31;
		solar = temp2;
		command(0x82);  float_dis(temp2);
	
		ADCON0 = 0x1D;
		ADCON1 = 0xC0;								// BATTERY
		while(ADGO);
		__delay_ms(100);
		temp = (256*ADRESH)+ADRESL;
		__delay_ms(100);__delay_ms(100);
		ADCON0 = 0x1D;
		ADCON1 = 0xC0;
		while(ADGO);
		__delay_ms(100);
		temp = (256*ADRESH)+ADRESL;
		temp2 = (float)temp; 
		temp2 = (temp2/204.6) * 3.25;
		battery = temp2;
		command(0x8C); float_dis(temp2);
				
		if(battery < solar) 
		{
			command(0xC0); lcd_dis("CHARGE",6);
			CHARGER = 1;
		}
		else 
		{
			command(0xC0); lcd_dis("NT-CHR",6);
			CHARGER = 0;
		}
			
}

void time(int ad)
{
	while(ad--)
	{
	__delay_ms(100);	
	}	
}	

void float_dis( float fl_val)
{
	int aa=0,bb=0,cc=0,dd=0;
	if(fl_val<10.0)					//7.5
	{
		aa=bb=cc=dd=0;
		fl_val = fl_val*10;			//75.0
		val = (int)fl_val;			//75
		aa = val/10;				//aa=7
		bb = val%10;				//bb=5
		write(aa + 0x30);			// 7
		write('.');					// .
		write(bb + 0x30);			// 5	
		write('V');write(' ');
	}
	else							//	12.5
	{
		aa=bb=cc=dd=0;
		fl_val = fl_val*10;			//	125
		val = (int)fl_val;
		aa = val/100;				// aa=1
		bb = val%100;				// bb = 25;
		cc = bb/10;					// cc = 2
		dd = bb%10;					// dd = 5
		write(aa + 0x30);	
		write(cc + 0x30);
		write('.');
		write(dd + 0x30);
		write('V');
	}
}
void interrupt tmr2(void)
{
	if(TMR2IF == 1)
	{
		TMR2IF = 0;
	}
}