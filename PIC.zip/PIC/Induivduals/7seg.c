#include<pic.h>

#define row1 RB0
#define row2 RB1
#define col1 RB2
#define col2 RB3

void main()
{
	TRISB = 0x03;
	TRISC = 0x00;
	while(1)
	{
		col1=1; col2=0;
      	if((col1==1) && (row1==1))   { PORTC = 0x60} else { PORTC = 0x00; }
      	if((col1==1) && (row2==1))   { PORTC = 0xf2;} else { PORTC = 0x00; }
      
      	col1=0; col2=1;
      	if((col2==1) && (row1==1))   { PORTC = 0xda;} else { PORTC = 0x00; }
      	if((col2==1) && (row2==1))   { PORTC = 0x66;} else { PORTC = 0x00; }
	}
}