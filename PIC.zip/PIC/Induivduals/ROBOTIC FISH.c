/*
=================================================================
Description : CUSTOM FONTS
MCU		 	: PIC16F877A
Program IDE	: MPLAB v8.30
Website		: http://www.circuitvalley.com/2012/02/lcd-custom-character-hd44780-16x2.html
=================================================================
*/

#include<pic.h>
#include"LCD1.h"
#include "uart.h"
__CONFIG(0x3F71);
#define _XTAL_FREQ 4e6

unsigned int dig[8] = {0xe,0x11,0xe,0xa,0xe,0xa,0xa,0x1f};

void main()
{
	lcd_init();	
	command(0x80); lcd_dis("Data",4);
										
			/* ~~~~~~~~~~~~~~~~ Load RAM ~~~~~~~~~~~~~~~~~~~~ */
						command(0x40);
						write(0xe);
						write(0x1b);
						write(0x11);
						write(0x11);
						write(0x11);
						write(0x11);
						write(0x11);
						write(0x1f);
						
						write(0xe);
						write(0x1b);
						write(0x11);
						write(0x11);
						write(0x11);
						write(0x11);
						write(0x1F);
						write(0x1f);
						
						write(0xe);
						write(0x1b);
						write(0x11);
						write(0x11);
						write(0x11);
						write(0x1F);
						write(0x1F);
						write(0x1f);
						
						write(0xe);
						write(0x1b);
						write(0x11);
						write(0x11);
						write(0x1F);
						write(0x1F);
						write(0x1F);
						write(0x1f);
						
						write(0xe);
						write(0x1b);
						write(0x11);
						write(0x1F);
						write(0x1F);
						write(0x1F);
						write(0x1F);
						write(0x1f);
						
						write(0xe);
						write(0x1b);
						write(0x1F);
						write(0x1F);
						write(0x1F);
						write(0x1F);
						write(0x1F);
						write(0x1f);
						
						write(0xe);
						write(0x1F);
						write(0x1F);
						write(0x1F);
						write(0x1F);
						write(0x1F);
						write(0x1F);
						write(0x1f);
						
						
	/*~~~~~~~~~~~ FOR Display just call the location ~~~~~~~~~~~~~~~~~~~~~~~~~*/
						command(0xC0);
						
						write(0x00);
						write(0x01);
						write(0x02);
						write(0x03);
						write(0x04);
						write(0x05);
						write(0x06);
						lcd_dis(" BATTERY ",9);
						    while(1)
						    {}

}