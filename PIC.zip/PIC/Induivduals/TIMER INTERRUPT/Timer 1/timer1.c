#include<pic.h>
#include "lcd.h"

unsigned int count=0, sec=0;
void tmr1_init();
void main()
{
	tmr1_init();
	lcd_init();
	while(1)
	{
		command(0x80);
		write(sec/10 + '0'); write(sec%10 + '0');
	}
}

void tmr1_init()
{
	GIE = 1;
	PEIE = 1;
	T1CON = 0x31;
	TMR1IE = 1;
	TMR1L = 0x1D;
	TMR1H = 0xFB;
}

void interrupt timer1(void)
{
	if(TMR1IF ==  1)
	{
		TMR1IF = 0;
		count++;
		if(count == 100)
		{
			count = 0;
			sec++;
		}
	}
	TMR1L = 0x1D;
	TMR1H = 0xFB;
}