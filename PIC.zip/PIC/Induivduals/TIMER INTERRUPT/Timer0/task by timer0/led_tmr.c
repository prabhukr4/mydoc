#include<pic.h>
#include "lcd.h"
__CONFIG(0x3f71);

unsigned int count = 0,sec = 0, sec1=0;

void tmr0_init();

void main()
{
	lcd_init();
	tmr0_init();
	TRISB = 0x00;
	command(0x80); lcd_dis("Count",5);
	
	while(1)
	{
		command(0xc0); write(sec/10 + '0'); write(sec%10 + '0');
		
		if(sec1<=5)
		{
			RB1=1;
			command(0xC3); lcd_dis("LED ON",7);
			
		}
		if(sec1 > 5)
		{
			RB1=0;
			command(0xc3); lcd_dis("LED OFF",7);
			if(sec1 == 10)
		 	{
		 		sec1 = 0;
		 	}
		 } 
		
	}
}

void tmr0_init()
{
	GIE = 1;
	PEIE = 1;
	TMR0IE = 1;
	OPTION = 0x07;
	TMR0 = 0xD8;
}

void interrupt tmr0(void)
{
	if(TMR0IF == 1)
	{
		TMR0IF = 0;
		count++;
		if(count >= 100)
		{
			count = 0;
			sec++;
			sec1++;
		}
	}
	TMR0 = 0xD8;
}