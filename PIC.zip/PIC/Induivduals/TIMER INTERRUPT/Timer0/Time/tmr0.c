#include<pic.h>
#include "lcd.h"

void tmr0_init();
void time_now(int, int);
unsigned int count=0, sec=0, min, hr;
void main()
{
	tmr0_init();
	lcd_init();
	
	/*~~~~~~~~~~~~~~~UPDATE YOUR PRESENT TIME HERE FOR COUNT TIME~~~~~~~~~~~~~~~~~~~~~~*/

							time_now(02,48);

	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/	
	command(0x80); lcd_dis("Time",4);
	command(0xc0); lcd_dis("  :  :",6);
	command(0xc0); write(hr/10 + '0');  write(hr%10 + '0');
	command(0xc3); write(min/10 + '0'); write(min%10 + '0');
		
	while(1)
	{
		command(0xc6);
		write(sec/10 + '0');
		write(sec%10 + '0');
		if(sec == 60)
		{
			sec=0;
			min++;
			command(0xc3);
			write(min/10 + '0');
			write(min%10 + '0');
			if(min == 60)
			{
				min=0;
				hr++;
				command(0xc0);
				write(hr/10 + '0');
				write(hr%10 + '0');
				if(hr==60)
				{
					hr=min=sec=0;
					
				}
			}
		}
	}
}

void time_now(int a, int b)
{
	hr = a;
	min = b;
}

void tmr0_init()
{
	GIE = 1;
	PEIE = 1;
	TMR0IE = 1;
	OPTION = 0x07;
	TMR0 = 0xD8;
}

void interrupt tmr0(void)
{
	if(TMR0IF == 1)
	{
		TMR0IF = 0;
		count++;
		if(count >= 100)
		{
			count = 0;
			sec++;
		}
	}
	TMR0 = 0xD8;
}