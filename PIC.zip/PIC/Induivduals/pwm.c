#include<pic.h>
#include "lcd.h"

unsigned int temp=0;
void all_init();
void adc_conv();
void main()
{
	all_init();
	while(1)
	{	
		adc_conv();
		command(0x80); lcd_dis("ADC Value",9);
		command(0xC0);
		hex_dec(temp);
		CCPR1L = (temp>>2);
		CCP1CON &= 0xCf;
		CCP1CON |= (0x30 & (temp<<4));
	}
}
 

void all_init()
{
	lcd_init();

	/*~~~~~~~ TIMER 2 and PWM ~~~~~~*/
	
	GIE = 1;
	PEIE = 1;
	T2CON = 0x05;
	TMR2IE = 1;
	PR2 = 0xF9;
	CCP1CON = 0x0c;
	CCPR1L = 255;
	ADCON1 = 0xC0;
}

void adc_conv()
{
	ADCON0 = 0x05;
	temp = (256 * ADRESH)+ ADRESL;
	delay(100);
}
void interrupt tmr2(void)
{
	if(TMR2IF == 1)
	{
		TMR2IF = 0;
	}
}