#include<pic.h>
#include "lcd.h"
__CONFIG(0x3F71);
#define _XTAL_FREQ 4e6

void ext_init();
unsigned int count = 0;
void main()
{

	lcd_init();
	ext_init();
	TRISB = 0xff;
	while(1)
	{
		command(0x80);
		lcd_dis("The Count value ");
		command(0xc0);
		write((count/10) + 0x30);
		write((count%10) + 0x30);
	}
}

void ext_init()
{
	GIE = 1;
	PEIE = 1;
	INTE = 1;
	RBIE = 1;
	INTEDG = 1;	// PUT PULL UP
}

void interrupt external(void)
{
	if(INTF)
	{
		INTF = 0;
		count++;
	}
}