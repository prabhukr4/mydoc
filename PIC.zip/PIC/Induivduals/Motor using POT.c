
/*sample program to generate PWM*/

#include<pic.h>
#include<stdio.h>
#include<math.h>
#include"lcd.h"
void pwm_init();
	void ftoa(float n, char *res, int afterpoint);
void adc_conv(void);
unsigned int a,b;
void main()
{
	 char res[20];
	lcd_init();	
	TRISA = 0xff;
	ADCON0 = 0x05;
	ADCON1 = 0xC0;
	ADRESL = 0x00;
	ADRESH = 0x00;
	TRISB = 0;
	pwm_init();		
	a=0;b=0;
	while(1)
	{
		adc_conv();
		command(0x80);
		lcd_dis("ADRESL VALUE:", 13);
		command(0x8D);
		write(a/100 + '0');
		b = a%100;
		write(b/10 + '0');
		write(b%10 + '0');
		ADRESL=0x00;
		
		//CCPR1L=a;
	   CCPR1L:CCP1CON=a;
	   ftoa(0.5, res, 1);
	   command(0xC0);
	   lcd_dis(res, 10);
	}
}
void pwm_init()	
{
	
/*to enable timer2 interrupt*/
	GIE=1;
	PEIE=1;
	
	T2CON=0x05;	//0b 0000 0101 (TIMER2 CONTROL REGISTER)
	TMR2IE=1;	//timer2 interrupt enable		
/*for pwm generation*/
	PR2=0xF9;	//PWM peroid for 1ms
	//CCPR1L=50;//0xFA;	//PWM dutycycle
	CCP1CON=0x0C;	//PWM mode in capture compare register
	//TRISC=0;		//CCP1 as output
}
void interrupt timer2(void)
{
	if(TMR2IF==1)
	{
		TMR2IF=0;
	}
}
void adc_conv(void)
{
	ADCON0 = 0x05;
	while(ADGO);
	a =(256*ADRESH)+ADRESL;
}
	void ftoa(float n, char *res, int afterpoint)
{
    // Extract integer part
    int ipart = (int)n;
 
    // Extract floating part
    float fpart = n - (float)ipart;
 
    // convert integer part to string
    int i = intToStr(ipart, res, 0);
 
    // check for display option after point
    if (afterpoint != 0)
    {
        res[i] = '.';  // add dot
 
        // Get the value of fraction part upto given no.
        // of points after dot. The third parameter is needed
        // to handle cases like 233.007
        fpart = fpart * pow(10, afterpoint);
 
        intToStr((int)fpart, res + i + 1, afterpoint);
    }	
}    		