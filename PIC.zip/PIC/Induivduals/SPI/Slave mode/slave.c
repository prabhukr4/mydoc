#include<pic.h>
#include "lcd.h"
#define _XTAL_FREQ 4e6

void time(int);
void init();

unsigned char data[10];

void main()
{
	init();
	command(0x80); lcd_dis("SPI SLAVE",9);
	while(1)
	{
		
	}
}

void init()
{
	lcd_init();
	TRISB = 0; PORTB = 0;

	
	/* ~~~~~~~~~~~~~~~~~ SLAVE MODE ~~~~~~~~~~~~~~~~ */
	
	SSPSTAT = 0x40;				//	SSP Status Register
	SSPCON = 0x04;				//	SSP Control Register
}
void time(int a)
{
	while(a--)
	{
		__delay_ms(100);
	}
}

void interrupt rx(void)
{
	if(SSPIF)
	{
		SSPIF = 0;
		data[0] = SSPBUF;
		command(0xCB); write(SSPBUF);
		RB0 = 1;
		command(0xC0); lcd_dis("Finished",8);
		time(50);
		
	}
	else
	{
		RB0 = 0;
		command(0xCB); write(' ');
		command(0xC0); lcd_dis("Process ",8);
	}
}   