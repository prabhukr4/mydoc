#include<pic.h>
#include "lcd.h"
#define _XTAL_FREQ 4e6

void init();
void time(int);

void main()
{
	init();
	command(0x80); lcd_dis("SPI MASTER",10);
	time(20);
	while(1)
	{
		RC2 = 1;
		RB0 = 0;
		command(0xC0); 
		lcd_dis("Process ",8);
		SSPBUF = '1' ;			// Transmitting data register
		while(! BF );			// when the BF is set the data is transmitted
		BF = 0;
		RC2 = 0;
		RB0 = 1;
		command(0xC0); lcd_dis("Finished",8);
		time(50);
		
	}
	
}

void init()
{
	lcd_init();
	TRISB = 0; PORTB = 0;
	/* ~~~~~~~~~~~~~ MASTER MODE ~~~~~~~~~~~~~~~~ */
	
	SSPSTAT = 0xC0;				//	SSP Status Register
	SSPCON = 0x30;				//	SSP Control Register
}

void time(int a)
{
	while(a--)
	{
		__delay_ms(100);
	}
}